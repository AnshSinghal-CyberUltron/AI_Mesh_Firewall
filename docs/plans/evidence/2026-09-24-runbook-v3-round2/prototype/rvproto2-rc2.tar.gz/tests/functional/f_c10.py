"""F-C10: owner-level admission on ONE guard owner (all-in-one unit, real L4 owner slowed by
RV_INJECT_OWNER_DELAY_MS=4 per window, so one owner saturates within one dev VM).

  python tests/functional/f_c10.py codel|bound|off [overload|poisson45] [NAME=VALUE ...]
     codel  rvproto-2 default (RC2): shed only on a STANDING queue (CoDel detector), hard cap 60 ms of work,
            guard budget RV_GUARD_WAIT_MS (admitted work is answered late, never abandoned)
     bound  RC1's rule: instantaneous 12 ms backlog bound + per-request budget shed (RV_OWNER_ADMISSION=bound)
     off    negative control: frozen-1 admission (C10 off); pins RV_GUARD_DEADLINE_MS=20 as round 1 did
All run with AMF_TARGET_P99_MS=1000 (round 1's unit-lane setting, which lifted the frozen per-worker bounds).
Loads (org-b: FAIL_OPEN posture, so an UNAVAILABLE guard = a FAIL_OPEN event), 70/30 SSE/JSON, headline corpus:
  overload   constant F_RATE (default 200 req/s, about 2x the slowed owner) for 30 s
  poisson45  Poisson arrivals at F_RATE (default 45 req/s, about 45% of the slowed owner) for 60 s
PASS overload (codel, bound): sheds happen AT THE OWNER (owner_shed > 0) as 503 + Retry-After; 0 FAIL_OPEN;
0 guard deadline expiries; admitted work waits at most the owner's hard cap (owner guard_queue_ns p99 <= the
cap x 1.1). PASS poisson45 (codel): owner sheds <= 0.1% of requests (bursts are absorbed, not shed). bound on
poisson45 is the reference (RC1 shed ordinary bursts). off is expected to show FAIL_OPEN > 0 under overload.
"""
from __future__ import annotations

import json
import os
import sys
import threading
import time
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ftlib as F  # noqa: E402

LOADS = {"overload": (float(os.environ.get("F_RATE", "200")), 30, "constant"),
         "poisson45": (float(os.environ.get("F_RATE", "45")), 60, "poisson")}
MODE_ENV = {"codel": {"RV_FIX_C10": "on", "RV_OWNER_ADMISSION": "codel"},
            "bound": {"RV_FIX_C10": "on", "RV_OWNER_ADMISSION": "bound"},
            "off": {"RV_FIX_C10": "off"}}


def probe_retry_after(port: int, stop: threading.Event, out: list[dict[str, str]]) -> None:
    body = json.dumps({"model": "gpt-4o-mini", "messages": [{"role": "user", "content": "probe " * 40}],
                       "max_tokens": 8}).encode()
    while not stop.is_set():
        code, hdr, _ = F.http(f"http://127.0.0.1:{port}/v1/chat/completions", data=body, timeout=10,
                              headers={"authorization": "Bearer sk-rv-org-b-0001", "content-type": "application/json"})
        if code == 503:
            out.append({"retry-after": hdr.get("retry-after", ""), "retry-after-ms": hdr.get("retry-after-ms", "")})
        time.sleep(0.2)


def main(mode: str, load: str, extra: dict[str, str]) -> int:
    F.stop_all()
    name = f"f_c10_{mode}_{load}"
    out = Path.home() / "rv2" / "logs" / name
    rate, dur, arrival = LOADS[load]
    F.valkey("flushall")
    F.control("init-db")
    F.control("seed")
    F.synthprov(out)
    port = 8400
    F.start("rvproto", [F.PY, "-m", "rvproto.serve"], out, RV_GUARD_TOPOLOGY="owner",
            WEB_CONCURRENCY=os.environ.get("F_WORKERS", "3"), RV_PORT=str(port), RV_INJECT_OWNER_DELAY_MS="4",
            RV_METRICS_DUMP_S="0", **{**MODE_ENV[mode], **extra})
    F.wait_ready(port)
    before = F.exporter()
    stop, ra = threading.Event(), []
    th = threading.Thread(target=probe_retry_after, args=(port, stop, ra), daemon=True)
    th.start()
    reqs = F.measured(F.olg(f"http://127.0.0.1:{port}", rate, dur, out / "olg", auth="sk-rv-org-b-0001",
                            extra=("-arrival", arrival)))
    stop.set()
    after = F.exporter()
    st = Counter(r.get("status", 0) for r in reqs)
    fail_open = sum(1 for r in reqs if r.get("status") == 200 and "sem:U" in (r.get("stages") or ""))
    owners = after.get("owners", [])
    ob = {o["owner"]: o for o in before.get("owners", [])}
    owner_counts = {o["owner"]: {k: v - ob.get(o["owner"], {}).get("count", {}).get(k, 0)
                                 for k, v in o["count"].items() if k.startswith("owner_shed") or k == "owner_requests"}
                    for o in owners}
    wc = {k: after["count"].get(k, 0) - before["count"].get(k, 0)
          for k in ("guard_deadline_expired", "guard_unavailable_findings", "guard_owner_sheds", "admitted")}
    summ = after.get("summary", {})
    deadlines = sorted({round(float(pw["gauge"].get("guard_deadline_ms", 0)), 2) for pw in after.get("per_worker", [])})
    t_input_p99 = summ.get("t_input_ns", {}).get("p99_ms")
    owner_q = [o["summary"].get("guard_queue_ns", {}).get("p99_ms") for o in owners]
    owner_x = [o["summary"].get("guard_exec_ns", {}).get("p99_ms") for o in owners]
    result = {"mode": mode, "load": load, "rate": rate, "arrival": arrival, "env": {**MODE_ENV[mode], **extra},
              "offered": len(reqs), "status": {str(k): v for k, v in sorted(st.items())},
              "fail_open_200_with_sem_U": fail_open, "owner": owner_counts, "worker": wc,
              "retry_after_probes": len(ra), "retry_after_present": sum(1 for x in ra if x["retry-after"]),
              "retry_after_ms_sample": [x["retry-after-ms"] for x in ra[:5]],
              "derived_guard_deadline_ms": deadlines, "t_input_p99_ms_cumulative": t_input_p99,
              "owner_queue_p99_ms": owner_q, "owner_exec_p99_ms": owner_x}
    sheds_at_owner = sum(v.get("owner_shed", 0) for v in owner_counts.values())
    cap_ms = float(extra.get("RV_OWNER_QUEUE_MS", "60" if mode == "codel" else "12"))
    result["owner_sheds_total"] = sheds_at_owner
    result["owner_shed_fraction"] = round(sheds_at_owner / max(len(reqs), 1), 5)
    if load == "overload":
        ok = (sheds_at_owner > 0 and fail_open == 0 and wc["guard_deadline_expired"] == 0 and st.get(503, 0) > 0
              and (not ra or all(x["retry-after"] for x in ra))
              and all(q is not None and q <= cap_ms * 1.1 for q in owner_q))
    else:
        ok = fail_open == 0 and wc["guard_deadline_expired"] == 0 and sheds_at_owner <= 0.001 * max(len(reqs), 1)
    result["verdict"] = ("PASS" if ok else "FAIL") + {"off": " (negative control)", "bound": " (RC1 rule, reference)"}.get(mode, "")
    F.save(name, result)
    F.stop_all()
    print(json.dumps(result, indent=1, default=str))
    return 0


if __name__ == "__main__":
    m = sys.argv[1] if len(sys.argv) > 1 else "codel"
    ld = sys.argv[2] if len(sys.argv) > 2 and "=" not in sys.argv[2] else "overload"
    ex = dict(kv.split("=", 1) for kv in sys.argv[2:] if "=" in kv)
    ex.setdefault("AMF_TARGET_P99_MS", "1000")
    if m == "off":
        ex.setdefault("RV_GUARD_DEADLINE_MS", "20")
    raise SystemExit(main(m, ld, ex))
