"""F-C36-WRITER: honest control-plane write outcomes across a Postgres outage (a Cloud SQL failover stand-in).

  python tests/functional/f_writer_failover.py     (env: RV_DATABASE_URL, RV_REDIS_URL, RV_STATE_HMAC_KEY)

A writer adds uniquely named API keys, back to back, for 30 s (StateWriter over PgDB + the store, as the CLI).
At +10 s the Postgres container restarts: open connections drop, and new ones fail for a few seconds.
Each write's reported outcome is recorded: ok | ok_publish_pending | unknown | error.
PASS:
  - every ok / ok_publish_pending write is in rv2_record with the reported (epoch, seq, hash);
  - no error write is in rv2_record (nothing was committed);
  - unknown writes (COMMIT's acknowledgement lost) are counted, either outcome allowed;
  - writes were attempted during the outage (the test exercised it);
  - one re-hydration round later, the store equals Postgres for every kind.
RC1 reported 22 of 149 committed writes as failures under the same kind of fault (r2-state): a publish that
re-read Postgres after the commit raised psycopg's error, which escaped as a write failure.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import time
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from rvproto.control.db import CommitUnknown, PgDB  # noqa: E402
from rvproto.control.rehydrate import Rehydrator  # noqa: E402
from rvproto.control.writer import StateWriter, key_hash  # noqa: E402
from rvproto.runtime.storeconn import sync_client  # noqa: E402


def main() -> int:
    db = PgDB(os.environ["RV_DATABASE_URL"])
    w = StateWriter(db, sync_client(os.environ["RV_REDIS_URL"], op_timeout_s=5.0),
                    os.environ["RV_STATE_HMAC_KEY"].encode(), actor="f-writer-failover")
    marks: dict[str, float] = {}

    def restart() -> None:
        time.sleep(10)
        marks["restart"] = time.time()
        subprocess.run(["sudo", "docker", "restart", "-t", "0", "rv2-pg"], check=True, capture_output=True)
        marks["restarted"] = time.time()

    th = threading.Thread(target=restart)
    th.start()
    writes: list[dict[str, object]] = []
    run_tag = f"{int(time.time())}"
    end, i = time.time() + 30, 0
    while time.time() < end:
        key = f"sk-fo-{run_tag}-{i}"
        t0 = time.time()
        try:
            w.key_add(key, "org-a", key_id=f"fo-{i}", rate=1e6, burst=1e6)
        except CommitUnknown:
            pass
        except Exception:  # noqa: BLE001 - the writer reported "error" (nothing committed)
            time.sleep(0.05)
        writes.append({**w.last, "i": i, "khash": key_hash(key), "t": t0})
        i += 1
    th.join()
    for _ in range(60):  # Postgres back: the re-hydrator republishes what a failed publish left behind
        try:
            db.version("key")
            break
        except Exception:  # noqa: BLE001
            time.sleep(1)
    rh = Rehydrator(db, w.r, w, period_ms=1000, checkpoint_s=5, stale_grace_ms=0)
    rh.check_once()
    diverged = {k: rh.diagnose(k) for k in ("plan", "key", "ks", "budget")}
    stored = {r["key"]: r for r in db.records("key")}
    status = Counter(str(x["status"]) for x in writes)
    def matches(x: dict[str, object]) -> bool:
        rec = stored.get(str(x["khash"]))
        return rec is not None and f'{rec["epoch"]}.{rec["seq"]}' == x.get("version") and rec["hash"] == x.get("hash")

    lost = [x for x in writes if x["status"] in ("ok", "ok_publish_pending") and not matches(x)]
    phantom = [x for x in writes if x["status"] == "error" and x["khash"] in stored]
    unknown = [x for x in writes if x["status"] == "unknown"]
    during = [x for x in writes if marks.get("restart", 0) <= float(x["t"]) <= marks.get("restarted", 0) + 10]  # type: ignore[arg-type]
    result = {"writes": len(writes), "status": dict(status), "marks": marks,
              "reported_ok_but_missing": len(lost), "reported_error_but_committed": len(phantom),
              "unknown_committed": sum(1 for x in unknown if x["khash"] in stored), "unknown_total": len(unknown),
              "writes_during_outage": len(during), "store_vs_postgres_after_one_round": diverged,
              "examples": [{k: x[k] for k in ("i", "status", "version") if k in x} for x in (lost + phantom)[:5]]}
    result["verdict"] = "PASS" if (not lost and not phantom and during and not any(diverged.values())
                                   and status.get("error", 0) + status.get("ok_publish_pending", 0) + len(unknown) > 0) else "FAIL"
    out = Path.home() / "rv2" / "results" / "f_writer_failover.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=1, default=str))
    print(json.dumps(result, indent=1, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
