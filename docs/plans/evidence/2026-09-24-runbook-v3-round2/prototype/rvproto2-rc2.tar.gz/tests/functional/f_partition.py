"""F-PARTITION (D2/D1): a gateway<->store network partition while serving.

  python tests/functional/f_partition.py [SECONDS]      (default 60)

All-in-one unit (C36 on, defaults: RV_KS_STALE_MS 5000, RV_STORE_BG_TIMEOUT_MS 1000, RV_PUBSUB_PING_MS 5000).
Load: olg at 20 req/s with key a (cached from the start). Probes every 250 ms: key p (valid, added just before
the partition and never used before it: every probe is a store read) and key q (revoked). After 20 s the host
firewall DROPs every packet between the gateway and Valkey, both directions (loopback :16379 and the
container's :6379), so established pooled and pub/sub connections die silently, as in a real partition (VPC
firewall rules would not cut them); then heal; then 30 s more.
PASS:
  - every gateway worker is alive afterwards (same pid) and its RSS grew < 150 MB (D2 grew GBs and OOM-killed);
  - the event loops kept running during the gap (exporter loop-lag p99 < 50 ms in every window);
  - during the gap every answer is 200 (served from RAM within the staleness bound) or 503 with a declared
    gap code (kill_switch_unavailable | plan_unavailable | shared_state_unavailable) carrying Retry-After;
    never 500 (D1), never a transport error; key p never 401/403; key q never 200;
  - recovery: key p answered 200 within 5 s of the heal.
"""

from __future__ import annotations

import json
import subprocess
import sys
import threading
import time
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ftlib as F  # noqa: E402

GAP_CODES = ("kill_switch_unavailable", "plan_unavailable", "shared_state_unavailable")


def _rules(action: str) -> None:
    ip = F.valkey_container_ip()
    rules = [["OUTPUT", "-o", "lo", "-p", "tcp", "--dport", "16379"], ["OUTPUT", "-o", "lo", "-p", "tcp", "--sport", "16379"],
             ["OUTPUT", "-d", ip, "-p", "tcp", "--dport", "6379"], ["INPUT", "-s", ip, "-p", "tcp", "--sport", "6379"],
             ["FORWARD", "-d", ip, "-p", "tcp", "--dport", "6379"], ["FORWARD", "-s", ip, "-p", "tcp", "--sport", "6379"]]
    for r in rules:
        subprocess.run(["sudo", "iptables", "-w", action, r[0], *r[1:], "-j", "DROP"], check=action == "-I",
                       capture_output=True)


def _rss_mb(pid: int) -> float | None:
    try:
        for line in Path(f"/proc/{pid}/status").read_text().splitlines():
            if line.startswith("VmRSS:"):
                return int(line.split()[1]) / 1024
    except OSError:
        return None
    return None


def _probe(key: str, name: str, stop: threading.Event, out: list[dict[str, object]]) -> None:
    body = json.dumps({"model": "gpt-4o-mini", "messages": [{"role": "user", "content": "hello"}], "max_tokens": 4}).encode()
    while not stop.is_set():
        t = time.time()
        try:
            code, hdr, raw = F.http("http://127.0.0.1:8400/v1/chat/completions", data=body, timeout=10,
                                    headers={"authorization": f"Bearer {key}", "content-type": "application/json"})
        except OSError as exc:
            code, hdr, raw = 0, {}, repr(exc).encode()
        err = ""
        if code and code != 200:
            try:
                err = json.loads(raw)["error"]["code"]
            except (ValueError, KeyError, TypeError):
                err = raw[:60].decode(errors="replace")
        out.append({"t": t, "k": name, "status": code, "code": err, "retry_after": hdr.get("retry-after", "")})
        time.sleep(0.25)


def main(gap_s: float) -> int:
    F.stop_all()
    out = Path.home() / "rv2" / "logs" / "f_partition"
    _rules("-D")  # a previous run's rules, if any
    F.valkey("flushall")
    F.control("init-db")
    F.control("seed")
    F.control("key-revoke", "sk-rv-org-q-0001")
    F.synthprov(out)
    F.start("rvproto", [F.PY, "-m", "rvproto.serve"], out, RV_GUARD_TOPOLOGY="owner", WEB_CONCURRENCY="3", RV_PORT="8400")
    F.wait_ready(8400)
    pids = [int(pw["pid"]) for pw in F.exporter().get("per_worker", [])]
    rss0 = {p: _rss_mb(p) for p in pids}
    F.control("key-add", "sk-rv-part-0001", "org-a")  # key p: valid, never seen by the gateway yet
    marks: dict[str, float] = {}
    probes: list[dict[str, object]] = []
    samples: list[dict[str, object]] = []
    stop = threading.Event()

    def fault() -> None:
        time.sleep(20)
        marks["cut"] = time.time()
        _rules("-I")
        time.sleep(gap_s)
        _rules("-D")
        marks["heal"] = time.time()

    def watch() -> None:
        while not stop.is_set():
            try:
                sig = json.loads(F.http("http://127.0.0.1:9464/signals", timeout=3)[2])
            except (OSError, ValueError):
                sig = {}
            samples.append({"t": time.time(), "rss": {p: _rss_mb(p) for p in pids},
                            "loop_lag_p99_ms": sig.get("loop_lag_p99_ms")})
            time.sleep(2)

    threads = [threading.Thread(target=fault), threading.Thread(target=watch, daemon=True),
               threading.Thread(target=_probe, args=("sk-rv-part-0001", "p", stop, probes), daemon=True),
               threading.Thread(target=_probe, args=("sk-rv-org-q-0001", "q", stop, probes), daemon=True)]
    for t in threads:
        t.start()
    reqs = F.olg("http://127.0.0.1:8400", 20, int(20 + gap_s + 30), out / "olg", ramp=1, warmup=1)
    threads[0].join()
    stop.set()
    time.sleep(1)
    result = _verdict(gap_s, marks, pids, rss0, probes, samples, reqs)
    F.save("f_partition", result)
    F.stop_all()
    _rules("-D")
    print(json.dumps(result, indent=1, default=str))
    return 0


def _verdict(gap_s: float, marks: dict[str, float], pids: list[int], rss0: dict[int, float | None],
             probes: list[dict[str, object]], samples: list[dict[str, object]], reqs: list[dict[str, object]]) -> dict[str, object]:
    cut, heal = marks["cut"], marks["heal"]
    in_gap = [p for p in probes if cut <= float(p["t"]) < heal]  # type: ignore[arg-type]
    alive = {p: _rss_mb(p) is not None for p in pids}
    growth = {p: round(max((s["rss"].get(p) or 0) for s in samples) - (rss0.get(p) or 0), 1) for p in pids}  # type: ignore[union-attr]
    lags = [float(s["loop_lag_p99_ms"]) for s in samples if s["loop_lag_p99_ms"] is not None]  # type: ignore[arg-type]
    bad_gap = [p for p in in_gap if not (p["status"] == 200 or (p["status"] == 503 and p["code"] in GAP_CODES and p["retry_after"]))
               and not (p["k"] == "q" and p["status"] == 401)]
    p_after = [float(p["t"]) for p in probes if p["k"] == "p" and p["status"] == 200 and float(p["t"]) >= heal]  # type: ignore[arg-type]
    olg_gap = Counter(str(r.get("status")) for r in reqs if r.get("status") is not None)
    res = {"gap_s": gap_s, "marks": marks, "workers_alive": alive, "rss_growth_mb": growth,
           "loop_lag_p99_ms_max": max(lags) if lags else None,
           "probe_status_in_gap": dict(Counter(f'{p["k"]}:{p["status"]}:{p["code"]}' for p in in_gap)),
           "gap_answers_outside_contract": bad_gap[:10], "olg_status_all": dict(olg_gap),
           "key_p_401_403": sum(1 for p in probes if p["k"] == "p" and p["status"] in (401, 403)),
           "key_q_200": sum(1 for p in probes if p["k"] == "q" and p["status"] == 200),
           "http_500": sum(1 for p in probes if p["status"] == 500) + olg_gap.get("500", 0),
           "recovered_after_heal_s": round(min(p_after) - heal, 3) if p_after else None}
    res["pass"] = (all(alive.values()) and all(g < 150 for g in growth.values()) and bool(lags) and max(lags) < 50
                   and not bad_gap and res["key_p_401_403"] == 0 and res["key_q_200"] == 0 and res["http_500"] == 0
                   and res["recovered_after_heal_s"] is not None and res["recovered_after_heal_s"] <= 5)
    res["verdict"] = "PASS" if res["pass"] else "FAIL"
    return res


if __name__ == "__main__":
    raise SystemExit(main(float(sys.argv[1]) if len(sys.argv) > 1 else 60))
