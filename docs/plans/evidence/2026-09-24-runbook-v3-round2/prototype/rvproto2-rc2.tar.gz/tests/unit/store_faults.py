"""Store fault injection for the D1/D2 tests: a real TCP store (fakeredis), a partition proxy, and the exact
socket death uvloop reports when TCP keepalive gives up during a partition."""

from __future__ import annotations

import errno
import os
import select
import socket
import threading
import time
from typing import Any

from fakeredis import TcpFakeServer


class FakeStore:
    """fakeredis over real TCP (RESP3 + hiredis, pub/sub, MULTI) in a thread of this process."""

    def __init__(self) -> None:
        self.srv = TcpFakeServer(("127.0.0.1", 0), server_type="redis")
        self.port = int(self.srv.server_address[1])
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    @property
    def url(self) -> str:
        return f"redis://127.0.0.1:{self.port}/0"

    def close(self) -> None:
        self.srv.shutdown()
        self.srv.server_close()


class PartitionProxy:
    """TCP proxy in front of a store. partition(): every connection that exists stops forwarding FOR EVER (its
    sockets stay open: nothing is sent, nothing is closed) and new connections are accepted but never answered,
    i.e. a silent partition that outlives the TCP connections. heal(): new connections work again."""

    def __init__(self, upstream_port: int) -> None:
        self.up = ("127.0.0.1", upstream_port)
        self.lsock = socket.create_server(("127.0.0.1", 0))
        self.port = int(self.lsock.getsockname()[1])
        self.cut = threading.Event()
        self.generation = 0
        self._held: list[socket.socket] = []
        threading.Thread(target=self._accept, daemon=True).start()

    @property
    def url(self) -> str:
        return f"redis://127.0.0.1:{self.port}/0"

    def partition(self) -> None:
        self.generation += 1
        self.cut.set()

    def heal(self) -> None:
        self.cut.clear()

    def _accept(self) -> None:
        while True:
            try:
                c, _ = self.lsock.accept()
            except OSError:
                return
            self._held.append(c)
            if self.cut.is_set():
                continue  # accepted by the kernel, never answered
            u = socket.create_connection(self.up)
            self._held.append(u)
            gen = self.generation
            for a, b in ((c, u), (u, c)):
                threading.Thread(target=self._pump, args=(a, b, gen), daemon=True).start()

    def _pump(self, src: socket.socket, dst: socket.socket, gen: int) -> None:
        while self.generation == gen:
            r, _, _ = select.select([src], [], [], 0.02)
            if not r or self.generation != gen:
                continue
            try:
                data = src.recv(65536)
                if not data:
                    return
                dst.sendall(data)
            except OSError:
                return


def keepalive_death(conn: Any) -> None:
    """What uvloop does when TCP keepalive gives up on a socket during a partition (ETIMEDOUT): the transport
    closes and the protocol's connection_lost(exc) stores the error in the StreamReader, while redis-py still
    counts the connection as connected (uvloop closes first and calls connection_lost one loop turn later;
    the end state is the same)."""
    t = conn._writer.transport
    t.get_protocol().connection_lost(TimeoutError(errno.ETIMEDOUT, os.strerror(errno.ETIMEDOUT)))
    t.close()


def rss_mb() -> float:
    with open(f"/proc/{os.getpid()}/status") as f:
        for line in f:
            if line.startswith("VmRSS:"):
                return int(line.split()[1]) / 1024.0
    return -1.0


class Beat:
    """Event-loop progress: a 5 ms ticker; `max_gap_ms` is the longest the loop went without running it."""

    def __init__(self) -> None:
        self.n = 0
        self.last = time.monotonic()
        self.max_gap_ms = 0.0

    async def run(self) -> None:
        import asyncio

        while True:
            await asyncio.sleep(0.005)
            now = time.monotonic()
            self.max_gap_ms = max(self.max_gap_ms, (now - self.last) * 1e3)
            self.last = now
            self.n += 1
