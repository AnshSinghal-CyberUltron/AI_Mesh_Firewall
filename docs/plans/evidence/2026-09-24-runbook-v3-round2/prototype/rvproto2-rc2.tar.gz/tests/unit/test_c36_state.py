"""C36 durable state: Postgres-first writer, versioned signed store copy, fail-closed readers, re-hydration.

Runs against fakeredis (MULTI/EXEC, Lua, pub/sub) and the in-memory Postgres twin (control/db.py MemDB);
the same flows run against real Postgres + Redis in the dev-VM functional test.
"""

from __future__ import annotations

import threading
from typing import Any

import fakeredis
import orjson
import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from rvproto.admit import posture
from rvproto.admit.admission import Admission
from rvproto.admit.identity import Identity
from rvproto.admit.killswitch import KillSwitch
from rvproto.admit.quota import Gcra, TokenLease
from rvproto.admit.state_v2 import VersionedIdentity, VersionedKillSwitch
from rvproto.control.db import CommitUnknown, MemDB
from rvproto.control.rehydrate import Rehydrator
from rvproto.control.writer import StateWriter, key_hash
from rvproto.domain.plan import PlanUnavailable, PlanUnknownTenant
from rvproto.domain.request import ErrorSpec
from rvproto.plan.fixtures import tenants
from rvproto.plan.snapshot import PlanSnapshot
from rvproto.plan.snapshot_v2 import VersionedPlanSnapshot
from rvproto.runtime.metrics import Registry
from rvproto.runtime.store import K2_BUDGET, K2_BUDGET_GEN, K2_META, K_AUTH_EPOCH, K_KEYS, K_KILLSWITCH, K_KILLSWITCH_ORGS, K_PLAN_PREFIX, K_PLAN_VERSIONS
from rvproto.runtime.versioned import StoreDataUnavailable, Version, make_meta, make_record, verify_meta, verify_record

K = b"test-hmac-key-not-a-secret"
KEY_A, KEY_B = "sk-rv-org-a-0001", "sk-rv-org-b-0001"


def _stores() -> tuple[fakeredis.FakeServer, fakeredis.FakeRedis, fakeredis.aioredis.FakeRedis]:
    server = fakeredis.FakeServer()
    return server, fakeredis.FakeRedis(server=server), fakeredis.aioredis.FakeRedis(server=server)


def _seed(w: StateWriter) -> None:
    w.key_add(KEY_A, "org-a", key_id="key-a-1", rate=1e6, burst=1e6)
    w.key_add(KEY_B, "org-b", key_id="key-b-1", rate=1e6, burst=1e6)
    for org, doc in tenants().items():
        w.plan_set(doc)
        w.budget_set(org, 10**9)
        w.killswitch("org", org, False)
    w.killswitch("global", None, False)


def _readers(ar: object) -> tuple[VersionedIdentity, VersionedKillSwitch, VersionedPlanSnapshot]:
    vid = VersionedIdentity(ar, K)  # type: ignore[arg-type]
    vks = VersionedKillSwitch(ar, Registry(0), K, refresh_ms=100, stale_ms=5000, identity=vid)  # type: ignore[arg-type]
    return vid, vks, VersionedPlanSnapshot(ar, Registry(0), K, reconcile_ms=100, stale_ms=5000)  # type: ignore[arg-type]


async def test_flush_with_killed_org_and_revoked_key_fails_closed_then_rehydrates() -> None:
    _, r, ar = _stores()
    db = MemDB()
    w = StateWriter(db, r, K)
    _seed(w)
    vid, vks, plans = _readers(ar)
    await vks.refresh_once()
    await plans.reconcile_once()
    assert vks.state() == "ok" and not vks.org_killed("org-a")
    assert (await vid.fetch(key_hash(KEY_A))) is not None
    # engage the org kill switch, revoke key B (Postgres first, then the store)
    w.killswitch("org", "org-a", True)
    w.key_revoke(KEY_B)
    await vks.refresh_once()
    assert vks.org_killed("org-a")
    assert (await vid.fetch(key_hash(KEY_B))) is None  # revoked => 401, a verified explicit OFF record
    # the store loses everything
    r.flushall()
    with pytest.raises(StoreDataUnavailable):
        await vks.refresh_once()  # the snapshot keeps the killed org until its staleness ceiling
    assert vks.org_killed("org-a")
    with pytest.raises(StoreDataUnavailable):
        await vid.fetch(key_hash(KEY_A))  # a valid, uncached key: 503, never 401
    with pytest.raises(StoreDataUnavailable):
        await vid.fetch(key_hash(KEY_B))  # the revoked key is not admitted either
    with pytest.raises(StoreDataUnavailable):
        await plans.reconcile_once()
    assert plans.get("org-a").org_id == "org-a" and not isinstance(plans.get("org-a"), PlanUnknownTenant)
    lease = TokenLease(ar, Registry(0), chunk_tokens=100, durable=True)  # type: ignore[arg-type]
    with pytest.raises(StoreDataUnavailable):
        await lease.refill("org-a", 10)  # a vanished budget is UNAVAILABLE, never exhausted (429)
    # re-hydrate from Postgres
    events = Rehydrator(db, r, w, period_ms=100, checkpoint_s=5).check_once()
    assert {e["kind"] for e in events} == {"plan", "key", "ks", "budget"}
    await vks.refresh_once()
    await plans.reconcile_once()
    assert vks.state() == "ok" and vks.org_killed("org-a")  # still killed after the restore
    assert (await vid.fetch(key_hash(KEY_B))) is None  # still revoked
    assert (await vid.fetch(key_hash(KEY_A))) is not None
    assert await lease.refill("org-a", 10)
    assert plans.get("org-b").version == "b-1"


async def test_negative_control_frozen_readers_reproduce_the_v2_defects() -> None:
    """C36 off: after FLUSHALL the frozen-1 readers un-kill the org, answer 401 for a valid key and
    403 unknown tenant for an onboarded org (the defects C36 fixes)."""
    _, r, ar = _stores()
    r.hset(K_KEYS, key_hash(KEY_A), orjson.dumps({"key_id": "k", "org_id": "org-a", "rate_per_s": 1e6, "burst": 1e6}))
    r.set(K_PLAN_PREFIX + "org-a", orjson.dumps(tenants()["org-a"]))
    r.hset(K_PLAN_VERSIONS, "org-a", "a-1")
    r.set(K_KILLSWITCH, "0")
    r.hset(K_KILLSWITCH_ORGS, "org-a", "1")
    r.set(K_AUTH_EPOCH, "1")
    idn = Identity(ar)  # type: ignore[arg-type]
    ks = KillSwitch(ar, Registry(0), refresh_ms=100, stale_ms=5000, on_epoch=idn.on_epoch)  # type: ignore[arg-type]
    plans = PlanSnapshot(ar, Registry(0), reconcile_ms=100, stale_ms=5000)  # type: ignore[arg-type]
    await ks.refresh_once()
    await plans.load_all()
    assert ks.org_killed("org-a")
    r.flushall()
    await ks.refresh_once()
    await plans.reconcile_once()
    assert not ks.org_killed("org-a")  # defect: the killed org is served again
    assert (await idn.fetch(key_hash(KEY_A))) is None  # defect: a valid key reads as invalid (401)
    assert isinstance(plans.get("org-a"), PlanUnknownTenant)  # defect: "unknown tenant" (403)


async def test_regressed_store_is_unavailable_and_signed_rollback_moves_forward() -> None:
    _, r, ar = _stores()
    db = MemDB()
    w = StateWriter(db, r, K)
    _seed(w)
    _, vks, _ = _readers(ar)
    await vks.refresh_once()
    old_meta = r.get(K2_META + "ks")
    log_before = len(db.st.log)
    w.killswitch("global", None, True)
    await vks.refresh_once()
    assert vks.state() == "engaged"
    r.set(K2_META + "ks", old_meta)  # a lagging replica: an OLDER (validly signed) manifest
    with pytest.raises(StoreDataUnavailable, match="older"):
        await vks.refresh_once()
    v = w.rollback(log_before)  # restore the content of the log entry: global switch OFF, signed
    assert v.epoch == 2 and v.seq == 0
    await vks.refresh_once()
    assert vks.state() == "ok" and vks.version == Version(2, 0)


async def test_tampered_or_unsigned_records_are_rejected() -> None:
    _, r, ar = _stores()
    w = StateWriter(MemDB(), r, K)
    _seed(w)
    _, vks, _ = _readers(ar)
    raw = r.hget("{rv2}:ks", "org:org-a")
    rec = orjson.loads(raw)
    rec["body"]["on"] = True  # flip the switch without the key
    r.hset("{rv2}:ks", "org:org-a", orjson.dumps(rec))
    with pytest.raises(StoreDataUnavailable):
        await vks.refresh_once()
    forged = make_record(b"another-key", "ks", "org:org-a", {"on": False}, Version(9, 9))
    with pytest.raises(StoreDataUnavailable):
        verify_record(K, "ks", orjson.dumps(forged))


async def test_publish_failure_leaves_postgres_authoritative_and_rehydrator_catches_up() -> None:
    server, r, ar = _stores()
    db = MemDB()
    w = StateWriter(db, r, K)
    _seed(w)
    server.connected = False  # the store is unreachable during the write
    v = w.killswitch("org", "org-b", True)
    assert v > Version(1, 0) and any(x["key"] == "org:org-b" and x["body"]["on"] for x in db.records("ks"))
    server.connected = True
    events = Rehydrator(db, r, w, period_ms=100, checkpoint_s=5).check_once()
    assert [e["reason"] for e in events if e["kind"] == "ks"] == ["stale"]
    _, vks, _ = _readers(ar)
    await vks.refresh_once()
    assert vks.org_killed("org-b")


class _SlowReader:
    """A publisher that read its Postgres snapshot earlier (it lost the race to a newer write)."""

    def __init__(self, db: MemDB, snap: tuple[Version, list[dict[str, Any]]]) -> None:
        self.db, self.snap = db, snap

    def snapshot(self, kind: str) -> tuple[Version, list[dict[str, Any]]]:
        return self.snap

    def __getattr__(self, name: str) -> Any:
        return getattr(self.db, name)


def test_a_publish_never_moves_the_store_backwards() -> None:
    _, r, _ = _stores()
    db = MemDB()
    w = StateWriter(db, r, K)
    _seed(w)
    old = db.snapshot("ks")
    w.killswitch("org", "org-b", True)  # a newer write, published
    newer = r.get(K2_META + "ks")
    slow = StateWriter(_SlowReader(db, old), r, K)  # type: ignore[arg-type]
    assert slow.publish("ks") is None and r.get(K2_META + "ks") == newer
    assert w.publish("ks") == len(db.records("ks"))  # the same version again is an idempotent overwrite


def test_rehydrator_waits_out_a_writers_in_flight_publish_but_repairs_a_lost_one() -> None:
    _, r, _ = _stores()
    db = MemDB()
    w = StateWriter(db, r, K)
    _seed(w)
    quiet = StateWriter(db, r, K)
    quiet.publish_safe = lambda kind: True  # type: ignore[method-assign]  # Postgres only: the store is stale
    quiet.killswitch("org", "org-b", True)
    late = threading.Timer(0.02, lambda: w.publish("ks"))  # the writer's own publish lands 20 ms later
    late.start()
    rh = Rehydrator(db, r, w, period_ms=100, checkpoint_s=5, stale_grace_ms=200)
    assert rh.check_once() == []  # an in-flight publish is not a fault
    late.join()
    quiet.killswitch("org", "org-b", False)  # this publish never comes
    assert [(e["kind"], e["reason"]) for e in rh.check_once()] == [("ks", "stale")]
    assert verify_meta_version(r.get(K2_META + "ks")) == db.version("ks")


def test_a_budget_reset_is_never_undone_by_a_checkpoint_of_the_older_budget() -> None:
    _, r, _ = _stores()
    db = MemDB()
    w = StateWriter(db, r, K)
    _seed(w)
    rh = Rehydrator(db, r, w, period_ms=100, checkpoint_s=5)
    r.set(K2_BUDGET + "org-a", 0)  # org-a spent its budget, and that was checkpointed ...
    assert rh.checkpoint() == 3
    w.budget_set("org-a", 5000)  # ... then the operator granted a new one
    r.flushall()
    rh.check_once()
    assert int(r.get(K2_BUDGET + "org-a")) == 5000  # the limit, not the old budget's checkpoint (0)
    r.set(K2_BUDGET + "org-a", 3000)  # spent under the NEW budget, checkpointed, flushed again
    rh.checkpoint()
    r.flushall()
    rh.check_once()
    assert int(r.get(K2_BUDGET + "org-a")) == 3000


def test_a_lost_budget_counter_write_is_repaired_but_never_over_a_newer_one() -> None:
    server, r, _ = _stores()
    db = MemDB()
    w = StateWriter(db, r, K)
    _seed(w)
    r.set(K2_BUDGET + "org-a", 7)
    server.connected = False
    v = w.budget_set("org-a", 5000)  # durable in Postgres; the counter write is lost
    server.connected = True
    rh = Rehydrator(db, r, w, period_ms=100, checkpoint_s=5)
    stale = rh.budget_repairs()
    assert [(org, mode, value) for org, mode, value, _, _ in stale] == [("org-a", "reset", 5000)]
    w.budget_set("org-a", 6000)  # a newer budget_set lands before that repair is applied
    org, mode, value, ver, tag = stale[0]
    assert rh._cas(keys=[K2_BUDGET + org, K2_BUDGET_GEN + org], args=[tag, value, str(ver), mode]) == 0
    assert int(r.get(K2_BUDGET + "org-a")) == 6000  # compare-and-set on the version tag: not overwritten
    r.set(K2_BUDGET_GEN + "org-a", str(v))  # the counter of an older budget again (5000 < 6000's version)
    assert rh.repair_budgets() == ["org-a:reset"] and int(r.get(K2_BUDGET + "org-a")) == 6000
    r.delete(K2_BUDGET_GEN + "org-b")  # an untagged counter is adopted, never rewritten
    r.set(K2_BUDGET + "org-b", 42)
    assert rh.repair_budgets() == ["org-b:gen"] and int(r.get(K2_BUDGET + "org-b")) == 42


def test_write_outcomes_are_reported_honestly() -> None:
    """ok / ok_publish_pending (committed, publish failed: e.g. Postgres failed over after the commit and the
    publish could not re-read it) / unknown (acknowledgement of COMMIT lost) / error (nothing committed)."""
    _, r, _ = _stores()
    db = MemDB()
    w = StateWriter(db, r, K)
    _seed(w)
    v = w.killswitch("org", "org-b", True)
    assert w.last["status"] == "ok" and w.last["version"] == str(v) and len(w.last["hash"]) == 64
    real = db.snapshot

    def failover(kind: str) -> Any:
        raise RuntimeError("connection failed: server closed the connection unexpectedly")  # not a redis/OS error

    db.snapshot = failover  # type: ignore[method-assign]
    v2 = w.killswitch("org", "org-b", False)  # must NOT raise: it is committed
    db.snapshot = real  # type: ignore[method-assign]
    assert w.last["status"] == "ok_publish_pending" and "re-hydrator" in w.last["note"]
    assert any(x["key"] == "org:org-b" and not x["body"]["on"] and x["seq"] == v2.seq for x in db.records("ks"))
    db.commit_unknown_next = True
    with pytest.raises(CommitUnknown):
        w.killswitch("org", "org-b", True)
    assert w.last["status"] == "unknown" and db.version("ks") > v2  # (in the twin it did commit)
    db.fail_next = True
    with pytest.raises(ConnectionError):
        w.killswitch("global", None, True)
    assert w.last["status"] == "error"
    assert not any(x["key"] == "global" and x["body"]["on"] for x in db.records("ks"))


async def test_gap_503s_carry_retry_after() -> None:
    """C36 gap answers (stale kill switch, store unavailable, plan unavailable) tell the client when to retry:
    the re-hydration period plus one gateway refresh period, at least 1 s."""
    _, r, ar = _stores()
    w = StateWriter(MemDB(), r, K)
    _seed(w)
    vid, vks, _ = _readers(ar)
    ra = posture.gap_retry_after_s(durable=True, rehydrate_period_ms=1000, refresh_ms=1000)
    assert ra == 2.0 and posture.gap_retry_after_s(durable=False, rehydrate_period_ms=1000, refresh_ms=1000) is None
    adm = Admission(vid, vks, Gcra(), TokenLease(ar, Registry(0), chunk_tokens=100, durable=True), ra)  # type: ignore[arg-type]
    stale = await adm.admit(KEY_A, 10, "gpt-4o-mini")  # never refreshed: the kill-switch snapshot is stale
    assert isinstance(stale, ErrorSpec) and stale.code == "kill_switch_unavailable" and stale.retry_after_s == 2.0
    await vks.refresh_once()
    r.flushall()
    gone = await adm.admit(KEY_A, 10, "gpt-4o-mini")  # an uncached key while the store is empty
    assert isinstance(gone, ErrorSpec) and gone.code == "shared_state_unavailable" and gone.retry_after_s == 2.0
    assert posture.gap(posture.PLAN_UNAVAILABLE, ra).retry_after_s == 2.0


def test_failed_postgres_transaction_publishes_nothing() -> None:
    _, r, _ = _stores()
    db = MemDB()
    w = StateWriter(db, r, K)
    _seed(w)
    before = r.get(K2_META + "ks")
    db.fail_next = True
    with pytest.raises(ConnectionError):
        w.killswitch("global", None, True)
    assert r.get(K2_META + "ks") == before and db.version("ks") == verify_meta_version(before)


def verify_meta_version(raw: bytes | None) -> Version:
    m = verify_meta(K, "ks", raw, not_before=Version(0, 0))
    return Version(m["epoch"], m["seq"])


@settings(max_examples=60, deadline=None)
@given(st.lists(st.tuples(st.sampled_from(["global", "org:a", "org:b", "model:m"]), st.booleans()), min_size=1,
                max_size=25))
def test_versions_strictly_increase_and_manifest_covers_every_write(ops: list[tuple[str, bool]]) -> None:
    db = MemDB()
    r = fakeredis.FakeRedis()
    w = StateWriter(db, r, K)
    seen = Version(0, 0)
    for scope, on in ops:
        kind, _, name = scope.partition(":")
        v = w.killswitch(kind, name or None, on) if kind != "global" else w.killswitch("global", None, on)
        assert v > seen
        seen = v
        meta = verify_meta(K, "ks", r.get(K2_META + "ks"), not_before=seen)
        assert Version(meta["epoch"], meta["seq"]) == seen
    final = {k: v for k, v in ops}
    stored = {x["key"]: x["body"]["on"] for x in db.records("ks")}
    assert stored == final


def test_manifest_digest_detects_a_missing_record() -> None:
    recs = [make_record(K, "ks", f"org:o{i}", {"on": False}, Version(1, i + 1)) for i in range(3)]
    meta = make_meta(K, "ks", Version(1, 3), recs)
    from rvproto.runtime.versioned import verify_set

    assert len(verify_set(K, "ks", meta, [orjson.dumps(x) for x in recs])) == 3
    with pytest.raises(StoreDataUnavailable, match="does not match"):
        verify_set(K, "ks", meta, [orjson.dumps(x) for x in recs[:2]])
