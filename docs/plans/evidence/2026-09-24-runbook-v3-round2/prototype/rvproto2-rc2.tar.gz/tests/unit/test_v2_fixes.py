"""rvproto-2 fixes C38 / C10 / C43 (+ discovery, drain wire) at unit level; property tests where natural."""

from __future__ import annotations

import asyncio
import gc
import json
import multiprocessing
import os
import random
import subprocess
import threading
import time
from pathlib import Path

import fakeredis
import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from rvproto.admit.deadline import DeadlineController, FixedDeadline
from rvproto.admit.overload import LoadGate
from rvproto.detect.guard import discovery, wire
from rvproto.detect.guard.ipc_client import OwnerClientBackend
from rvproto.detect.guard.owner_queue import Entry, OwnerQueue
from rvproto.runtime.config import load_settings
from rvproto.runtime.exporter import NodeExporter, Segment
from rvproto.runtime.loopguard import install_gc_probe, tune_gc
from rvproto.runtime.metrics import Registry
from rvproto.runtime.shm_metrics import SHM_DIR, ShmRegistry, make_registry

TAG = f"v2t{os.getpid()}"


# ---------------- C38: metrics off the serving loop ----------------

@settings(max_examples=40, deadline=None)
@given(st.lists(st.integers(min_value=0, max_value=10**12), min_size=1, max_size=300),
       st.lists(st.tuples(st.sampled_from(["a", "b{x=\"1\"}", "c"]), st.integers(1, 1000)), max_size=50))
def test_shm_registry_exports_exactly_what_the_frozen_registry_would(values: list[int], incs: list[tuple[str, int]]) -> None:
    shm = ShmRegistry(7, tag=TAG, role="w", slots=(8, 16, 16))
    ref = Registry(7)
    try:
        for v in values:
            shm.observe("t_ns", v)
            ref.observe("t_ns", v)
        for name, by in incs:
            shm.inc(name, by)
            ref.inc(name, by)
        seg = Segment(shm.path).export()
        want = ref.export()
        assert seg["hist"] == want["hist"] and seg["count"] == want["count"]
        assert shm.export()["hist"] == want["hist"]  # the in-process view agrees too
    finally:
        shm.close()


def test_shm_gauges_slots_are_reused_and_overflow_degrades_locally() -> None:
    shm = ShmRegistry(1, tag=TAG, role="w", slots=(1, 2, 2))
    try:
        shm.set("g1", 1.0)
        shm.set("g2", 2.0)
        del shm.gauge["g1"]
        shm.set("g3", 3.0)  # reuses g1's slot
        shm.set("g4", 4.0)  # no slot left: process-local, never an exception
        assert Segment(shm.path).export()["gauge"] == {"g2": 2.0, "g3": 3.0}
        shm.observe("h1", 5)
        shm.observe("h2", 6)  # histogram slots exhausted: local
        shm.inc("c1")
        shm.inc("c2")
        shm.inc("c3")
        assert shm.count["metrics_slot_overflow"] >= 1 and shm.count["c3"] == 1
    finally:
        shm.close()


def test_exporter_dumps_on_a_processes_request_and_renders_prometheus(tmp_path: Path) -> None:
    tag = f"{TAG}x"
    shm = ShmRegistry(0, tag=tag, role="w", slots=(8, 16, 16))
    exp = NodeExporter(tag=tag, kind="gateway", metrics_dir=str(tmp_path), dump_s=0, host="127.0.0.1", port=0,
                       export_s=60, draining=lambda: False, push=None)
    try:
        shm.observe("loop_lag_ns", 1500)
        shm.inc("admitted", 3)
        exp.start()
        shm.request_dump()  # what the SIGUSR1 handler does: one word written
        path = tmp_path / "worker-0.json"
        for _ in range(100):
            if path.exists():
                break
            asyncio.run(asyncio.sleep(0.02))
        d = json.loads(path.read_text())
        assert d["count"]["admitted"] == 3 and d["hist"]["loop_lag_ns"]["n"] == 1 and d["pid"] == os.getpid()
        assert "rv_admitted_total 3" in exp.render()
    finally:
        exp.stop()
        shm.close()
        exp.cleanup()


def _flip_buckets(path: str, h_off: int, seconds: float) -> None:
    """Child process: keep turning bucket words zero / non-zero in histogram slot 0 of a live segment."""
    import mmap
    import struct

    fd = os.open(path, os.O_RDWR)
    mm = mmap.mmap(fd, 0)
    end, v = time.monotonic() + seconds, 0
    while time.monotonic() < end:
        v ^= 1
        for k in range(64):
            mm[h_off + (4 + k) * 8 : h_off + (5 + k) * 8] = struct.pack("<q", v * (k + 1))
    mm.close()
    os.close(fd)


def test_exporter_reads_a_segment_while_its_process_writes_it() -> None:
    shm = ShmRegistry(5, tag=f"{TAG}f", role="w", slots=(2, 2, 2))
    shm.observe("h", 7)
    seg = Segment(shm.path)
    child = multiprocessing.get_context("fork").Process(target=_flip_buckets, args=(str(shm.path), seg.h_off, 1.0))
    child.start()
    n = 0
    try:
        while child.is_alive():
            seg.export()  # reads a private copy of each histogram: never "array changed during call"
            n += 1
    finally:
        child.join()
        shm.close()
    assert child.exitcode == 0 and n > 50


def test_exporter_loops_survive_errors_and_readiness_still_arrives(tmp_path: Path) -> None:
    tag = f"{TAG}e"
    shm = ShmRegistry(0, tag=tag, role="w", slots=(4, 4, 4))
    shm.set("worker_ready", 1.0)
    exp = NodeExporter(tag=tag, kind="gateway", metrics_dir=str(tmp_path), dump_s=0, host="127.0.0.1", port=0,
                       export_s=60, draining=lambda: False, push=None, expect_workers=1)
    real, fails = exp.refresh, [3]

    def flaky() -> list[Segment]:
        if fails[0]:
            fails[0] -= 1
            raise RuntimeError("number of non-zero array elements changed during function execution.")
        return real()

    exp.refresh = flaky  # type: ignore[method-assign]
    node = Path(SHM_DIR) / f"rv2-node-{tag}.json"
    try:
        exp.start()
        for _ in range(100):
            if node.exists():
                break
            time.sleep(0.02)
        assert json.loads(node.read_text())["ready"] is True and exp.loop_errors == 3
    finally:
        exp.stop()
        shm.close()
        exp.cleanup()


def test_exporter_prunes_dump_files_of_processes_that_are_gone(tmp_path: Path) -> None:
    gone = subprocess.Popen(["true"])
    gone.wait()
    (tmp_path / "worker-5.json").write_text(json.dumps({"worker": 5, "pid": gone.pid, "gauge": {}}))  # a previous run
    (tmp_path / "owner-1.json").write_text(json.dumps({"worker": 1, "pid": gone.pid, "gauge": {}}))
    (tmp_path / "worker-0.json").write_text(json.dumps({"worker": 0, "pid": os.getpid(), "gauge": {}}))
    (tmp_path / "notes.json").write_text("{}")
    exp = NodeExporter(tag=f"{TAG}p", kind="gateway", metrics_dir=str(tmp_path), dump_s=0, host="127.0.0.1", port=0,
                       export_s=60, draining=lambda: False, push=None)
    assert exp.prune_dumps() == 2
    assert sorted(p.name for p in tmp_path.iterdir()) == ["notes.json", "worker-0.json"]


def test_concurrent_dumps_never_fail(tmp_path: Path) -> None:
    """The dump loop, GET /dump and SIGUSR1 dump from different threads (they shared one temporary name)."""
    tag = f"{TAG}d"
    shm = ShmRegistry(0, tag=tag, role="w", slots=(4, 4, 4))
    exp = NodeExporter(tag=tag, kind="gateway", metrics_dir=str(tmp_path), dump_s=0, host="127.0.0.1", port=0,
                       export_s=60, draining=lambda: False, push=None)
    errors: list[BaseException] = []

    def hammer() -> None:
        try:
            for _ in range(200):
                exp.dump()
        except BaseException as exc:  # noqa: BLE001
            errors.append(exc)

    threads = [threading.Thread(target=hammer) for _ in range(4)]
    try:
        for t in threads:
            t.start()
        for t in threads:
            t.join()
    finally:
        shm.close()
    assert not errors and json.loads((tmp_path / "worker-0.json").read_text())["pid"] == os.getpid()
    assert sorted(p.name for p in tmp_path.iterdir()) == ["worker-0.json"]


def _parse_prometheus(text: str) -> dict[tuple[str, frozenset[tuple[str, str]]], float]:
    """The real parser (prometheus_client) must accept every line; no series may appear twice."""
    from prometheus_client.parser import text_string_to_metric_families

    seen: dict[tuple[str, frozenset[tuple[str, str]]], float] = {}
    for fam in text_string_to_metric_families(text):
        for smp in fam.samples:
            key = (smp.name, frozenset(smp.labels.items()))
            assert key not in seen, f"duplicate series {key}"
            seen[key] = smp.value
    assert len(seen) == sum(1 for line in text.splitlines() if line.strip()), "a line was not parsed as one sample"
    return seen


def test_exporter_metrics_are_valid_prometheus_text_for_gateway_unit_and_guard(tmp_path: Path) -> None:
    """rc1 emitted `rv_gc_pause_ns{gen="0"}{stat="n"}` (two label sets): managed Prometheus rejected the scrape."""
    for kind, roles in (("gateway", ("w",)), ("unit", ("w", "o")), ("guard", ("o",))):
        tag = f"{TAG}p{kind[0]}"
        segs = []
        for i, role in enumerate(r for r in roles for _ in range(2)):
            shm = ShmRegistry(i % 2, tag=tag, role=role, slots=(8, 16, 16))
            shm.observe('gc_pause_ns{gen="0"}', 12_000)
            shm.observe("loop_lag_ns", 900)
            shm.inc('owner_shed_reason{reason="standing_queue"}', 2)
            shm.inc("admitted", 5)
            shm.set('plan_version_info{org="org-b",version="b-2"}', 1.0)
            shm.set("active_streams", 3.0)
            segs.append(shm)
        exp = NodeExporter(tag=tag, kind=kind, metrics_dir="", dump_s=0, host="127.0.0.1", port=0,
                           export_s=60, draining=lambda: False, push=None)
        exp.signals = {"requests_per_s": 12.5, "owner_queue_windows_avg": 0.4}
        try:
            got = _parse_prometheus(exp.render())
        finally:
            for shm in segs:
                shm.close()
        assert got[("rv2_signal", frozenset({("kind", kind), ("name", "requests_per_s")}))] == 12.5
        if "w" in roles:
            assert got[("rv_gc_pause_ns", frozenset({("gen", "0"), ("stat", "n")}))] == 2.0
            assert got[("rv_owner_shed_reason_total", frozenset({("reason", "standing_queue")}))] == 4.0
            assert got[("rv_plan_version_info", frozenset({("org", "org-b"), ("version", "b-2"), ("worker", "1")}))] == 1.0
        if "o" in roles:
            assert got[("rv_admitted_total", frozenset({("role", "owner")}))] == 10.0
            assert got[("rv_active_streams", frozenset({("role", "owner"), ("worker", "0")}))] == 3.0


def test_c38_off_keeps_the_frozen_registry_and_tokenizer_setting() -> None:
    s = load_settings({"RV_FIX_C38": "off"})
    assert type(make_registry(0, on=s.v2.c38.on, tag=TAG, role="w", slots=(1, 1, 1))) is Registry
    assert not s.tokenize_in_thread and load_settings({}).tokenize_in_thread
    assert load_settings({"RV_TOKENIZE_IN_THREAD": "0"}).tokenize_in_thread is False  # explicit override wins


def test_gc_probe_records_pauses_and_tuning_freezes() -> None:
    reg = Registry(0)
    install_gc_probe(reg)
    try:
        gc.collect()
        assert sum(reg.h(f'gc_pause_ns{{gen="{g}"}}').n for g in (0, 1, 2)) >= 1
        applied = tune_gc(load_settings({"RV_GC_THRESHOLD": "70000,20,30"}))
        assert applied["gc_threshold"] == (70000, 20, 30) and int(applied["gc_frozen"]) > 0  # type: ignore[call-overload]
    finally:
        gc.callbacks.clear()
        gc.unfreeze()
        gc.set_threshold(700, 10, 10)


# ---------------- C10: owner-level admission ----------------

@settings(max_examples=80, deadline=None)
@given(st.lists(st.tuples(st.sampled_from([512, 1024, 1536]), st.floats(0.002, 0.030), st.booleans()),
                min_size=1, max_size=60))
def test_bound_admission_admits_only_what_finishes_within_budget_and_bound(events: list[tuple[int, float, bool]]) -> None:
    """rc1's rule (RV_OWNER_ADMISSION=bound): admitted into a non-empty queue => predicted wait + own execution
    <= its budget AND the backlog stays within RV_OWNER_QUEUE_MS; every refusal is a SHED carrying the backlog's
    drain time."""
    s = load_settings({"RV_OWNER_ADMISSION": "bound", "RV_OWNER_QUEUE_MS": "12"})
    tps = 240_000.0
    q = OwnerQueue(s, Registry(0), tokens_per_s=tps, frozen_cap_tokens=10**9)
    admitted: list[Entry] = []
    for cost, budget_s, finish_one in events:
        before = q.queued_tokens
        est = q.backlog_ns() / 1e9  # the owner's own estimate (running item's progress subtracted)
        assert est <= before / tps + 1e-9
        res = q.admit(cost, cost // 512, int(budget_s * 1e9))
        if isinstance(res, Entry):
            if before:
                assert est + cost / tps <= budget_s + 1e-4  # (the clock moved a little between the two reads)
                assert before + cost <= q.cap_tokens
            admitted.append(res)
        else:
            assert before > 0 and res >= cost / tps - 1e-12 and res <= max(before, cost) / tps + 1e-9
        if finish_one and admitted:
            q.finish(admitted.pop(0))
    assert q.queued_tokens == sum(e.cost for e in admitted)


def test_c10_off_restores_the_frozen_owner_bound_without_budget_check() -> None:
    q = OwnerQueue(load_settings({"RV_FIX_C10": "off"}), Registry(0), tokens_per_s=1000.0, frozen_cap_tokens=5000)
    assert q.cap_tokens == 5000 and isinstance(q.admit(512, 1, 10**12), Entry)
    assert isinstance(q.admit(512, 1, 1), Entry)  # frozen-1 never checks the request's budget


TPS = 240_000.0  # an L4 on PG2-22M: 2.13 ms per 512-token window


def _simulate(q: OwnerQueue, arrivals: list[tuple[int, int]], budget_ns: int = 10**9) -> tuple[int, list[int], list[float]]:
    """Discrete-event run of one owner (FIFO, one executor, service = cost / rate) on a virtual clock.
    Returns (sheds, sojourn of every admitted request in ns, Retry-After of every shed)."""
    now = [0]
    q.clock = lambda: now[0]
    q._t = 0
    queue: list[Entry] = []
    sheds, sojourns, retry = 0, [], []
    i = 0
    while i < len(arrivals) or queue:
        done = queue[0].started_ns + int(queue[0].cost / q.tps * 1e9) if queue else None
        if i < len(arrivals) and (done is None or arrivals[i][0] < done):
            now[0], cost = arrivals[i]
            res = q.admit(cost, cost // 512, budget_ns)
            if isinstance(res, Entry):
                queue.append(res)
            else:
                sheds += 1
                retry.append(res)
            i += 1
        else:
            assert done is not None
            now[0] = done
            e = queue.pop(0)
            sojourns.append(e.started_ns - e.queued_ns)
            q.finish(e)
    return sheds, sojourns, retry


def _poisson(rho: float, seconds: float, seed: int) -> list[tuple[int, int]]:
    """Poisson arrivals of 1-3-window requests (mean 1.6 windows) at utilisation rho of one TPS owner."""
    rng = random.Random(seed)
    sizes = [512, 512, 512, 1024, 1536]
    rate = rho * TPS / (sum(sizes) / len(sizes))
    t, out = 0.0, []
    while t < seconds:
        t += rng.expovariate(rate)
        out.append((int(t * 1e9), rng.choice(sizes)))
    return out


def test_codel_absorbs_poisson_bursts_that_the_rc1_bound_sheds() -> None:
    """rho 0.45 Poisson (bursts, no standing queue): codel sheds nothing; rc1's 12 ms bound sheds ordinary
    bursts (the r2unit / r2fleet finding) -- same arrivals."""
    for seed in range(3):
        arrivals = _poisson(0.45, 30.0, seed)
        codel = OwnerQueue(load_settings({}), Registry(0), tokens_per_s=TPS, frozen_cap_tokens=0)
        sheds, sojourns, _ = _simulate(codel, arrivals)
        assert sheds == 0 and not codel.overloaded
        bound = OwnerQueue(load_settings({"RV_OWNER_ADMISSION": "bound"}), Registry(0), tokens_per_s=TPS,
                           frozen_cap_tokens=0)
        assert _simulate(bound, arrivals, budget_ns=int(13e6))[0] > 0
        assert sorted(sojourns)[int(0.99 * len(sojourns))] < 20e6  # what the bursts cost: late, never lost


def test_codel_sheds_a_standing_queue_and_bounds_admitted_waits() -> None:
    """Sustained 2x overload: sheds (503 + Retry-After >= own execution), every admitted wait <= the hard cap,
    and once the standing queue is detected the admitted waits stay near the target."""
    arrivals = _poisson(2.0, 10.0, 7)
    q = OwnerQueue(load_settings({}), Registry(0), tokens_per_s=TPS, frozen_cap_tokens=0)
    sheds, sojourns, retry = _simulate(q, arrivals)
    assert 0.4 < sheds / len(arrivals) < 0.6  # about the excess
    assert max(sojourns) <= 60e6 + 1536 / TPS * 1e9  # the hard cap (one request may start over it)
    steady = sojourns[len(sojourns) // 10:]  # after the onset (the detector needs one interval)
    assert sorted(steady)[int(0.99 * len(steady))] <= 5e6 + 1536 / TPS * 1e9
    assert min(retry) >= 512 / TPS - 1e-12


@settings(max_examples=60, deadline=None)
@given(st.lists(st.tuples(st.integers(0, 8_000_000), st.sampled_from([512, 1024, 1536, 4096])), min_size=1,
                max_size=300))
def test_codel_never_sheds_a_request_that_would_wait_less_than_the_target(events: list[tuple[int, int]]) -> None:
    """Any arrival pattern: a request whose predicted wait is under the target is shed only by the hard cap;
    admitted waits never exceed the cap; the books balance."""
    arrivals, t = [], 0
    for gap, cost in events:
        t += gap
        arrivals.append((t, cost))
    q = OwnerQueue(load_settings({}), Registry(0), tokens_per_s=TPS, frozen_cap_tokens=0)
    now = [0]
    q.clock = lambda: now[0]
    q._t = 0
    queue: list[Entry] = []
    for at, cost in arrivals:
        while queue and queue[0].started_ns + int(queue[0].cost / TPS * 1e9) <= at:
            now[0] = queue[0].started_ns + int(queue[0].cost / TPS * 1e9)
            q.finish(queue.pop(0))
        now[0] = at
        wait, before = q.backlog_ns(at), q.queued_tokens
        res = q.admit(cost, cost // 512, 10**9)
        if isinstance(res, Entry):
            queue.append(res)
            assert not before or before + cost <= q.cap_tokens
        else:
            assert before + cost > q.cap_tokens or wait >= q.target_ns
    assert q.queued_tokens == sum(e.cost for e in queue)


def test_deadline_is_derived_from_the_budget_and_bounded() -> None:
    reg = Registry(0)
    d = DeadlineController(reg, slo_ms=20, margin_ms=2, min_ms=4, window_s=0.0, fixed_ms=None)
    assert d.current_ms() == 20 - 5 - 2  # before a window: non-guard p99 assumed SLO/4
    for _ in range(1000):
        d.observe(3_000_000)  # 3 ms non-guard work
    d.observe(0)  # rotates the (zero-length) window
    assert d.current_ms() == pytest.approx(20 - 3.05 - 2, abs=0.06)
    for _ in range(1000):
        d.observe(30_000_000)
    d.observe(0)
    assert d.current_ms() == 4  # never below the floor
    pinned = DeadlineController(reg, slo_ms=20, margin_ms=2, min_ms=4, window_s=0.0, fixed_ms=9.0)
    pinned.observe(1)
    pinned.observe(1)
    assert pinned.current_ms() == 9.0 and FixedDeadline(20.0).current_ms() == 20.0


def test_knobs_are_separate_from_the_amf_target() -> None:
    s = load_settings({"AMF_TARGET_P99_MS": "1000", "RV_OWNER_QUEUE_MS": "7", "RV_STORE_TIMEOUT_MS": "30",
                       "RV_INPUT_QUEUE_CAP": "5", "RV_SLO_MS": "20"})
    assert (s.v2.c10.owner_queue_ms, s.v2.c10.store_timeout_ms, s.v2.c10.input_queue_cap, s.v2.c10.slo_ms) == (7, 30, 5, 20)


def test_per_worker_guard_share_is_advisory_under_c10() -> None:
    reg = Registry(0)
    gate = LoadGate(reg, inflight_cap=100)
    gate.configure_guard(input_cap=None, guard_cap_tokens=512, tokens_per_s=1e5, advisory=True)
    assert gate.take_guard(512) is None and gate.take_guard(512) is None  # frozen-1 would shed the second
    assert reg.count["guard_share_exceeded_advisory"] == 1
    gate2 = LoadGate(reg, inflight_cap=100)
    gate2.configure_guard(input_cap=None, guard_cap_tokens=512, tokens_per_s=1e5, advisory=False)
    assert gate2.take_guard(512) is None and gate2.take_guard(512) is not None


# ---------------- C43: load-aware routing ----------------

class _FakeLink:
    def __init__(self, name: str, est: int, *, draining: bool = False) -> None:
        self.name, self._est, self.draining, self.removed, self.writer = name, est, draining, False, object()

    def estimate_ns(self, now: int) -> int:
        return self._est

    def routable(self) -> bool:
        return not self.draining


def test_routing_picks_the_least_estimated_backlog_with_random_ties() -> None:
    s = load_settings({"RV_GUARD_ROUTE_EPS_US": "250"})
    b = OwnerClientBackend(s, Registry(0), endpoints=[], sharing=1, model_hash="h", name="t")
    links = [_FakeLink("a", 5_000_000), _FakeLink("b", 100_000), _FakeLink("c", 300_000)]
    picks = {b._choose(links).name for _ in range(200)}  # type: ignore[arg-type]
    assert picks == {"b", "c"}  # c is within 250 us of b: a tie; a is never chosen
    off = OwnerClientBackend(load_settings({"RV_FIX_C43": "off"}), Registry(0), endpoints=[], sharing=1,
                             model_hash="h", name="t")
    for x in links:
        x.windows = 0  # type: ignore[attr-defined]
    assert [off._choose(links).name for _ in range(3)] == ["a", "b", "c"]  # type: ignore[arg-type]


def test_state_frames_and_redirect_roundtrip() -> None:
    geo = wire.Geometry(16, 512)
    rid, res = wire.decode_response(wire.encode_state(1_234_567, 5, True)[4:], geo)
    assert rid == wire.STATE_ID and res.queue_ns == 1_234_567 and res.exec_ns == 5 and res.detail == "D"
    rid, res = wire.decode_response(wire.encode_redirect(9, "guard owner draining")[4:], geo)
    assert rid == 9 and not res.ok and res.detail.startswith("redirect:")
    with pytest.raises(wire.FrameError):
        body = bytearray(wire.encode_state(1, 1, False)[4:])
        body[0:4] = (7).to_bytes(4, "little")  # a state frame with a request id
        wire.decode_response(bytes(body), geo)


# ---------------- discovery ----------------

async def test_registration_discovery_and_draining_exclusion() -> None:
    server = fakeredis.FakeServer()
    r = fakeredis.aioredis.FakeRedis(server=server)
    regs = []
    for port in (7070, 7071):
        reg = discovery.OwnerRegistration("redis://unused", advertise=("10.0.0.5", port),
                                          hello={"index": 0, "pid": 1, "tokens_per_s": 2e5, "model_hash": "m"},
                                          ttl_ms=300)
        reg.r = fakeredis.aioredis.FakeRedis(server=server)
        await reg.beat()
        regs.append(reg)
    seen: list[list[str]] = []
    task = asyncio.create_task(discovery.watch(r, period_s=0.05, model_hash="m",
                                               apply=lambda eps, tps: seen.append(sorted(str(e) for e in eps))))
    try:
        await asyncio.sleep(0.12)
        assert seen[-1] == ["10.0.0.5:7070", "10.0.0.5:7071"]
        await regs[0].draining()  # a draining owner is dropped at the next poll
        await asyncio.sleep(0.12)
        assert seen[-1] == ["10.0.0.5:7071"]
        await asyncio.sleep(0.4)  # both TTLs lapse without heartbeats: gone
        assert seen[-1] == [] and not await r.smembers("{rv2}:guard:owners")
    finally:
        task.cancel()


async def test_client_adds_and_retires_endpoints_live() -> None:
    s = load_settings({})
    b = OwnerClientBackend(s, Registry(0), endpoints=[], sharing=1, model_hash="h", name="t")
    b.set_endpoints([wire.Endpoint("tcp", "10.0.0.1", 7070), wire.Endpoint("tcp", "10.0.0.2", 7070)])
    assert sorted(x.name for x in b.links) == ["10.0.0.1:7070", "10.0.0.2:7070"]
    b.set_endpoints([wire.Endpoint("tcp", "10.0.0.2", 7070)])
    retired = [x for x in b.links if x.name == "10.0.0.1:7070"]
    assert not retired or retired[0].removed  # retired: no new work, closed once idle
    await b.close()


class _Conn:
    def close(self) -> None:
        return None

    def is_closing(self) -> bool:
        return False


async def test_a_connected_owner_is_kept_when_its_registration_vanishes() -> None:
    """A flushed / failed-over store loses every registration at once: routing must not lose the fleet."""
    b = OwnerClientBackend(load_settings({}), Registry(0), endpoints=[], sharing=1, model_hash="h", name="t")
    b.set_endpoints([wire.Endpoint("tcp", "10.0.0.1", 7070), wire.Endpoint("tcp", "10.0.0.2", 7070)])
    up = next(x for x in b.links if x.name == "10.0.0.1:7070")
    up.writer = _Conn()  # type: ignore[assignment]  # connected; 10.0.0.2 is down
    b.set_endpoints([])
    assert [x.name for x in b.links if not x.removed] == ["10.0.0.1:7070"]
    assert b.metrics.count["guard_owner_kept_unregistered"] == 1
    up.draining = True  # a draining owner deregisters on exit: that one goes
    b.set_endpoints([])
    assert up.removed
    await b.close()


def test_connection_lifetime_limits_close_after_n_requests_or_t_seconds() -> None:
    """RV_CONN_MAX_REQUESTS / RV_CONN_MAX_AGE_S: the request crossing the threshold is answered with
    `connection: close`; the client's next connection starts afresh; off by default."""
    from rvproto.edge.connlimit import ConnLimits

    assert not ConnLimits(Registry(0), max_requests=0, max_age_s=0, keepalive_s=75).should_close(("10.0.0.9", 5), 0.0)
    m = Registry(0)
    by_n = ConnLimits(m, max_requests=3, max_age_s=0, keepalive_s=75)
    assert [by_n.should_close(("10.0.0.9", 5000), t) for t in (0.0, 0.1, 0.2, 0.3)] == [False, False, True, False]
    assert m.count["conn_closed_max_requests"] == 1
    by_t = ConnLimits(m, max_requests=0, max_age_s=30, keepalive_s=75)
    assert not by_t.should_close(("10.0.0.9", 5001), 0.0) and not by_t.should_close(("10.0.0.9", 5001), 29.9)
    assert by_t.should_close(("10.0.0.9", 5001), 30.0) and not by_t.should_close(("10.0.0.9", 5001), 30.1)
    assert not by_t.should_close(("10.0.0.9", 5002), 0.0)
    assert not by_t.should_close(("10.0.0.9", 5002), 200.0)  # idle past keep-alive: a new connection on that port
    assert by_t.should_close(None, 1.0) is False  # (no client address: never)


async def test_closing_wrapper_adds_connection_close_to_the_response_start() -> None:
    from rvproto.edge.app import _closing

    sent: list[dict[str, object]] = []

    async def send(msg: dict[str, object]) -> None:
        sent.append(msg)

    wrapped = _closing(send)
    await wrapped({"type": "http.response.start", "status": 200, "headers": [(b"content-type", b"text/event-stream")]})
    await wrapped({"type": "http.response.body", "body": b"data: x\n\n", "more_body": True})
    assert (b"connection", b"close") in sent[0]["headers"] and "headers" not in sent[1]  # type: ignore[operator]


def test_rng_is_not_shared_between_workers() -> None:
    a = OwnerClientBackend(load_settings({}), Registry(0), endpoints=[], sharing=1, model_hash="h", name="t")
    b = OwnerClientBackend(load_settings({}), Registry(0), endpoints=[], sharing=1, model_hash="h", name="t")
    assert a._rng is not b._rng and isinstance(a._rng, random.Random)
