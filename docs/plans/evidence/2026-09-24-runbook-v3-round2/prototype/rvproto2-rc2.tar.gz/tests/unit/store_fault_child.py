"""Child process of test_store_resilience.py: ONE store-fault scenario on uvloop (as the gateway workers run).

    python store_fault_child.py SCENARIO DEADLINE_S

Prints one JSON result line. A watchdog THREAD ends the process at the deadline with ok=false and what it saw
(the event loop may be blocked: that is the D2 failure). Runs against whichever rvproto tree is first on
sys.path, so the base tree reproduces D1/D2 with the same scenarios.
"""

from __future__ import annotations

import asyncio
import errno
import json
import os
import sys
import threading
import time
from collections.abc import Callable
from typing import Any

import redis
import uvloop

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from store_faults import Beat, FakeStore, PartitionProxy, keepalive_death, rss_mb  # noqa: E402

from rvproto.admit.admission import Admission  # noqa: E402
from rvproto.admit.quota import Gcra, TokenLease  # noqa: E402
from rvproto.admit.state_v2 import VersionedIdentity, VersionedKillSwitch  # noqa: E402
from rvproto.control.db import MemDB  # noqa: E402
from rvproto.control.writer import StateWriter, key_hash  # noqa: E402
from rvproto.domain.request import ErrorSpec  # noqa: E402
from rvproto.plan.fixtures import tenants  # noqa: E402
from rvproto.plan.snapshot_v2 import VersionedPlanSnapshot  # noqa: E402
from rvproto.runtime import store  # noqa: E402
from rvproto.runtime.metrics import Registry  # noqa: E402

K = b"test-hmac-key-not-a-secret"
KEY_A, KEY_B = "sk-rv-org-a-0001", "sk-rv-org-b-0001"
UVLOOP_CLOSED = "unable to perform operation on <TCPTransport closed=True reading=False 0x0>; the handler is closed"
BEAT = Beat()
SEEN: dict[str, Any] = {"phase": "start", "rss0": 0.0}


class _Contract:
    target_p99_ms = 20.0


class _Bounds:
    redis_connections = 8


def emit(**kw: Any) -> None:
    sys.stdout.write(json.dumps(kw, default=str) + "\n")
    sys.stdout.flush()


def watchdog(deadline_s: float) -> None:
    t_end = time.monotonic() + deadline_s
    while time.monotonic() < t_end:
        time.sleep(0.05)
    stall = time.monotonic() - BEAT.last
    emit(kind="result", ok=False, reason="deadline", phase=SEEN["phase"], loop_stalled_s=round(stall, 2),
         rss_mb=round(rss_mb(), 1), rss_delta_mb=round(rss_mb() - SEEN["rss0"], 1))
    os._exit(3)


def writer(url: str) -> StateWriter:
    w = StateWriter(MemDB(), redis.Redis.from_url(url), K)
    w.key_add(KEY_A, "org-a", key_id="key-a-1", rate=1e6, burst=1e6)
    w.key_add(KEY_B, "org-b", key_id="key-b-1", rate=1e6, burst=1e6)
    for org, doc in tenants().items():
        w.plan_set(doc)
        w.budget_set(org, 10**9)
        w.killswitch("org", org, False)
    w.killswitch("global", None, False)
    return w


def bg_client(url: str, m: Registry, timeout_s: float) -> Any:
    try:
        return store.connect_background(url, _Contract(), _Bounds(), timeout_s=timeout_s, events=m.inc)  # type: ignore[arg-type]
    except TypeError:  # base tree
        return store.connect_background(url, _Contract(), _Bounds())  # type: ignore[arg-type]


def rp_client(url: str, m: Registry, timeout_s: float) -> Any:
    try:
        return store.connect(url, _Contract(), _Bounds(), timeout_s=timeout_s, events=m.inc)  # type: ignore[arg-type]
    except TypeError:  # base tree
        return store.connect(url, _Contract(), _Bounds(), timeout_s=timeout_s)  # type: ignore[arg-type]


def snapshot(r: Any, m: Registry, ping_s: float, op_s: float) -> VersionedPlanSnapshot:
    try:
        from rvproto.runtime.push import PushKnobs
    except ImportError:  # base tree: listen()
        return VersionedPlanSnapshot(r, m, K, reconcile_ms=60000, stale_ms=120000)
    knobs = PushKnobs(ping_s=ping_s, backoff_s=(0.05, 0.3), drain_max=8, op_timeout_s=op_s)
    return VersionedPlanSnapshot(r, m, K, reconcile_ms=60000, stale_ms=120000, push=knobs)  # type: ignore[call-arg]


def track_pubsubs(r: Any) -> list[Any]:
    made: list[Any] = []
    orig = r.pubsub

    def pubsub(*a: Any, **k: Any) -> Any:
        ps = orig(*a, **k)
        made.append(ps)
        return ps

    r.pubsub = pubsub
    return made


async def until(pred: Callable[[], bool], timeout_s: float) -> bool:
    end = time.monotonic() + timeout_s
    while time.monotonic() < end:
        if pred():
            return True
        await asyncio.sleep(0.01)
    return pred()


def live(made: list[Any]) -> bool:
    return bool(made) and made[-1].connection is not None and made[-1].subscribed


async def pubsub_etimedout() -> dict[str, Any]:
    """D2: the subscribed pub/sub socket dies (keepalive ETIMEDOUT); a plan update published afterwards
    must still arrive by push (periodic reconcile is 60 s here), with the loop running and RSS flat."""
    fs = FakeStore()
    w, m = await asyncio.to_thread(writer, fs.url), Registry(0)  # blocking client: off the loop
    r = bg_client(fs.url, m, 0.5)
    made = track_pubsubs(r)
    snap = snapshot(r, m, ping_s=0.5, op_s=0.5)
    await snap.load_all()
    task = asyncio.create_task(snap.run())
    await until(lambda: live(made), 3.0)
    await asyncio.sleep(0.2)
    SEEN["rss0"], SEEN["phase"], BEAT.max_gap_ms = rss_mb(), "etimedout", 0.0
    keepalive_death(made[-1].connection)
    await asyncio.sleep(0.3)
    SEEN["phase"] = "publish"
    t_pub = time.monotonic()
    await asyncio.to_thread(w.plan_set, dict(tenants()["org-a"], version="a-after-fault"))
    ok = await until(lambda: snap.versions().get("org-a") == "a-after-fault", 5.0)
    applied_s = time.monotonic() - t_pub
    task.cancel()
    return dict(ok=ok, push_applied_s=round(applied_s, 3), rss_delta_mb=round(rss_mb() - SEEN["rss0"], 1),
                max_loop_gap_ms=round(BEAT.max_gap_ms, 1), pubsubs=len(made), counters=dict(m.count))


async def pubsub_partition() -> dict[str, Any]:
    """D2: a silent partition that outlives the pub/sub TCP connection (nothing sent, nothing closed). The
    listener must declare the connection dead by its own liveness PING, keep retrying (bounded) through the
    partition, and deliver again after the heal."""
    fs = FakeStore()
    proxy = PartitionProxy(fs.port)
    w, m = await asyncio.to_thread(writer, fs.url), Registry(0)
    r = bg_client(proxy.url, m, 0.3)
    made = track_pubsubs(r)
    snap = snapshot(r, m, ping_s=0.3, op_s=0.3)
    await snap.load_all()
    task = asyncio.create_task(snap.run())
    await until(lambda: live(made), 3.0)
    await asyncio.sleep(0.2)
    SEEN["rss0"], SEEN["phase"], BEAT.max_gap_ms = rss_mb(), "partition", 0.0
    proxy.partition()
    await asyncio.sleep(2.0)
    dead_in_partition, made_in_partition = m.count.get("pubsub_dead", 0), len(made)
    SEEN["phase"] = "healed"
    proxy.heal()
    t_heal = time.monotonic()
    await asyncio.to_thread(w.plan_set, dict(tenants()["org-a"], version="a-after-heal"))
    ok = await until(lambda: snap.versions().get("org-a") == "a-after-heal", 5.0)
    recovered_s = time.monotonic() - t_heal
    task.cancel()
    return dict(ok=ok, recovered_after_heal_s=round(recovered_s, 3), dead_in_partition=dead_in_partition,
                pubsubs_in_partition=made_in_partition, rss_delta_mb=round(rss_mb() - SEEN["rss0"], 1),
                max_loop_gap_ms=round(BEAT.max_gap_ms, 1), counters=dict(m.count))


class _FakePubSub:
    def __init__(self, owner: Any) -> None:
        self.owner = owner

    async def subscribe(self, channel: str) -> None:
        return None

    async def get_message(self, timeout: float | None = 0.0, **_: Any) -> dict[str, Any] | None:
        self.owner.reads += 1
        return {"type": "message", "data": b"plan"} if self.owner.flood else None  # never waits

    async def ping(self, *_: Any) -> None:
        return None

    async def aclose(self) -> None:
        return None


class _FakeRedis:
    def __init__(self, flood: bool) -> None:
        self.flood = flood
        self.made = 0
        self.reads = 0

    def pubsub(self) -> _FakePubSub:
        self.made += 1
        return _FakePubSub(self)


async def listener_client_bugs() -> dict[str, Any]:
    """Whatever the client library does: a get_message that answers "no message" without waiting (the D2
    signature) is a dead connection, and a message flood is taken DRAIN_MAX per wakeup, one nudge each; the
    event loop keeps running in both cases."""
    from rvproto.runtime.push import PushKnobs, PushListener

    out: dict[str, Any] = {}
    for flood in (False, True):
        m, fake, nudges = Registry(0), _FakeRedis(flood), [0]

        async def nudge() -> bool:
            nudges[0] += 1
            return True

        knobs = PushKnobs(ping_s=0.2, backoff_s=(0.01, 0.05), drain_max=8, op_timeout_s=0.1)
        task = asyncio.create_task(PushListener(fake, "ch", m, name="t", knobs=knobs).run(nudge, lambda msg: True))
        BEAT.max_gap_ms = 0.0
        await asyncio.sleep(1.0)
        task.cancel()
        out["flood" if flood else "no_wait"] = dict(dead=m.count.get("pubsub_dead", 0), pubsubs=fake.made,
                                                    reads=fake.reads, nudges=nudges[0],
                                                    max_loop_gap_ms=round(BEAT.max_gap_ms, 1))
    out["ok"] = True
    return out


async def d1_dead_pooled_connection() -> dict[str, Any]:
    """D1: a pooled request-path connection whose socket died (keepalive ETIMEDOUT) must not be handed out:
    the next store read reconnects instead of failing with uvloop's RuntimeError (HTTP 500)."""
    fs = FakeStore()
    await asyncio.to_thread(writer, fs.url)
    m = Registry(0)
    r = rp_client(fs.url, m, 0.25)
    vid = VersionedIdentity(r, K)
    first = await vid.fetch(key_hash(KEY_B))
    keepalive_death(r.connection_pool._available_connections[-1])
    await asyncio.sleep(0.05)
    try:
        p = await vid.fetch(key_hash(KEY_A))
        outcome = "principal" if p is not None else "none"
    except Exception as exc:  # noqa: BLE001 - the scenario reports what escaped
        outcome = f"raised {type(exc).__name__}: {exc}"
    return dict(ok=first is not None and outcome == "principal", outcome=outcome, counters=dict(m.count))


def _inject(fault: str, conn: Any) -> None:
    def raiser(exc: BaseException) -> Callable[..., Any]:
        def f(*_: Any, **__: Any) -> Any:
            raise exc

        return f

    async def aread(exc: BaseException) -> Any:
        raise exc

    if fault == "write_uvloop_closed":  # the exact D1 call site: self._writer.writelines(command)
        conn._writer.writelines = raiser(RuntimeError(UVLOOP_CLOSED))
    elif fault == "write_reset":
        conn._writer.writelines = raiser(ConnectionResetError(errno.ECONNRESET, "Connection reset by peer"))
    elif fault == "read_uvloop_closed":
        conn._reader.read = lambda *_a, **_k: aread(RuntimeError(UVLOOP_CLOSED))
    elif fault == "read_etimedout":
        conn._reader.read = lambda *_a, **_k: aread(TimeoutError(errno.ETIMEDOUT, os.strerror(errno.ETIMEDOUT)))
    elif fault == "keepalive_death":
        keepalive_death(conn)


async def _admit_once(fault: str, fs: FakeStore, proxy: PartitionProxy) -> str:
    m = Registry(0)
    url = {"store_refused": "redis://127.0.0.1:1/0", "store_silent": proxy.url}.get(fault, fs.url)
    r, rb = rp_client(url, m, 0.25), bg_client(fs.url, m, 0.5)
    vid = VersionedIdentity(r, K)
    vks = VersionedKillSwitch(rb, m, K, refresh_ms=500, stale_ms=5000, identity=vid)
    await vks.refresh_once()
    lease = TokenLease(r, m, chunk_tokens=10**6, durable=True)
    lease._local["org-a"] = 10**9  # fakeredis-over-TCP has no Lua: keep the lease off the store
    adm = Admission(vid, vks, Gcra(), lease)  # type: ignore[arg-type]
    if url == fs.url:
        await vid.fetch(key_hash(KEY_B))  # one live pooled connection to break
        _inject(fault, r.connection_pool._available_connections[-1])
        await asyncio.sleep(0.05)
    try:
        out = await adm.admit(KEY_A, 100, "gpt-4o-mini")
    except Exception as exc:  # noqa: BLE001 - an escaping exception is an HTTP 500
        return f"raised {type(exc).__name__}: {exc}"
    if isinstance(out, ErrorSpec):
        return f"{out.status}:{out.code}"
    return "grant"


async def d1_admission_faults() -> dict[str, Any]:
    """D1: every transport-level fault on the request path is 503 shared_state_unavailable (or, when the
    socket was already dead before the call, a transparent reconnect and a grant), never an exception."""
    fs = FakeStore()
    await asyncio.to_thread(writer, fs.url)
    proxy = PartitionProxy(fs.port)
    proxy.partition()
    faults = ("write_uvloop_closed", "write_reset", "read_uvloop_closed", "read_etimedout", "keepalive_death",
              "store_refused", "store_silent")
    outcomes = {f: await _admit_once(f, fs, proxy) for f in faults}
    return dict(ok=not any(o.startswith("raised") for o in outcomes.values()), outcomes=outcomes)


SCENARIOS = {f.__name__: f for f in (pubsub_etimedout, pubsub_partition, listener_client_bugs,
                                     d1_dead_pooled_connection, d1_admission_faults)}


async def main(name: str) -> None:
    asyncio.create_task(BEAT.run())
    res = await SCENARIOS[name]()
    emit(kind="result", scenario=name, **res)


if __name__ == "__main__":
    threading.Thread(target=watchdog, args=(float(sys.argv[2]),), daemon=True).start()
    uvloop.run(main(sys.argv[1]))
    os._exit(0)
