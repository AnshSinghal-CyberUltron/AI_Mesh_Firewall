"""D1/D2 (r2-chaos): a gateway<->store partition must never OOM a worker (pub/sub spin) nor surface as HTTP 500.

Scenario tests run in a child process on uvloop (store_fault_child.py) against a real TCP store (fakeredis):
a regression that spins the event loop cannot hang the session, and the child's watchdog reports what it
saw. The same scenarios on the pre-fix tree reproduce both defects (evidence/r2-fix-d2).
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any

import pytest
from redis.exceptions import ConnectionError as RedisConnectionError

from rvproto.detect.guard.discovery import OwnerRegistration
from rvproto.runtime.config import load_settings
from rvproto.runtime.metrics import Registry, prometheus
from rvproto.runtime.push import DEFAULT_PUSH, PushKnobs
from rvproto.runtime.store import StoreError, connect, connect_background
from rvproto.runtime.storeconn import RvConnection, RvSSLConnection, RvUnixConnection, client, sync_client

ROOT = Path(__file__).resolve().parents[2]
CHILD = Path(__file__).with_name("store_fault_child.py")


def _run(scenario: str, deadline_s: float = 20.0) -> dict[str, Any]:
    env = dict(os.environ, PYTHONPATH=os.pathsep.join(p for p in (str(ROOT), os.environ.get("PYTHONPATH")) if p))
    p = subprocess.run([sys.executable, str(CHILD), scenario, str(deadline_s)], capture_output=True, text=True,
                       env=env, cwd=ROOT, timeout=deadline_s + 30)
    results = [json.loads(x) for x in p.stdout.splitlines() if x.startswith("{") and '"kind": "result"' in x]
    assert results, (p.returncode, p.stdout[-2000:], p.stderr[-4000:])
    return results[-1]  # type: ignore[no-any-return]


def test_d2_pubsub_socket_death_is_detected_and_push_resumes() -> None:
    r = _run("pubsub_etimedout")
    assert r["ok"], r
    assert r["max_loop_gap_ms"] < 250 and r["rss_delta_mb"] < 20, r  # pre-fix: loop blocked, +500 MB in 3 s
    assert r["counters"]["pubsub_dead"] >= 1 and r["pubsubs"] >= 2, r
    assert r["counters"]["store_dead_transports"] >= 1 and r["counters"]["store_reconnects"] >= 1, r
    assert r["push_applied_s"] < 2.0, r


def test_d2_silent_partition_is_found_by_liveness_ping_and_heals() -> None:
    r = _run("pubsub_partition")
    assert r["ok"], r  # pre-fix: blocked on the dead socket for ever, the update never arrives
    assert r["dead_in_partition"] >= 1 and r["pubsubs_in_partition"] >= 2, r  # detected, retried (bounded)
    assert r["recovered_after_heal_s"] < 2.0, r
    assert r["max_loop_gap_ms"] < 250 and r["rss_delta_mb"] < 20, r


def test_d2_listener_survives_a_client_that_never_waits_and_a_message_flood() -> None:
    r = _run("listener_client_bugs")
    nw, fl = r["no_wait"], r["flood"]
    assert nw["dead"] >= 3 and nw["pubsubs"] >= 3 and nw["nudges"] == nw["pubsubs"], nw  # catch-up per subscribe
    assert nw["max_loop_gap_ms"] < 100, nw
    assert fl["dead"] == 0 and fl["pubsubs"] == 1 and fl["reads"] >= 100, fl
    assert fl["reads"] <= 8 * fl["nudges"] + 8, fl  # <= RV_PUBSUB_DRAIN_MAX messages per nudge
    assert fl["max_loop_gap_ms"] < 100, fl


def test_d1_a_dead_pooled_socket_is_replaced_not_handed_out() -> None:
    r = _run("d1_dead_pooled_connection")
    assert r["ok"], r  # pre-fix: RuntimeError "... the handler is closed" (HTTP 500)
    assert r["counters"]["store_dead_transports"] >= 1 and r["counters"]["store_reconnects"] >= 1, r


def test_d1_every_transport_fault_on_the_request_path_is_a_declared_503() -> None:
    out = _run("d1_admission_faults")["outcomes"]
    assert out.pop("keepalive_death") == "grant", out  # socket dead BEFORE the call: reconnected, served
    assert set(out.values()) == {"503:shared_state_unavailable"}, out


@pytest.mark.parametrize(("url", "cls"), [
    ("redis://10.1.2.3:6379/3", RvConnection),
    ("rediss://10.1.2.3:6380/0?ssl_cert_reqs=none", RvSSLConnection),
    ("unix:///run/valkey.sock?db=2", RvUnixConnection),
])
def test_every_pool_bounds_ops_connects_and_waits_and_never_retries(url: str, cls: type) -> None:
    class C:
        target_p99_ms = 20.0

    class B:
        redis_connections = 7

    for r, t in ((connect(url, C(), B(), timeout_s=0.025), 0.025),  # type: ignore[arg-type]
                 (connect_background(url, C(), B(), timeout_s=1.0), 1.0),  # type: ignore[arg-type]
                 (client(url, pool_size=None, op_timeout_s=0.5), 0.5)):
        pool = r.connection_pool
        kw = pool.connection_kwargs
        assert pool.connection_class is cls
        assert (kw["socket_timeout"], kw["socket_connect_timeout"]) == (t, t)
        assert kw["health_check_interval"] == 0 and kw["retry_on_timeout"] is False
        conn = pool.make_connection()
        assert isinstance(conn, cls) and conn.retry.get_retries() == 0
        if hasattr(pool, "timeout"):  # BlockingConnectionPool: waiting for a pooled connection is bounded too
            assert pool.timeout == t and pool.max_connections == 7
    assert "ssl_cert_reqs" in connect_background("rediss://h:6380/0?ssl_cert_reqs=none", C(), B()).connection_pool.connection_kwargs  # type: ignore[arg-type]


def test_guard_registration_and_control_plane_clients_are_bounded() -> None:
    reg = OwnerRegistration("redis://10.1.2.3:6379/0", advertise=("10.0.0.9", 7070), hello={}, ttl_ms=3000)
    kw = reg.r.connection_pool.connection_kwargs
    assert reg.r.connection_pool.connection_class is RvConnection and kw["socket_timeout"] == 1.0
    assert kw["socket_connect_timeout"] == 1.0
    skw = sync_client("redis://10.1.2.3:6379/0", op_timeout_s=5.0).connection_pool.connection_kwargs
    assert (skw["socket_timeout"], skw["socket_connect_timeout"]) == (5.0, 5.0)


def test_no_store_client_is_built_outside_the_boundary_and_no_listen_loop() -> None:
    pkg = ROOT / "rvproto"
    boundary = pkg / "runtime" / "storeconn.py"
    ctor = re.compile(r"\bRedis\s*\(|\.from_url\s*\(|ConnectionPool\s*\(")
    listen = re.compile(r"\.listen\(\)\s*:|in\s+\w+\.listen\(\)")
    for p in pkg.rglob("*.py"):
        text = p.read_text()
        if p != boundary:
            assert not ctor.search(text), f"{p}: build store clients with runtime/storeconn.py (D1/D2)"
        assert not listen.search(text), f"{p}: pub/sub must use runtime/push.py, not listen() (D2)"


def test_store_link_knobs_default_to_the_push_defaults_and_validate() -> None:
    st = load_settings({}).v2.store
    ms = PushKnobs(ping_s=st.pubsub_ping_ms / 1000, backoff_s=(st.backoff_ms[0] / 1000, st.backoff_ms[1] / 1000),
                   drain_max=st.pubsub_drain_max, op_timeout_s=st.bg_timeout_ms / 1000)
    assert ms == DEFAULT_PUSH
    for bad in ({"RV_STORE_BG_TIMEOUT_MS": "0"}, {"RV_STORE_BG_TIMEOUT_MS": "3000"},  # > RV_KS_STALE_MS/2
                {"RV_PUBSUB_PING_MS": "-1"}, {"RV_STORE_BACKOFF_MS": "500,100"}, {"RV_STORE_BACKOFF_MS": "100"},
                {"RV_PUBSUB_DRAIN_MAX": "0"}):
        with pytest.raises(ValueError):
            load_settings(bad)


def test_store_events_are_exported_as_the_named_prometheus_counters() -> None:
    m = Registry(0)
    for name in ("store_reconnects", "pubsub_dead", "store_dead_transports", "store_transport_errors"):
        m.inc(name)
    text = prometheus(m.export())
    for name in ("rv_store_reconnects_total 1", "rv_pubsub_dead_total 1", "rv_store_dead_transports_total 1"):
        assert name in text, text
    assert issubclass(RedisConnectionError, StoreError)  # every mapped transport fault is caught as a StoreError
