"""C36 plan snapshot over the versioned, signed store layout (runtime/versioned.py).

Reconcile = one MULTI read of the plan manifest + index (org -> {epoch, seq, hash, deleted}); the index
must match the manifest's count and digest. Changed orgs are fetched, verified (signature, hash, version
equal to the index entry) and compiled. A missing / unverifiable / regressed manifest or index is a
FAILED reconcile: the snapshot is left untouched and ages, so a flushed store gives PLAN_UNAVAILABLE
(503) after the staleness ceiling, never PLAN_UNKNOWN_TENANT (403). An org disappears only through an
explicit OFF record (deleted=true: offboarded); an org absent from a verified, complete index was never
onboarded (403 is then correct).
"""

from __future__ import annotations

import asyncio
import json
import sys
import time

import orjson
import redis.asyncio as aioredis

from rvproto.domain.plan import ExecutionPlan, PlanLookup, PlanUnavailable, PlanUnknownTenant
from rvproto.plan.compiler import PlanInvalid, compile_plan
from rvproto.runtime.metrics import Registry
from rvproto.runtime.push import DEFAULT_PUSH, PushKnobs, PushListener
from rvproto.runtime.store import K2_META, K2_PLAN, K2_PLAN_INDEX, K2_UPDATES, StoreError
from rvproto.runtime.versioned import ZERO, StoreDataUnavailable, digest, verify_meta, verify_record, version_of


def _log(event: str, exc: BaseException) -> None:
    sys.stderr.write(json.dumps({"event": event, "t": time.time(), "error": repr(exc)[:300]}) + "\n")


class VersionedPlanSnapshot:
    def __init__(self, r: aioredis.Redis, metrics: Registry, hmac_key: bytes, *, reconcile_ms: float,
                 stale_ms: float, push: PushKnobs = DEFAULT_PUSH) -> None:
        self.r = r
        self.push = PushListener(r, K2_UPDATES, metrics, name="plan", knobs=push)
        self.metrics = metrics
        self.k = hmac_key
        self.reconcile_s = reconcile_ms / 1000.0
        self.stale_ns = int(stale_ms * 1e6)
        self._plans: dict[str, ExecutionPlan] = {}
        self._invalid: dict[str, str] = {}
        self._applied: dict[str, tuple[int, int, str]] = {}  # org -> (epoch, seq, hash) compiled
        self.version = ZERO
        self._last_ok_ns = 0
        self.loaded = False

    def versions(self) -> dict[str, str]:
        return {org: p.version for org, p in self._plans.items()}

    def age_s(self) -> float:
        return (time.perf_counter_ns() - self._last_ok_ns) / 1e9

    def fresh(self) -> bool:
        return self.loaded and time.perf_counter_ns() - self._last_ok_ns <= self.stale_ns

    def get(self, org_id: str) -> PlanLookup:
        if time.perf_counter_ns() - self._last_ok_ns > self.stale_ns:
            return PlanUnavailable(org_id, "plan snapshot older than the staleness ceiling")
        plan = self._plans.get(org_id)
        if plan is not None:
            return plan
        if org_id in self._invalid:
            return PlanUnavailable(org_id, self._invalid[org_id])
        return PlanUnknownTenant(org_id)

    async def load_all(self) -> None:
        try:
            await self.reconcile_once()
        except StoreError as exc:  # start anyway: the snapshot is stale => PLAN_UNAVAILABLE, never 403
            self.metrics.inc("plan_reconcile_errors")
            _log("plan_initial_load_failed", exc)
        self.loaded = True

    async def reconcile_once(self) -> None:
        pipe = self.r.pipeline(transaction=True)
        pipe.get(K2_META + "plan")
        pipe.hgetall(K2_PLAN_INDEX)
        meta_raw, index_raw = await pipe.execute()
        meta = verify_meta(self.k, "plan", meta_raw, not_before=self.version)
        index = {k.decode(): orjson.loads(v) for k, v in index_raw.items()}
        entries = list(index.values())
        if len(entries) != int(meta["count"]) or digest(entries) != meta["digest"]:
            raise StoreDataUnavailable("plan index does not match its manifest (partial or mixed state)")
        plans, invalid, applied = dict(self._plans), dict(self._invalid), dict(self._applied)
        for org, e in index.items():
            want = (int(e["epoch"]), int(e["seq"]), e["hash"])
            if applied.get(org) == want:
                continue
            if e["deleted"]:  # explicit OFF: offboarded
                plans.pop(org, None)
                invalid.pop(org, None)
                applied[org] = want
                continue
            await self._load_one(org, want, plans, invalid, applied)
        vanished = [o for o in plans if o not in index]
        if vanished:
            raise StoreDataUnavailable(f"plans of {vanished} vanished without an OFF record")
        self._plans, self._invalid, self._applied = plans, invalid, applied
        self.version = version_of(meta)
        self._last_ok_ns = time.perf_counter_ns()

    async def _load_one(self, org: str, want: tuple[int, int, str], plans: dict[str, ExecutionPlan],
                        invalid: dict[str, str], applied: dict[str, tuple[int, int, str]]) -> None:
        raw = await self.r.get(K2_PLAN + org)
        if raw is None:
            raise StoreDataUnavailable(f"plan record of {org} missing while indexed")
        rec = verify_record(self.k, "plan", raw)
        if (rec["epoch"], rec["seq"], rec["hash"]) != want:
            raise StoreDataUnavailable(f"plan record of {org} does not match its index entry")
        try:
            plans[org] = compile_plan(rec["body"])
            invalid.pop(org, None)
            self.metrics.inc("plan_reloads")
        except (PlanInvalid, ValueError, KeyError) as exc:  # the previous valid version keeps serving
            if org not in plans:
                invalid[org] = f"plan failed validation: {exc}"
            self.metrics.inc("plan_invalid")
        applied[org] = want

    async def run(self) -> None:
        """Push (pub/sub) + periodic reconcile; failures only age the snapshot."""
        listener = asyncio.create_task(self._listen())
        try:
            while True:
                try:
                    await self.reconcile_once()
                except StoreError as exc:
                    self.metrics.inc("plan_reconcile_errors")
                    _log("plan_reconcile_error", exc)
                await asyncio.sleep(self.reconcile_s)
        finally:
            listener.cancel()

    async def _listen(self) -> None:
        """Pub/sub nudges through runtime/push.py (never redis-py's listen(): D2)."""
        await self.push.run(self._pushed, _plan_nudge)

    async def _pushed(self) -> bool:
        try:
            await self.reconcile_once()
        except StoreError as exc:
            self.metrics.inc("plan_reconcile_errors")
            _log("plan_reconcile_error", exc)
            return False  # the listener retries on its next wakeup
        self.metrics.inc("plan_push_applied")
        return True


def _plan_nudge(msg: dict[str, object]) -> bool:
    return msg.get("type") == "message" and msg.get("data") in (b"plan", b"all")
