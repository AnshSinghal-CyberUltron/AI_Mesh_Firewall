"""Keep-alive connection lifetime (RV_CONN_MAX_REQUESTS / RV_CONN_MAX_AGE_S, both 0 = off by default).

An L4 passthrough load balancer balances per CONNECTION, and keep-alive client pools pin their connections to
the backends that were healthy when each connection opened: after a scale-out the new gateways would receive
only the few connections opened later. Once a connection has served N requests, or is older than T seconds,
the response of the request that crosses the threshold carries `connection: close` (the same mechanism as the
drain), so the client reconnects and the balancer spreads the new connection. Nothing is cut: an SSE stream
only gets the header on its response; the connection closes after that response completes.

A connection is identified by the client address (host, port) of its requests (per worker; SO_REUSEPORT keeps
a connection on one worker). An entry idle for longer than the keep-alive timeout belongs to a connection that
has closed (a reused client port starts afresh); idle entries are pruned, so the table holds at most the
worker's live connections.
"""

from __future__ import annotations

from collections.abc import Sequence

from rvproto.runtime.metrics import Registry

_PRUNE_S = 10.0


class ConnLimits:
    def __init__(self, metrics: Registry, *, max_requests: int, max_age_s: float, keepalive_s: float) -> None:
        self.metrics = metrics
        self.max_requests = max_requests
        self.max_age_s = max_age_s
        self.idle_s = keepalive_s + 5.0
        self.on = max_requests > 0 or max_age_s > 0
        self._conns: dict[tuple[str, int], list[float]] = {}  # client -> [first seen, requests, last seen]
        self._pruned = 0.0

    def should_close(self, client: Sequence[object] | None, now: float) -> bool:
        """Count one request on this connection; True = answer it with `connection: close`."""
        if not self.on or not client or len(client) < 2:
            return False
        key = (str(client[0]), int(client[1]))  # type: ignore[call-overload]
        e = self._conns.get(key)
        if e is None or now - e[2] > self.idle_s:
            e = self._conns[key] = [now, 0.0, now]
        e[1] += 1
        e[2] = now
        by_count = self.max_requests > 0 and e[1] >= self.max_requests
        by_age = self.max_age_s > 0 and now - e[0] >= self.max_age_s
        if now - self._pruned >= _PRUNE_S:
            self._prune(now)
        if not (by_count or by_age):
            return False
        del self._conns[key]
        self.metrics.inc("conn_closed_max_requests" if by_count else "conn_closed_max_age")
        return True

    def _prune(self, now: float) -> None:
        self._pruned = now
        for key in [k for k, e in self._conns.items() if now - e[2] > self.idle_s]:
            del self._conns[key]
        self.metrics.set("conn_tracked", len(self._conns))
