"""C10: the guard deadline is DERIVED from the processing budget, never set equal to it.

deadline = clamp(RV_SLO_MS - p99(non-guard input work) - RV_GUARD_DEADLINE_MARGIN_MS,
                 RV_GUARD_DEADLINE_MIN_MS, RV_GUARD_DEADLINE_MAX_MS (default RV_SLO_MS))
where the non-guard input work of a request is t_input - t_guard_wait (admission, plan pin, canonicalise,
tokenise, deterministic scan, resolve, transform), measured on THIS worker over the previous
RV_GUARD_DEADLINE_WINDOW_S. The margin keeps headroom for output-phase processing. Until a window has
completed, the non-guard p99 is taken as a quarter of the SLO. An explicit RV_GUARD_DEADLINE_MS pins
the deadline (operator override); with RV_FIX_C10=off the frozen-1 rule applies (RV_GUARD_DEADLINE_MS,
else the contract's AMF target). The clamp stops a spiral under loop pressure (slower non-guard stages ->
tighter deadline -> more sheds); every change of the derived value is logged (guard_deadline_changed).
The budget a guard call carries: the pinned deadline if set; else, with RV_OWNER_ADMISSION=codel and no
budget shed, RV_GUARD_WAIT_MS (admitted work is answered late rather than abandoned: an abandoned guard
call becomes UNAVAILABLE, i.e. FAIL_OPEN or a false block); else the derived deadline.

Observation is O(1) (a fixed-width bucket increment); the p99 is computed once per window.
"""

from __future__ import annotations

import json
import sys
import time

from rvproto.runtime.metrics import Registry

_BUCKET_NS = 50_000  # 0.05 ms resolution
_SPAN_BUCKETS = 1000  # 0..50 ms; longer lands in the last bucket


class DeadlineController:
    def __init__(self, metrics: Registry, *, slo_ms: float, margin_ms: float, min_ms: float, window_s: float,
                 fixed_ms: float | None, max_ms: float | None = None, wait_ms: float | None = None,
                 worker: int = 0) -> None:
        self.metrics = metrics
        self.slo_ms, self.margin_ms, self.min_ms = slo_ms, margin_ms, min_ms
        self.max_ms = slo_ms if max_ms is None else max_ms
        self.wait_ms = wait_ms
        self.worker = worker
        self.window_ns = int(window_s * 1e9)
        self.fixed_ms = fixed_ms
        self._counts = [0] * _SPAN_BUCKETS
        self._n = 0
        self._window_end = time.perf_counter_ns() + self.window_ns
        self.other_p99_ms = slo_ms / 4
        self.deadline_ms = fixed_ms if fixed_ms is not None else self._derive()
        metrics.set("guard_deadline_ms", self.deadline_ms)

    def _derive(self) -> float:
        return min(max(self.slo_ms - self.other_p99_ms - self.margin_ms, self.min_ms), self.max_ms)

    def current_ms(self) -> float:
        """The budget of the next guard call."""
        if self.fixed_ms is None and self.wait_ms is not None:
            return self.wait_ms
        return self.deadline_ms

    def observe(self, nonguard_ns: int) -> None:
        now = time.perf_counter_ns()
        if now >= self._window_end:
            self._rotate(now)
        self._counts[min(max(nonguard_ns, 0) // _BUCKET_NS, _SPAN_BUCKETS - 1)] += 1
        self._n += 1

    def _rotate(self, now: int) -> None:
        if self._n:
            rank, acc = 0.99 * self._n, 0
            for i, c in enumerate(self._counts):
                acc += c
                if acc >= rank:
                    self.other_p99_ms = (i + 1) * _BUCKET_NS / 1e6  # bucket upper edge: conservative
                    break
            if self.fixed_ms is None:
                old, self.deadline_ms = self.deadline_ms, self._derive()
                if abs(self.deadline_ms - old) >= _BUCKET_NS / 1e6:
                    raw = self.slo_ms - self.other_p99_ms - self.margin_ms
                    clamp = "min" if raw < self.min_ms else "max" if raw > self.max_ms else None
                    sys.stderr.write(json.dumps({"event": "guard_deadline_changed", "t": time.time(),
                                                 "worker": self.worker, "from_ms": round(old, 3),
                                                 "to_ms": round(self.deadline_ms, 3), "clamped": clamp,
                                                 "nonguard_p99_ms": round(self.other_p99_ms, 3)}) + "\n")
            self.metrics.set("guard_deadline_ms", self.deadline_ms)
            self.metrics.set("input_nonguard_p99_ms", self.other_p99_ms)
        self._counts = [0] * _SPAN_BUCKETS
        self._n = 0
        self._window_end = now + self.window_ns


class FixedDeadline:
    """RV_FIX_C10=off: the frozen-1 deadline (explicit RV_GUARD_DEADLINE_MS, else the contract target)."""

    def __init__(self, deadline_ms: float) -> None:
        self.deadline_ms = deadline_ms

    def current_ms(self) -> float:
        return self.deadline_ms

    def observe(self, nonguard_ns: int) -> None:
        return None
