"""The store client boundary: every Redis/Valkey connection rvproto opens is built here (D1, D2).

A socket that dies underneath a pooled connection (TCP keepalive ETIMEDOUT during a partition, a reset, a
peer close) leaves redis-py 8.1 + uvloop with a closed transport and a StreamReader that re-raises the socket
error on every read. Two defects followed from that:
  D2  redis-py reads the socket's ETIMEDOUT as "no message yet" (asyncio.TimeoutError IS TimeoutError since
      Python 3.11) whenever a read carries its own timeout, returns None without disconnecting, and a pub/sub
      listen() loop re-reads the dead socket forever: the event loop never yields again and every re-raise
      grows the stored exception's traceback (GBs in seconds -> OOM).
  D1  the pool hands the dead connection out again; the next write raises uvloop's RuntimeError ("... the
      handler is closed"), which no StoreError clause catches -> HTTP 500.
The Rv* connection classes turn every transport fault into redis ConnectionError (a StoreError), and replace
a dead socket on checkout (no I/O needed to see it) instead of handing it out. Every pool gets explicit op,
connect and pool-wait timeouts and one retry policy: none (retry_on_timeout off, no PING health checks).
The request path's store budget is one RV_STORE_TIMEOUT_MS; background loops retry on their own period, and
a redis-level retry could duplicate a non-idempotent write (audit XADD). The pub/sub connection, the one
connection that can sit idle for ever, has its own verified liveness PING (runtime/push.py).
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import redis
import redis.asyncio as aioredis
from redis.asyncio.connection import (
    AbstractConnection,
    Connection,
    SSLConnection,
    UnixDomainSocketConnection,
    parse_url,
)
from redis.asyncio.retry import Retry
from redis.backoff import NoBackoff
from redis.exceptions import ConnectionError as StoreConnectionError

Events = Callable[[str], object] | None


class _Resilient:
    """Mixin over redis-py's asyncio connection classes (TCP, TLS, Unix socket)."""

    _reader: Any
    _writer: Any

    def __init__(self, *args: Any, rv_events: Events = None, **kwargs: Any) -> None:
        self._rv_events = rv_events
        self._rv_connected_once = False
        super().__init__(*args, **kwargs)

    def _rv_emit(self, name: str) -> None:
        if self._rv_events is not None:
            self._rv_events(name)

    def _rv_transport_dead(self) -> bool:
        """The socket is gone although redis-py still counts the connection as connected."""
        w, r = self._writer, self._reader
        if w is None or r is None:
            return False
        return bool(w.transport.is_closing() or r.exception() is not None or r.at_eof())

    def _rv_lost(self, what: str, exc: BaseException) -> StoreConnectionError:
        return StoreConnectionError(f"Error while {what} {self._host_error()}: {exc!r}")  # type: ignore[attr-defined]

    async def connect_check_health(self, check_health: bool = True, retry_socket_connect: bool = True) -> None:
        if self._rv_transport_dead():  # never reuse a dead socket (pool checkout, pub/sub reconnect): replace it
            self._rv_emit("store_dead_transports")
            await self.disconnect(nowait=True)  # type: ignore[attr-defined]
        had = self._writer
        await super().connect_check_health(  # type: ignore[misc]
            check_health=check_health, retry_socket_connect=retry_socket_connect)
        if self._writer is not None and self._writer is not had:
            if self._rv_connected_once:
                self._rv_emit("store_reconnects")
            self._rv_connected_once = True

    async def send_packed_command(self, command: Any, check_health: bool = True) -> None:
        if self._rv_transport_dead():  # disconnected => redis-py reconnects (bounded by socket_connect_timeout)
            self._rv_emit("store_dead_transports")
            await self.disconnect(nowait=True)  # type: ignore[attr-defined]
        try:
            await super().send_packed_command(command, check_health=check_health)  # type: ignore[misc]
        except RuntimeError as exc:  # uvloop: write on a transport closed underneath us ("the handler is closed")
            self._rv_emit("store_transport_errors")
            raise self._rv_lost("writing to", exc) from exc

    async def _read_response_from_parser(self, disable_decoding: bool = False,
                                         push_request: bool | None = False) -> Any:
        try:
            return await super()._read_response_from_parser(  # type: ignore[misc]
                disable_decoding=disable_decoding, push_request=push_request)
        except TimeoutError as exc:
            # Raised by the SOCKET (keepalive / user-timeout ETIMEDOUT): a read deadline expires outside this frame
            # (CancelledError here). Left alone, redis-py would answer "no message yet" and never disconnect (D2).
            self._rv_emit("store_dead_transports")
            raise self._rv_lost("reading from", exc) from exc
        except RuntimeError as exc:
            self._rv_emit("store_transport_errors")
            raise self._rv_lost("reading from", exc) from exc


class RvConnection(_Resilient, Connection):
    """redis:// (TCP)."""


class RvSSLConnection(_Resilient, SSLConnection):
    """rediss:// (TLS)."""


class RvUnixConnection(_Resilient, UnixDomainSocketConnection):
    """unix://."""


def _rv_class(base: type[AbstractConnection]) -> type[AbstractConnection]:
    if issubclass(base, SSLConnection):
        return RvSSLConnection
    if issubclass(base, UnixDomainSocketConnection):
        return RvUnixConnection
    return RvConnection


def pool_kwargs(url: str, *, op_timeout_s: float, connect_timeout_s: float, events: Events) -> dict[str, Any]:
    """Connection kwargs for `url`: the URL gives the endpoint, credentials, db and TLS options; this boundary owns
    the connection class, the timeouts and the retry policy (they win over URL query options)."""
    opts: dict[str, Any] = dict(parse_url(url))
    opts["connection_class"] = _rv_class(opts.get("connection_class", Connection))
    opts.update(socket_timeout=op_timeout_s, socket_connect_timeout=connect_timeout_s, retry_on_timeout=False,
                retry=Retry(NoBackoff(), 0), health_check_interval=0, decode_responses=False, rv_events=events)
    return opts


def client(url: str, *, pool_size: int | None, op_timeout_s: float, events: Events = None,
           pool_wait_s: float | None = None) -> aioredis.Redis:
    """An asyncio client whose every op, connect and (pool_size set) wait for a pooled connection is bounded.
    The client owns its pool: aclose() also closes the pool's sockets (as Redis.from_url did)."""
    kw = pool_kwargs(url, op_timeout_s=op_timeout_s, connect_timeout_s=op_timeout_s, events=events)
    if pool_size is None:
        return aioredis.Redis.from_pool(aioredis.ConnectionPool(**kw))
    wait = op_timeout_s if pool_wait_s is None else pool_wait_s
    return aioredis.Redis.from_pool(aioredis.BlockingConnectionPool(max_connections=pool_size, timeout=wait, **kw))


def sync_client(url: str, *, op_timeout_s: float) -> redis.Redis:
    """Control plane (writer, re-hydrator): blocking sockets, no event loop; explicit op + connect timeouts."""
    return redis.Redis.from_url(url, socket_timeout=op_timeout_s, socket_connect_timeout=op_timeout_s,
                                retry_on_timeout=False, health_check_interval=0)
