"""rvproto-2 settings: the four fixes (each behind its own flag, default ON) and the knobs they add.

Every flag set to `off` restores the rvproto-frozen-1 behaviour of that area, so each fix has a
negative control on the same build:
  RV_FIX_C38  loop isolation: metrics in shared memory + off-loop exporter, tokenizer encode_batch in a
              thread pool (TOKENIZERS_PARALLELISM=false), GC frozen after startup with raised thresholds
  RV_FIX_C10  owner-level admission: per-worker guard cap advisory; owner queue bound, input queue, guard
              deadline and store timeout are separate knobs (no AMF_TARGET_P99_MS coupling); the owner sheds
              (503 + Retry-After) on a STANDING queue (RV_OWNER_ADMISSION=codel, default) or, rc1's rule, on an
              instantaneous backlog bound plus a per-request budget check (RV_OWNER_ADMISSION=bound)
  RV_FIX_C43  load-aware guard routing: owners push their backlog to subscribed workers on every change;
              workers route each guard call to the owner with the least estimated backlog
  RV_FIX_C36  durable state: versioned, signed records with explicit OFF records; missing or regressed
              store data is UNAVAILABLE (503), never "unknown tenant" / 401 for a valid key
"""

from __future__ import annotations

from dataclasses import dataclass

V2_DEFAULTS: tuple[tuple[str, str], ...] = (
    ("RV_FIX_C38", "on"),
    ("RV_FIX_C10", "on"),
    ("RV_FIX_C43", "on"),
    ("RV_FIX_C36", "on"),
    # C38 loop isolation
    ("RV_GC_FREEZE", "on"),  # gc.freeze() once startup is complete (C38 on only)
    ("RV_GC_THRESHOLD", "50000,50,100"),  # gc.set_threshold (C38 on only)
    ("RV_INJECT_CPU_BURST", ""),  # test fault: "<worker>:<ms>:<period_s>" busy-loop on that worker's event loop
    ("RV_EXPORTER_PORT", "9464"),  # launcher / guard-node exporter: /metrics (Prometheus), /metrics.json; 0 = off
    ("RV_EXPORTER_HOST", "0.0.0.0"),
    ("RV_SHM_SLOTS", "96,512,512"),  # shared-memory metric slots per process: histograms, counters, gauges
    # C10 owner-level admission
    ("RV_SLO_MS", "20"),  # the processing SLO the guard deadline is derived from
    ("RV_GUARD_DEADLINE_MARGIN_MS", "2"),  # headroom kept for output-phase processing
    ("RV_GUARD_DEADLINE_MIN_MS", "4"),
    ("RV_GUARD_DEADLINE_MAX_MS", ""),  # clamp of the derived deadline; empty => RV_SLO_MS
    ("RV_GUARD_DEADLINE_WINDOW_S", "10"),  # rolling window of the non-guard input-stage p99
    ("RV_OWNER_ADMISSION", "codel"),  # codel: shed on a standing queue | bound: rc1's instantaneous bound
    ("RV_OWNER_TARGET_MS", "5"),  # codel: standing queue = minimum sojourn over an interval above this
    ("RV_OWNER_INTERVAL_MS", "100"),
    ("RV_OWNER_QUEUE_MS", ""),  # hard backlog cap, ms of work at the measured rate; empty => 60 codel / 12 bound
    ("RV_OWNER_BUDGET_SHED", ""),  # shed when predicted wait + execution > the budget; empty => off codel / on bound
    ("RV_GUARD_WAIT_MS", ""),  # codel, no budget shed: guard budget of a request (admitted work is never abandoned
    #                            before it; late beats FAIL_OPEN); empty => max(100, RV_OWNER_QUEUE_MS + 40)
    ("RV_INPUT_QUEUE_CAP", ""),  # per-worker input-phase bound; empty => none (C10 on) / contract (C10 off)
    ("RV_STORE_TIMEOUT_MS", "25"),  # store op timeout on the request path (C10 on; off: the contract's AMF target)
    # C43 routing + guard discovery + drain
    ("RV_GUARD_DISCOVERY", ""),  # store | static; empty => store when RV_GUARD_TOPOLOGY=remote and no RV_GUARD_OWNER_ADDRS
    ("RV_GUARD_DISCOVERY_MS", "1000"),
    ("RV_GUARD_REGISTER_TTL_MS", "3000"),
    ("RV_GUARD_ADVERTISE", ""),  # host:port owners register (empty => the TCP listen address)
    ("RV_GUARD_ROUTE_EPS_US", "250"),  # owners within this estimated backlog of the minimum tie (random pick)
    ("RV_GUARD_DRAIN_S", "30"),  # owner drain bound after SIGTERM
    ("RV_DRAIN_ACCEPT_S", "15"),  # gateway: keep accepting (readyz 503, connection: close) this long after SIGTERM
    ("RV_DRAIN_S", "60"),  # gateway: then stop accepting and finish in-flight streams within this bound
    ("RV_ATTRIBUTION", "header"),  # off | header (x-rv-attr) | stages (also appended to x-rv-stages)
    ("RV_INJECT_OWNER_DELAY_MS", "0"),  # test fault: extra delay before each owner execution
    # C36 durable state
    ("RV_STATE_HMAC_KEY", ""),  # record signing key (control plane and gateways); required when C36 is on
    ("RV_DATABASE_URL", ""),  # Postgres DSN (control-plane writer and re-hydrator only)
    ("RV_REHYDRATE_PERIOD_MS", "1000"),
    ("RV_BUDGET_CHECKPOINT_S", "5"),
    # autoscaling signals
    ("RV_EXPORT_S", "10"),  # exporter window for loop-lag / queue / CPU signals
    ("RV_CLOUD_MONITORING", "off"),  # on: push the signals as Cloud Monitoring custom metrics
    ("RV_MONITORING_RESOURCE", "gce_instance"),  # gce_instance | k8s_pod
    ("RV_MONITORING_PREFIX", "custom.googleapis.com/rv2"),
    # store links (D1/D2: gateway<->store partition): runtime/storeconn.py, runtime/push.py
    ("RV_STORE_BG_TIMEOUT_MS", "1000"),  # background store op / connect / pool-wait timeout (<= RV_KS_STALE_MS/2)
    ("RV_PUBSUB_PING_MS", "5000"),  # pub/sub liveness: PING after this much silence, dead after 2x
    ("RV_STORE_BACKOFF_MS", "100,2000"),  # pub/sub re-subscribe backoff: first,cap (equal-jitter exponential)
    ("RV_PUBSUB_DRAIN_MAX", "64"),  # pub/sub messages taken per wakeup (coalesced into one nudge)
    # keep-alive connection lifetime (L4 load balancers balance per connection): edge/connlimit.py
    ("RV_CONN_MAX_REQUESTS", "0"),  # `connection: close` on the response of the Nth request; 0 = off
    ("RV_CONN_MAX_AGE_S", "0"),  # ... of the first request after the connection is T s old; 0 = off
    ("RV_KEEPALIVE_S", "75"),  # uvicorn keep-alive timeout (serve.py)
)


def _flag(raw: str, name: str) -> bool:
    v = raw.strip().lower()
    if v not in ("on", "off"):
        raise ValueError(f"{name}={raw!r} (on | off)")
    return v == "on"


def _ints(raw: str, n: int, name: str) -> tuple[int, ...]:
    parts = tuple(int(x) for x in raw.split(",") if x.strip())
    if len(parts) != n or min(parts) < 0:
        raise ValueError(f"{name}={raw!r} needs {n} non-negative integers")
    return parts


def _burst(raw: str) -> tuple[int, float, float] | None:
    if not raw.strip():
        return None
    w, ms, period = raw.split(":")
    out = int(w), float(ms), float(period)
    if out[1] <= 0 or out[2] <= 0:
        raise ValueError(f"RV_INJECT_CPU_BURST={raw!r} (<worker>:<ms>:<period_s>, both positive)")
    return out


@dataclass(frozen=True, slots=True)
class LoopIsolation:
    on: bool
    gc_freeze: bool
    gc_threshold: tuple[int, int, int]
    cpu_burst: tuple[int, float, float] | None
    exporter_port: int
    exporter_host: str
    shm_slots: tuple[int, int, int]


@dataclass(frozen=True, slots=True)
class Admission:
    on: bool
    slo_ms: float
    deadline_margin_ms: float
    deadline_min_ms: float
    deadline_max_ms: float
    deadline_window_s: float
    admission: str  # "codel" | "bound"
    target_ms: float
    interval_ms: float
    owner_queue_ms: float  # the hard cap (effective value)
    budget_shed: bool
    guard_wait_ms: float
    input_queue_cap: int | None
    store_timeout_ms: float

    @property
    def codel(self) -> bool:
        return self.on and self.admission == "codel"

    @property
    def wait_budget_ms(self) -> float | None:
        """The guard budget a worker applies instead of the derived deadline (codel without budget shed)."""
        return self.guard_wait_ms if self.codel and not self.budget_shed else None


@dataclass(frozen=True, slots=True)
class Routing:
    on: bool
    discovery: str  # "store" | "static"
    discovery_ms: float
    register_ttl_ms: float
    advertise: str
    route_eps_ns: int
    guard_drain_s: float
    drain_accept_s: float
    drain_s: float
    attribution: str
    inject_owner_delay_ms: float


@dataclass(frozen=True, slots=True)
class Durable:
    on: bool
    hmac_key: str
    database_url: str
    rehydrate_period_ms: float
    budget_checkpoint_s: float


@dataclass(frozen=True, slots=True)
class Signals:
    export_s: float
    cloud_monitoring: bool
    resource: str
    prefix: str


@dataclass(frozen=True, slots=True)
class StoreLinks:
    bg_timeout_ms: float
    pubsub_ping_ms: float
    backoff_ms: tuple[float, float]
    pubsub_drain_max: int


@dataclass(frozen=True, slots=True)
class EdgeConn:
    max_requests: int
    max_age_s: float
    keepalive_s: float


@dataclass(frozen=True, slots=True)
class V2:
    c38: LoopIsolation
    c10: Admission
    c43: Routing
    c36: Durable
    signals: Signals
    store: StoreLinks
    edge: EdgeConn


def load_v2(get: dict[str, str], *, topology: str, static_addrs: bool) -> V2:
    t = _ints(get["RV_GC_THRESHOLD"], 3, "RV_GC_THRESHOLD")
    c38 = LoopIsolation(
        on=_flag(get["RV_FIX_C38"], "RV_FIX_C38"),
        gc_freeze=_flag(get["RV_GC_FREEZE"], "RV_GC_FREEZE"),
        gc_threshold=(t[0], t[1], t[2]),
        cpu_burst=_burst(get["RV_INJECT_CPU_BURST"]),
        exporter_port=int(get["RV_EXPORTER_PORT"]),
        exporter_host=get["RV_EXPORTER_HOST"],
        shm_slots=_shm_slots(get["RV_SHM_SLOTS"]),
    )
    c10 = _admission(get)
    disc = get["RV_GUARD_DISCOVERY"].strip() or ("store" if topology == "remote" and not static_addrs else "static")
    if disc not in ("store", "static"):
        raise ValueError(f"RV_GUARD_DISCOVERY={disc!r} (store | static)")
    attr = get["RV_ATTRIBUTION"].strip().lower()
    if attr not in ("off", "header", "stages"):
        raise ValueError(f"RV_ATTRIBUTION={attr!r} (off | header | stages)")
    c43 = Routing(
        on=_flag(get["RV_FIX_C43"], "RV_FIX_C43"),
        discovery=disc,
        discovery_ms=float(get["RV_GUARD_DISCOVERY_MS"]),
        register_ttl_ms=float(get["RV_GUARD_REGISTER_TTL_MS"]),
        advertise=get["RV_GUARD_ADVERTISE"].strip(),
        route_eps_ns=int(float(get["RV_GUARD_ROUTE_EPS_US"]) * 1000),
        guard_drain_s=float(get["RV_GUARD_DRAIN_S"]),
        drain_accept_s=float(get["RV_DRAIN_ACCEPT_S"]),
        drain_s=float(get["RV_DRAIN_S"]),
        attribution=attr,
        inject_owner_delay_ms=float(get["RV_INJECT_OWNER_DELAY_MS"]),
    )
    c36 = Durable(
        on=_flag(get["RV_FIX_C36"], "RV_FIX_C36"),
        hmac_key=get["RV_STATE_HMAC_KEY"],
        database_url=get["RV_DATABASE_URL"],
        rehydrate_period_ms=float(get["RV_REHYDRATE_PERIOD_MS"]),
        budget_checkpoint_s=float(get["RV_BUDGET_CHECKPOINT_S"]),
    )
    res = get["RV_MONITORING_RESOURCE"].strip()
    if res not in ("gce_instance", "k8s_pod"):
        raise ValueError(f"RV_MONITORING_RESOURCE={res!r} (gce_instance | k8s_pod)")
    signals = Signals(
        export_s=float(get["RV_EXPORT_S"]),
        cloud_monitoring=_flag(get["RV_CLOUD_MONITORING"], "RV_CLOUD_MONITORING"),
        resource=res,
        prefix=get["RV_MONITORING_PREFIX"].rstrip("/"),
    )
    _check(c10)
    edge = EdgeConn(max_requests=int(get["RV_CONN_MAX_REQUESTS"]), max_age_s=float(get["RV_CONN_MAX_AGE_S"]),
                    keepalive_s=float(get["RV_KEEPALIVE_S"]))
    if edge.max_requests < 0 or edge.max_age_s < 0:
        raise ValueError("RV_CONN_MAX_REQUESTS / RV_CONN_MAX_AGE_S must be >= 0 (0 = off)")
    return V2(c38, c10, c43, c36, signals, _store_links(get), edge)


def _admission(get: dict[str, str]) -> Admission:
    iq = get["RV_INPUT_QUEUE_CAP"].strip()
    mode = get["RV_OWNER_ADMISSION"].strip().lower()
    if mode not in ("codel", "bound"):
        raise ValueError(f"RV_OWNER_ADMISSION={mode!r} (codel | bound)")
    cap, shed, dmax, wait = (get[k].strip() for k in (
        "RV_OWNER_QUEUE_MS", "RV_OWNER_BUDGET_SHED", "RV_GUARD_DEADLINE_MAX_MS", "RV_GUARD_WAIT_MS"))
    slo = float(get["RV_SLO_MS"])
    cap_ms = float(cap) if cap else (60.0 if mode == "codel" else 12.0)
    return Admission(
        on=_flag(get["RV_FIX_C10"], "RV_FIX_C10"),
        slo_ms=slo,
        deadline_margin_ms=float(get["RV_GUARD_DEADLINE_MARGIN_MS"]),
        deadline_min_ms=float(get["RV_GUARD_DEADLINE_MIN_MS"]),
        deadline_max_ms=float(dmax) if dmax else slo,
        deadline_window_s=float(get["RV_GUARD_DEADLINE_WINDOW_S"]),
        admission=mode,
        target_ms=float(get["RV_OWNER_TARGET_MS"]),
        interval_ms=float(get["RV_OWNER_INTERVAL_MS"]),
        owner_queue_ms=cap_ms,
        budget_shed=_flag(shed, "RV_OWNER_BUDGET_SHED") if shed else mode == "bound",
        guard_wait_ms=float(wait) if wait else max(100.0, cap_ms + 40.0),
        input_queue_cap=int(iq) if iq else None,
        store_timeout_ms=float(get["RV_STORE_TIMEOUT_MS"]),
    )


def _store_links(get: dict[str, str]) -> StoreLinks:
    parts = tuple(float(x) for x in get["RV_STORE_BACKOFF_MS"].split(",") if x.strip())
    links = StoreLinks(
        bg_timeout_ms=float(get["RV_STORE_BG_TIMEOUT_MS"]),
        pubsub_ping_ms=float(get["RV_PUBSUB_PING_MS"]),
        backoff_ms=(parts[0], parts[-1]) if parts else (0.0, 0.0),
        pubsub_drain_max=int(get["RV_PUBSUB_DRAIN_MAX"]),
    )
    if links.bg_timeout_ms <= 0:
        raise ValueError("RV_STORE_BG_TIMEOUT_MS must be positive")
    if links.pubsub_ping_ms <= 0:
        raise ValueError("RV_PUBSUB_PING_MS must be positive")
    if len(parts) != 2 or not 0 < parts[0] <= parts[1]:
        raise ValueError(f"RV_STORE_BACKOFF_MS={get['RV_STORE_BACKOFF_MS']!r} needs first,cap with 0 < first <= cap")
    if links.pubsub_drain_max < 1:
        raise ValueError("RV_PUBSUB_DRAIN_MAX must be >= 1")
    return links


def _shm_slots(raw: str) -> tuple[int, int, int]:
    h, c, g = _ints(raw, 3, "RV_SHM_SLOTS")
    return h, c, g


def _check(c10: Admission) -> None:
    if c10.deadline_min_ms <= 0 or c10.deadline_min_ms > c10.slo_ms:
        raise ValueError("RV_GUARD_DEADLINE_MIN_MS must be in (0, RV_SLO_MS]")
    if c10.deadline_max_ms < c10.deadline_min_ms:
        raise ValueError("RV_GUARD_DEADLINE_MAX_MS must be >= RV_GUARD_DEADLINE_MIN_MS")
    if c10.owner_queue_ms <= 0:
        raise ValueError("RV_OWNER_QUEUE_MS must be positive")
    if c10.target_ms <= 0 or c10.interval_ms <= 0:
        raise ValueError("RV_OWNER_TARGET_MS and RV_OWNER_INTERVAL_MS must be positive")
    if c10.wait_budget_ms is not None and c10.guard_wait_ms < c10.owner_queue_ms:
        raise ValueError("RV_GUARD_WAIT_MS must be >= RV_OWNER_QUEUE_MS (admitted work would expire in the queue)")
    if c10.input_queue_cap is not None and c10.input_queue_cap < 1:
        raise ValueError("RV_INPUT_QUEUE_CAP must be >= 1")


def describe_v2(v: V2) -> dict[str, object]:
    out: dict[str, object] = {}
    for group in ("c38", "c10", "c43", "c36", "signals", "store", "edge"):
        g = getattr(v, group)
        d = {f: getattr(g, f) for f in g.__slots__}  # type: ignore[attr-defined]
        if group == "c36":
            d["hmac_key"] = "<set>" if v.c36.hmac_key else ""
            d["database_url"] = "<set>" if v.c36.database_url else ""
        out[group] = d
    return out
