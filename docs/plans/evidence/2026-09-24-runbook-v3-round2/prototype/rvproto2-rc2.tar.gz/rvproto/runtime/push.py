"""Pub/sub nudges (plan updates) without redis-py's PubSub.listen() (D2).

listen() re-reads its connection in a loop that never yields while the connection answers "no message" at
once; on a dead socket it spun the event loop and grew memory until the kernel killed every worker. This
listener polls with get_message(timeout=poll) and treats as a DEAD connection:
  - any store or transport error (runtime/storeconn.py maps every transport fault to ConnectionError),
  - repeated "no message" answers returned without waiting (the spin signature, whatever the client does),
  - silence: no message at all (a PING's pong included) for 2 x RV_PUBSUB_PING_MS; a PING goes out after
    RV_PUBSUB_PING_MS of silence, so a live connection is never silent that long.
A dead connection is closed (its pooled connection released) and re-subscribed after an equal-jitter
exponential backoff within RV_STORE_BACKOFF_MS; after every (re)subscription the caller's nudge runs once to
catch up on whatever was published while it was away; a nudge that fails (the caller returns False: e.g. its
reconcile met a pooled connection that died in the partition) is retried on every poll wakeup until it
succeeds, so push recovery never waits for the periodic reconcile. At most RV_PUBSUB_DRAIN_MAX messages are taken per
wakeup and they coalesce into ONE nudge (a nudge re-reads the complete state, so no message needs keeping):
nothing is buffered here, the rest waits in the socket (redis-py reads one socket chunk per call, and the
StreamReader pauses reading at twice its 64 KiB limit).
Metrics: pubsub_dead (every connection declared dead), <name>_listen_errors (the pre-existing counter),
<name>_pubsub_subscribed, <name>_nudge_failures.
"""

from __future__ import annotations

import asyncio
import json
import random
import sys
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any

import redis.asyncio as aioredis

from rvproto.runtime.metrics import Registry
from rvproto.runtime.store import StoreError

_FAST_NONE_LIMIT = 3  # consecutive "no message" answers that did not wait (a healthy read waits `poll`)
_PING = b"rv-live"


@dataclass(frozen=True, slots=True)
class PushKnobs:
    ping_s: float  # RV_PUBSUB_PING_MS
    backoff_s: tuple[float, float]  # RV_STORE_BACKOFF_MS: first, cap
    drain_max: int  # RV_PUBSUB_DRAIN_MAX
    op_timeout_s: float  # RV_STORE_BG_TIMEOUT_MS: bounds closing a dead connection


# = the V2_DEFAULTS knob defaults (a unit test keeps them equal); readers built without knobs still get push
DEFAULT_PUSH = PushKnobs(ping_s=5.0, backoff_s=(0.1, 2.0), drain_max=64, op_timeout_s=1.0)


def _log(event: str, **kw: object) -> None:
    sys.stderr.write(json.dumps({"event": event, "t": time.time(), **kw}, default=str) + "\n")


def _err(exc: BaseException | None) -> str | None:
    """redis-py 8 exceptions repr() as their category only ("network:ConnectionError"): keep the message."""
    return None if exc is None else f"{type(exc).__name__}: {exc}"[:300]


class PushListener:
    def __init__(self, r: aioredis.Redis, channel: str, metrics: Registry, *, name: str, knobs: PushKnobs) -> None:
        self.r = r
        self.channel = channel
        self.metrics = metrics
        self.name = name
        self.k = knobs
        self.poll_s = knobs.ping_s / 4
        self._rng = random.Random()
        self.subscribed = False

    def backoff(self, attempt: int) -> float:
        """Equal jitter: uniform in [d/2, d], d = min(cap, first * 2**(attempt-1))."""
        first, cap = self.k.backoff_s
        d = min(cap, first * 2 ** min(max(attempt - 1, 0), 30))
        return d / 2 + self._rng.uniform(0, d / 2)

    async def run(self, on_nudge: Callable[[], Awaitable[bool]], accept: Callable[[dict[str, Any]], bool]) -> None:
        """on_nudge: re-read the state; True when it succeeded. accept(msg): does this message ask for a nudge."""
        loop = asyncio.get_running_loop()
        attempt = 0
        while True:
            ps = self.r.pubsub()
            since: float | None = None
            try:
                await ps.subscribe(self.channel)
                since = loop.time()
                self.subscribed = True
                self.metrics.inc(f"{self.name}_pubsub_subscribed")
                pending = not await self._nudge(on_nudge)  # catch up: what was published while we were away is lost
                await self._pump(ps, on_nudge, accept, pending)
            except (*StoreError, RuntimeError) as exc:  # RuntimeError: e.g. "pubsub connection not set"
                self._dead("error", exc)
            finally:
                self.subscribed = False
                await self._close(ps)
            lived = 0.0 if since is None else loop.time() - since
            attempt = 1 if lived >= self.k.ping_s else attempt + 1  # a flapping store keeps backing off
            await asyncio.sleep(self.backoff(attempt))

    async def _pump(self, ps: Any, on_nudge: Callable[[], Awaitable[bool]],
                    accept: Callable[[dict[str, Any]], bool], pending: bool) -> None:
        """Deliver until the connection is dead (returns) or fails (raises). pending: a nudge is still owed."""
        loop = asyncio.get_running_loop()
        last_rx = pinged = loop.time()
        fast = 0
        while True:
            t0 = loop.time()
            msg = await ps.get_message(timeout=self.poll_s)
            now = loop.time()
            if pending and msg is None:
                pending = not await self._nudge(on_nudge)
            if msg is None:
                if now - t0 < self.poll_s / 2:
                    fast += 1
                    await asyncio.sleep(0)  # never starve the loop, whatever the client library does
                    if fast >= _FAST_NONE_LIMIT:
                        return self._dead("no_wait")
                else:
                    fast = 0
                if now - last_rx >= 2 * self.k.ping_s:
                    return self._dead("silent")
                if now - last_rx >= self.k.ping_s and now - pinged >= self.k.ping_s:
                    await ps.ping(_PING)  # its pong (or any message) proves the connection alive
                    pinged = now
                continue
            fast = 0
            nudge = accept(msg) or pending
            for _ in range(self.k.drain_max - 1):  # what is already buffered, bounded per wakeup
                more = await ps.get_message(timeout=0)
                if more is None:
                    break
                nudge = accept(more) or nudge
            if nudge:
                pending = not await self._nudge(on_nudge)
            last_rx = loop.time()  # our own processing is not silence
            await asyncio.sleep(0)  # a message flood must not monopolize the loop either

    async def _nudge(self, on_nudge: Callable[[], Awaitable[bool]]) -> bool:
        try:
            return await on_nudge()
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001 - the caller counts its own store errors; nothing kills the listener
            self.metrics.inc(f"{self.name}_nudge_failures")
            _log(f"{self.name}_nudge_failed", error=_err(exc))
            return False

    def _dead(self, reason: str, exc: BaseException | None = None) -> None:
        """Count and log one dead connection (the caller closes it and backs off)."""
        self.metrics.inc("pubsub_dead")
        self.metrics.inc(f"{self.name}_listen_errors")
        _log(f"{self.name}_pubsub_dead", reason=reason, error=_err(exc))

    async def _close(self, ps: Any) -> None:
        try:
            await asyncio.wait_for(ps.aclose(), self.k.op_timeout_s)
        except (*StoreError, RuntimeError):
            pass
