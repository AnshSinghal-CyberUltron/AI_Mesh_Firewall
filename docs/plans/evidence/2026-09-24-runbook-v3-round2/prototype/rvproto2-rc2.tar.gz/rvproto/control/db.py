"""C36 source of truth: Postgres (Cloud SQL) tables of the control plane, and an in-memory twin for tests.

  rv2_version(kind PK, epoch, seq)                 the per-kind version counter (row-locked by writers)
  rv2_record(kind, key PK, epoch, seq, hash, deleted, op, sig, body jsonb, updated_at)  current state
  rv2_log(id bigserial PK, kind, key, epoch, seq, hash, deleted, op, sig, body, actor, at)  append-only
  rv2_budget_checkpoint(org PK, remaining, at, epoch, seq)  periodic copy of the store's budget counters,
                                                   tagged with the budget record version they count down

Every write runs in one transaction: lock the kind's version row, take (epoch, seq + 1) (or (epoch + 1, 0)
for a rollback / a divergence repair), upsert the record, append the log row, bump the version.
A publish reads the version and the record set as ONE snapshot (version row FOR SHARE, which waits for a
writer holding it FOR UPDATE), so a manifest never claims a version its record set does not match.
"""

from __future__ import annotations

import contextlib
import threading
import time
from collections.abc import Iterator
from dataclasses import dataclass
from typing import Any, Protocol

import orjson

from rvproto.runtime.versioned import KINDS, Version

SCHEMA = """
CREATE TABLE IF NOT EXISTS rv2_version (kind text PRIMARY KEY, epoch bigint NOT NULL, seq bigint NOT NULL);
CREATE TABLE IF NOT EXISTS rv2_record (
  kind text NOT NULL, key text NOT NULL, epoch bigint NOT NULL, seq bigint NOT NULL, hash text NOT NULL,
  deleted boolean NOT NULL, op text NOT NULL, sig text NOT NULL, body jsonb NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY (kind, key));
CREATE TABLE IF NOT EXISTS rv2_log (
  id bigserial PRIMARY KEY, kind text NOT NULL, key text NOT NULL, epoch bigint NOT NULL, seq bigint NOT NULL,
  hash text NOT NULL, deleted boolean NOT NULL, op text NOT NULL, sig text NOT NULL, body jsonb NOT NULL,
  actor text NOT NULL, at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS rv2_budget_checkpoint (org text PRIMARY KEY, remaining bigint NOT NULL,
  at timestamptz NOT NULL DEFAULT now());
ALTER TABLE rv2_budget_checkpoint ADD COLUMN IF NOT EXISTS epoch bigint NOT NULL DEFAULT 0;
ALTER TABLE rv2_budget_checkpoint ADD COLUMN IF NOT EXISTS seq bigint NOT NULL DEFAULT 0;
"""


class CommitUnknown(Exception):
    """The connection failed DURING COMMIT: the write may or may not be durable (a failover mid-commit).
    The writer reports it as such -- never as a failure -- and the re-hydrator publishes whatever committed."""


class Tx(Protocol):
    def version(self, kind: str, *, lock: bool) -> Version: ...

    def set_version(self, kind: str, v: Version) -> None: ...

    def upsert(self, rec: dict[str, Any], actor: str) -> None: ...

    def records(self, kind: str) -> list[dict[str, Any]]: ...

    def snapshot(self, kind: str) -> tuple[Version, list[dict[str, Any]]]: ...

    def log_entry(self, log_id: int) -> dict[str, Any] | None: ...


class DB(Protocol):
    def tx(self) -> contextlib.AbstractContextManager[Tx]: ...

    def version(self, kind: str) -> Version: ...

    def records(self, kind: str) -> list[dict[str, Any]]: ...

    def snapshot(self, kind: str) -> tuple[Version, list[dict[str, Any]]]: ...

    def checkpoint(self, remaining: dict[str, tuple[int, Version]]) -> None: ...

    def checkpoints(self) -> dict[str, tuple[int, Version]]: ...


_REC_COLS = "kind, key, epoch, seq, hash, deleted, op, sig, body"


def _row(r: tuple[Any, ...]) -> dict[str, Any]:
    kind, key, epoch, seq, h, deleted, op, sig, body = r
    return {"kind": kind, "key": key, "epoch": int(epoch), "seq": int(seq), "hash": h, "deleted": bool(deleted),
            "op": op, "sig": sig, "body": body if not isinstance(body, (str, bytes)) else orjson.loads(body)}


class _PgTx:
    def __init__(self, cur: Any) -> None:
        self.cur = cur

    def version(self, kind: str, *, lock: bool) -> Version:
        self.cur.execute("INSERT INTO rv2_version (kind, epoch, seq) VALUES (%s, 1, 0) ON CONFLICT DO NOTHING", (kind,))
        self.cur.execute("SELECT epoch, seq FROM rv2_version WHERE kind = %s" + (" FOR UPDATE" if lock else ""), (kind,))
        epoch, seq = self.cur.fetchone()
        return Version(int(epoch), int(seq))

    def set_version(self, kind: str, v: Version) -> None:
        self.cur.execute("UPDATE rv2_version SET epoch = %s, seq = %s WHERE kind = %s", (v.epoch, v.seq, kind))

    def upsert(self, rec: dict[str, Any], actor: str) -> None:
        vals = (rec["kind"], rec["key"], rec["epoch"], rec["seq"], rec["hash"], rec["deleted"], rec["op"], rec["sig"],
                orjson.dumps(rec["body"]).decode())
        self.cur.execute(
            f"INSERT INTO rv2_record ({_REC_COLS}) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s::jsonb) "
            "ON CONFLICT (kind, key) DO UPDATE SET epoch = EXCLUDED.epoch, seq = EXCLUDED.seq, hash = EXCLUDED.hash, "
            "deleted = EXCLUDED.deleted, op = EXCLUDED.op, sig = EXCLUDED.sig, body = EXCLUDED.body, updated_at = now()",
            vals)
        self.cur.execute(f"INSERT INTO rv2_log ({_REC_COLS}, actor) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s::jsonb, %s)",
                         (*vals, actor))

    def records(self, kind: str) -> list[dict[str, Any]]:
        self.cur.execute(f"SELECT {_REC_COLS} FROM rv2_record WHERE kind = %s ORDER BY key", (kind,))
        return [_row(r) for r in self.cur.fetchall()]

    def snapshot(self, kind: str) -> tuple[Version, list[dict[str, Any]]]:
        self.cur.execute("INSERT INTO rv2_version (kind, epoch, seq) VALUES (%s, 1, 0) ON CONFLICT DO NOTHING", (kind,))
        self.cur.execute("SELECT epoch, seq FROM rv2_version WHERE kind = %s FOR SHARE", (kind,))
        epoch, seq = self.cur.fetchone()
        return Version(int(epoch), int(seq)), self.records(kind)

    def log_entry(self, log_id: int) -> dict[str, Any] | None:
        self.cur.execute(f"SELECT {_REC_COLS} FROM rv2_log WHERE id = %s", (log_id,))
        r = self.cur.fetchone()
        return _row(r) if r else None


class PgDB:
    """psycopg 3; one short-lived connection per operation (control-plane CLI / re-hydrator rates)."""

    def __init__(self, dsn: str) -> None:
        import psycopg

        self.psycopg = psycopg
        self.dsn = dsn

    def _conn(self) -> Any:
        return self.psycopg.connect(self.dsn, connect_timeout=5, autocommit=False)

    def init_schema(self) -> None:
        with self._conn() as c, c.cursor() as cur:
            cur.execute(SCHEMA)
            for kind in KINDS:
                cur.execute("INSERT INTO rv2_version (kind, epoch, seq) VALUES (%s, 1, 0) ON CONFLICT DO NOTHING", (kind,))

    @contextlib.contextmanager
    def tx(self) -> Iterator[_PgTx]:
        """An exception in the body rolls back (nothing durable). A failure of COMMIT itself is CommitUnknown."""
        c = self._conn()
        try:
            with c.cursor() as cur:
                yield _PgTx(cur)
            try:
                c.commit()
            except self.psycopg.Error as exc:
                raise CommitUnknown(f"{type(exc).__name__}: {exc}"[:300]) from exc
        except BaseException:
            try:
                if not c.closed:
                    c.rollback()
            except self.psycopg.Error:
                pass  # the connection is gone: the server rolls an uncommitted transaction back itself
            raise
        finally:
            c.close()

    def version(self, kind: str) -> Version:
        with self.tx() as t:
            return t.version(kind, lock=False)

    def records(self, kind: str) -> list[dict[str, Any]]:
        with self.tx() as t:
            return t.records(kind)

    def snapshot(self, kind: str) -> tuple[Version, list[dict[str, Any]]]:
        with self.tx() as t:
            return t.snapshot(kind)

    def checkpoint(self, remaining: dict[str, tuple[int, Version]]) -> None:
        with self._conn() as c, c.cursor() as cur:
            for org, (n, v) in remaining.items():
                cur.execute("INSERT INTO rv2_budget_checkpoint (org, remaining, at, epoch, seq) "
                            "VALUES (%s, %s, now(), %s, %s) ON CONFLICT (org) DO UPDATE SET "
                            "remaining = EXCLUDED.remaining, at = now(), epoch = EXCLUDED.epoch, seq = EXCLUDED.seq",
                            (org, n, v.epoch, v.seq))

    def checkpoints(self) -> dict[str, tuple[int, Version]]:
        with self._conn() as c, c.cursor() as cur:
            cur.execute("SELECT org, remaining, epoch, seq FROM rv2_budget_checkpoint")
            return {o: (int(n), Version(int(e), int(q))) for o, n, e, q in cur.fetchall()}


@dataclass
class _MemState:
    versions: dict[str, Version]
    records: dict[tuple[str, str], dict[str, Any]]
    log: list[dict[str, Any]]
    checkpoints: dict[str, tuple[int, Version]]


class _MemTx:
    def __init__(self, st: _MemState) -> None:
        self.st = st

    def version(self, kind: str, *, lock: bool) -> Version:
        return self.st.versions.setdefault(kind, Version(1, 0))

    def set_version(self, kind: str, v: Version) -> None:
        self.st.versions[kind] = v

    def upsert(self, rec: dict[str, Any], actor: str) -> None:
        self.st.records[(rec["kind"], rec["key"])] = dict(rec)
        self.st.log.append(dict(rec, actor=actor, id=len(self.st.log) + 1, at=time.time()))

    def records(self, kind: str) -> list[dict[str, Any]]:
        return [dict(r) for (k, _), r in sorted(self.st.records.items()) if k == kind]

    def snapshot(self, kind: str) -> tuple[Version, list[dict[str, Any]]]:
        return self.version(kind, lock=False), self.records(kind)

    def log_entry(self, log_id: int) -> dict[str, Any] | None:
        e = next((x for x in self.st.log if x["id"] == log_id), None)
        return None if e is None else {k: v for k, v in e.items() if k not in ("actor", "id", "at")}


class MemDB:
    """Transactional in-memory twin of PgDB (unit tests): a failed transaction leaves no trace."""

    def __init__(self) -> None:
        self.st = _MemState({k: Version(1, 0) for k in KINDS}, {}, [], {})
        self.lock = threading.Lock()
        self.fail_next = False  # test hook: the next transaction raises before commit
        self.commit_unknown_next = False  # test hook: the next transaction commits, then its acknowledgement is lost

    def init_schema(self) -> None:
        return None

    @contextlib.contextmanager
    def tx(self) -> Iterator[_MemTx]:
        with self.lock:
            work = _MemState(dict(self.st.versions), dict(self.st.records), list(self.st.log), dict(self.st.checkpoints))
            yield _MemTx(work)
            if self.fail_next:
                self.fail_next = False
                raise ConnectionError("injected database failure")
            self.st = work
            if self.commit_unknown_next:
                self.commit_unknown_next = False
                raise CommitUnknown("injected: connection lost during COMMIT")

    def version(self, kind: str) -> Version:
        return self.st.versions.get(kind, Version(1, 0))

    def records(self, kind: str) -> list[dict[str, Any]]:
        return _MemTx(self.st).records(kind)

    def snapshot(self, kind: str) -> tuple[Version, list[dict[str, Any]]]:
        with self.lock:
            return _MemTx(self.st).snapshot(kind)

    def checkpoint(self, remaining: dict[str, tuple[int, Version]]) -> None:
        self.st.checkpoints.update(remaining)

    def checkpoints(self) -> dict[str, tuple[int, Version]]:
        return dict(self.st.checkpoints)
