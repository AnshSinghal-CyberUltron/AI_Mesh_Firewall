"""The ONE queue of a guard owner (its GPU): admission, backlog accounting and state pushes.

Admission, C10 on, RV_OWNER_ADMISSION=codel (default): shed (503 + Retry-After) only on a STANDING queue.
  - Sojourn = how long a request waited before it started to run (FIFO, one executor).
  - The owner enters "overloaded" once every request that started over RV_OWNER_INTERVAL_MS waited at least
    RV_OWNER_TARGET_MS (CoDel's detector: the minimum sojourn over an interval stays above the target).
  - While overloaded it admits a request only if the current backlog is below the target, which keeps the
    standing queue near the target instead of shedding bursts.
  - It leaves that state once a whole interval passes without a shed: demand is back under capacity. (The
    sojourn of ADMITTED requests cannot end it: holding them under the target is exactly what the state does.)
  - A hard cap (RV_OWNER_QUEUE_MS of work, default 60) always applies, for memory and overload safety.
  - The per-request budget shed is optional (RV_OWNER_BUDGET_SHED, default off): a burst makes a few
    requests late instead of shedding them, since sheds count as failures and 1% may be late.
RV_OWNER_ADMISSION=bound (rc1): shed when the backlog plus the request would exceed RV_OWNER_QUEUE_MS
(default 12), or (budget shed, default on) when the predicted wait + own execution exceeds its budget.
C10 off: the frozen-1 bound (pool_size(GUARD) of the AMF target), no budget check.
A request arriving into an empty queue always runs. Retry-After of a shed = the backlog's drain time, at
least the request's own execution time.
Backlog = queued + running padded tokens / measured tokens/s, minus the time the running item has already
run, so neither admission nor the pushed state over-counts the work in progress. The time integrals
owner_backlog_ns_x_s and owner_windows_x_ms let the exporter report the average queue over any window
(autoscaling signal) without sampling.
State pushes (C43 on): after every change, one STATE frame per subscribed worker connection, coalesced
to at most one per event-loop iteration.
"""

from __future__ import annotations

import asyncio
import json
import sys
import time
from collections import deque
from collections.abc import Callable

from rvproto.detect.guard import wire
from rvproto.runtime.config import Settings
from rvproto.runtime.metrics import Registry


class Entry:
    """One admitted request: its cost, and when it was queued and started (0 = still waiting)."""

    __slots__ = ("cost", "windows", "queued_ns", "started_ns")

    def __init__(self, cost: int, windows: int, queued_ns: int) -> None:
        self.cost, self.windows, self.queued_ns, self.started_ns = cost, windows, queued_ns, 0


class OwnerQueue:
    def __init__(self, s: Settings, metrics: Registry, *, tokens_per_s: float, frozen_cap_tokens: int,
                 clock: Callable[[], int] = time.perf_counter_ns) -> None:
        c10 = s.v2.c10
        self.metrics = metrics
        self.clock = clock
        self.codel = c10.codel
        self.budget_check = c10.on and c10.budget_shed
        self.tps = tokens_per_s
        self.cap_tokens = int(tokens_per_s * c10.owner_queue_ms / 1000.0) if c10.on else frozen_cap_tokens
        self.target_ns = int(c10.target_ms * 1e6)
        self.interval_ns = int(c10.interval_ms * 1e6)
        self.cap_reason = "hard_cap" if self.codel else "queue_bound"
        self.queued_tokens = 0
        self.queued_windows = 0
        self._items: deque[Entry] = deque()  # admitted, unfinished, FIFO (the head runs once started)
        self.overloaded = False
        self._first_above = 0  # CoDel: when started requests began to wait >= target without a break
        self._last_shed = 0  # while overloaded: the last shed (a whole interval without one ends the state)
        self.draining = False
        self.subscribers: set[asyncio.StreamWriter] = set()
        self._push_pending = False
        self._t = clock()

    def describe(self) -> dict[str, object]:
        return {"admission": "codel" if self.codel else "bound", "cap_tokens": self.cap_tokens,
                "target_ms": self.target_ns / 1e6, "interval_ms": self.interval_ns / 1e6,
                "budget_shed": self.budget_check}

    def backlog_ns(self, now: int | None = None) -> int:
        if not self.queued_tokens:
            return 0
        full = self.queued_tokens / self.tps * 1e9
        head = self._items[0] if self._items else None
        if head is not None and head.started_ns:
            ran = (now or self.clock()) - head.started_ns
            full -= min(max(ran, 0), head.cost / self.tps * 1e9)
        return int(max(full, 0))

    def _acct(self, now: int) -> None:
        dt, self._t = now - self._t, now
        if dt > 0 and self.queued_tokens:
            self.metrics.inc("owner_backlog_ns_x_s", int(self.backlog_ns(now) * dt / 1e9))
            self.metrics.inc("owner_windows_x_ms", int(self.queued_windows * dt / 1e6))

    def _shed_reason(self, cost_tokens: int, wait_ns: int, budget_ns: int) -> str | None:
        if self.queued_tokens + cost_tokens > self.cap_tokens:
            return self.cap_reason
        if self.codel and self.overloaded and wait_ns >= self.target_ns:
            return "standing_queue"
        if self.budget_check and wait_ns + cost_tokens / self.tps * 1e9 > budget_ns:
            return "budget"
        return None

    def admit(self, cost_tokens: int, windows: int, budget_ns: int) -> Entry | float:
        """The admitted request's Entry (pass it to finish()), or the Retry-After seconds of a SHED: the
        backlog's drain time, at least the request's own execution time."""
        now = self.clock()
        wait_ns = self.backlog_ns(now)
        if self.overloaded and now - self._last_shed >= self.interval_ns:
            self._leave_overload("no_shed_for_an_interval")
        if self._items:
            reason = self._shed_reason(cost_tokens, wait_ns, budget_ns)
            if reason is not None:
                self._last_shed = now
                self.metrics.inc("owner_shed")
                self.metrics.inc(f'owner_shed_reason{{reason="{reason}"}}')
                return max(wait_ns / 1e9, cost_tokens / self.tps)
        self._acct(now)
        entry = Entry(cost_tokens, windows, now)
        self._items.append(entry)
        if len(self._items) == 1:
            self._start(entry, now)  # into an empty queue: it runs at once
        self.queued_tokens += cost_tokens
        self.queued_windows += windows
        self._changed()
        return entry

    def finish(self, entry: Entry) -> None:
        now = self.clock()
        self._acct(now)
        was_head = bool(self._items) and self._items[0] is entry
        try:
            self._items.remove(entry)  # the FIFO head normally; a cancelled request anywhere
        except ValueError:
            return  # finished twice: already accounted
        self.queued_tokens -= entry.cost
        self.queued_windows -= entry.windows
        if not self._items:
            self._first_above = 0  # no standing queue
        elif was_head and not self._items[0].started_ns:
            self._start(self._items[0], now)
        self._changed()

    def _start(self, entry: Entry, now: int) -> None:
        """The executor takes `entry`: its sojourn drives the CoDel detector."""
        entry.started_ns = now
        sojourn = now - entry.queued_ns
        self.metrics.observe("owner_sojourn_ns", sojourn)
        if not self.codel:
            return
        if sojourn < self.target_ns:
            self._first_above = 0
            return
        if not self._first_above:
            self._first_above = now
        elif not self.overloaded and now - self._first_above >= self.interval_ns:
            self.overloaded = True
            self._last_shed = now
            self.metrics.inc("owner_overload_entered")
            self.metrics.set("owner_overloaded", 1)
            _log("guard_owner_overloaded", sojourn_ms=round(sojourn / 1e6, 3), backlog_ms=round(self.backlog_ns(now) / 1e6, 3))

    def _leave_overload(self, why: str) -> None:
        self._first_above = 0
        self.overloaded = False
        self.metrics.set("owner_overloaded", 0)
        _log("guard_owner_overload_cleared", reason=why)

    def set_draining(self) -> None:
        self.draining = True
        self._changed()

    def subscribe(self, writer: asyncio.StreamWriter) -> None:
        self.subscribers.add(writer)
        writer.write(wire.encode_state(self.backlog_ns(), self.queued_windows, self.draining))

    def _changed(self) -> None:
        m = self.metrics
        m.set("owner_backlog_ns", self.backlog_ns())
        m.set("owner_queued_windows", self.queued_windows)
        m.set("owner_queued_tokens", self.queued_tokens)
        if self.subscribers and not self._push_pending:
            self._push_pending = True
            asyncio.get_running_loop().call_soon(self._push)

    def _push(self) -> None:
        self._push_pending = False
        frame = wire.encode_state(self.backlog_ns(), self.queued_windows, self.draining)
        n = 0
        for w in list(self.subscribers):
            if w.is_closing():
                self.subscribers.discard(w)
                continue
            try:
                w.write(frame)
                n += 1
            except (RuntimeError, OSError):  # the worker went away between the check and the write
                self.subscribers.discard(w)
        self.metrics.inc("owner_state_pushes", n)


def _log(event: str, **kw: object) -> None:
    sys.stderr.write(json.dumps({"event": event, "t": time.time(), **kw}) + "\n")
