"""Guard owner: ONE process per GPU owns the TensorRT session (guard-bench: N per-worker
sessions on one L4 fall from 466 to 186-270 windows/s). Workers send windows over a Unix socket
(owner on the same node) and/or TCP (a guard-only node serving remote gateway workers), as set by
RV_GUARD_OWNER_LISTEN; the owner runs them FIFO on its single inference thread (MicroBatcher,
B=1). Protocol and frame validation: wire.py.

The owner's queue is THE guard queue of its GPU, so it is bounded here: accepted, unfinished
padded tokens <= pool_size(GUARD) of the owner's own measured rate (work that drains within the
p99 target); beyond it a request is refused at once (SHED -> 503 + Retry-After at the worker)
instead of queueing into deadline expiry, which would turn overload into UNAVAILABLE findings.
A request larger than the whole bound is accepted only into an empty queue.

The TCP listener is unauthenticated: bind it to the VPC-internal address only
(deploy/start_guard_node.sh).

rvproto-2: admission and backlog accounting live in owner_queue.py (C10 budget-aware shed, C43 state
pushes to subscribed workers). SIGTERM drains: the owner re-registers as draining, answers NEW work from
subscribed workers with REDIRECT (they re-route), finishes its queue and exits within RV_GUARD_DRAIN_S.
A TCP owner registers itself in the store for discovery (discovery.py) when RV_REDIS_URL is reachable.
"""

from __future__ import annotations

import asyncio
import json
import os
import signal
import socket
import sys
import time
from pathlib import Path

from tokenizers import Tokenizer

from rvproto.detect.guard import wire
from rvproto.detect.guard.batcher import padded_cost
from rvproto.detect.guard.discovery import OwnerRegistration
from rvproto.detect.guard.owner_queue import Entry, OwnerQueue
from rvproto.detect.guard.local_onnx import LocalOnnxBackend
from rvproto.domain.guard import Budget, GuardResult
from rvproto.runtime import contract as rc
from rvproto.runtime.config import Settings
from rvproto.runtime.loopguard import install_gc_probe, tune_gc
from rvproto.runtime.shm_metrics import ShmRegistry, make_registry, metrics_tag


def _vocab(s: Settings) -> int | None:
    return Tokenizer.from_file(s.guard_tokenizer).get_vocab_size() if s.guard_tokenizer else None


class GuardOwner:
    def __init__(self, s: Settings, index: int, *, gpu: bool, model_hash: str) -> None:
        self.s = s
        self.index = index
        self.path = wire.socket_path(s.guard_socket_dir, index)
        self.geo = wire.Geometry(s.max_windows, s.window_tokens, _vocab(s))
        if s.guard_owner_listen_tcp is not None and self.geo.vocab is None:
            raise ValueError("a TCP guard owner needs RV_GUARD_TOKENIZER (token ids are range-checked)")
        self.metrics = make_registry(index, on=s.v2.c38.on, tag=metrics_tag(f"o{s.port}"), role="o",
                                     slots=s.v2.c38.shm_slots)
        self.backend = LocalOnnxBackend(s, self.metrics, gpu=gpu, device_id=index if gpu else 0,
                                        model_hash=model_hash)
        self.clients = 0
        self.hello: dict[str, object] = {}
        self.q: OwnerQueue | None = None
        self.reg: OwnerRegistration | None = None
        self._stop = asyncio.Event()
        self._last_work = time.monotonic()

    @property
    def cap_tokens(self) -> int:
        return self.q.cap_tokens if self.q is not None else 0

    @property
    def queued_tokens(self) -> int:
        return self.q.queued_tokens if self.q is not None else 0

    def _advertise(self) -> tuple[str, int] | None:
        adv = self.s.v2.c43.advertise
        if adv:
            host, _, port = adv.rpartition(":")
            return host, int(port) + self.index
        if self.s.guard_owner_listen_tcp is None:
            return None
        host, port = self.s.guard_owner_listen_tcp
        return host, port + self.index

    async def serve(self) -> None:
        await self.backend.start()
        install_gc_probe(self.metrics)
        sys.stderr.write(json.dumps({"event": "loop_hygiene", "owner": self.index, **tune_gc(self.s)}, default=str) + "\n")
        tokens_per_s = self.backend.tokens_per_s
        assert tokens_per_s is not None
        contract, _ = rc.load()
        frozen_cap = rc.derive(rc.with_guard(contract, tokens_per_s), self.s).guard_queue_tokens or 0
        self.q = OwnerQueue(self.s, self.metrics, tokens_per_s=tokens_per_s, frozen_cap_tokens=frozen_cap)
        self.hello = {"host": socket.gethostname(), "index": self.index, "pid": os.getpid(),
                      "tokens_per_s": tokens_per_s, "model_hash": self.backend.model_hash,
                      "provider": self.backend.providers[0], "proto": 2}
        servers, endpoints = await self._listen()
        ready = {**self.hello, "endpoints": endpoints, "queue_cap_tokens": self.cap_tokens, "admission": self.q.describe()}
        Path(self.s.guard_socket_dir).mkdir(mode=0o700, parents=True, exist_ok=True)
        tmp = Path(f"{self.path}.ready.{os.getpid()}.tmp")
        tmp.write_text(json.dumps(ready))
        tmp.replace(self.path + ".ready")
        sys.stderr.write(json.dumps({"event": "guard_owner_ready", **ready, "detail": self.backend.detail}) + "\n")
        tasks = [asyncio.create_task(self._gauges())]
        adv = self._advertise()
        if adv is not None and self.s.redis_url:
            self.reg = OwnerRegistration(self.s.redis_url, advertise=adv, hello=self.hello,
                                         ttl_ms=self.s.v2.c43.register_ttl_ms)
            tasks.append(asyncio.create_task(self.reg.run()))
        asyncio.get_running_loop().add_signal_handler(signal.SIGTERM, self._stop.set)
        serving = [asyncio.create_task(srv.serve_forever()) for srv in servers]
        try:
            await self._stop.wait()
            await self._drain()
        finally:
            for t in (*tasks, *serving):
                t.cancel()
            if self.reg is not None:
                await self.reg.remove()

    async def _listen(self) -> tuple[list[asyncio.Server], list[str]]:
        servers, endpoints = [], []
        if self.s.guard_owner_listen_unix:  # bound only now: connectable == warm
            Path(self.path).unlink(missing_ok=True)
            servers.append(await asyncio.start_unix_server(self._client, path=self.path))
            os.chmod(self.path, 0o600)
            endpoints.append(f"unix:{self.path}")
        if self.s.guard_owner_listen_tcp is not None:
            host, port = self.s.guard_owner_listen_tcp
            servers.append(await asyncio.start_server(self._client, host, port + self.index))
            endpoints.append(f"{host}:{port + self.index}")
        return servers, endpoints

    async def _drain(self) -> None:
        """Stop taking new work (subscribed workers are told and re-route), finish the queue, exit."""
        assert self.q is not None
        self.q.set_draining()
        if self.reg is not None:
            await self.reg.draining()
        t0 = time.monotonic()
        bound = self.s.v2.c43.guard_drain_s
        sys.stderr.write(json.dumps({"event": "guard_owner_draining", "owner": self.index, "bound_s": bound}) + "\n")
        while time.monotonic() - t0 < bound:
            if self.q.queued_tokens == 0 and time.monotonic() - self._last_work > 0.5:
                break
            await asyncio.sleep(0.05)
        self.metrics.set("owner_drain_s", time.monotonic() - t0)
        sys.stderr.write(json.dumps({"event": "guard_owner_drained", "owner": self.index,
                                     "s": round(time.monotonic() - t0, 3), "left_tokens": self.q.queued_tokens}) + "\n")


    async def _gauges(self) -> None:
        def dump() -> None:
            if isinstance(self.metrics, ShmRegistry):  # C38: the node exporter dumps; only ask for it
                self.metrics.request_dump()
            elif self.s.metrics_dir:
                self.metrics.dump(self.s.metrics_dir, stem="owner")

        asyncio.get_running_loop().add_signal_handler(signal.SIGUSR1, dump)  # li experiment / C38
        last = 0.0
        periodic = self.s.metrics_dump_s > 0 and not isinstance(self.metrics, ShmRegistry)
        while True:
            m = self.metrics
            m.set("owner_clients", self.clients)
            m.set("owner_queue_cap_tokens", self.cap_tokens)
            stats = getattr(self.backend, "queue_stats", None)
            if stats is not None:
                items, windows, age = stats()
                m.set("guard_queue_items", items)
                m.set("guard_queue_windows", windows)
                m.set("guard_queue_oldest_age_seconds", age)
            if self.backend.tokens_per_s is not None:
                m.set("guard_tokens_per_s", self.backend.tokens_per_s)
            if periodic and time.monotonic() - last >= self.s.metrics_dump_s:
                dump()
                last = time.monotonic()
            await asyncio.sleep(1.0)

    async def _client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        assert self.q is not None
        self.clients += 1
        peer = writer.get_extra_info("peername")
        pending: set[asyncio.Task[None]] = set()
        inflight: dict[int, asyncio.Future[GuardResult]] = {}
        subscribed = False
        writer.write(wire.encode_response(0, GuardResult(True, (), 0, 0, 0, json.dumps(self.hello))))
        try:
            while True:
                (n_bytes,) = wire.U32.unpack(await reader.readexactly(4))
                if n_bytes > self.geo.max_request:
                    raise wire.FrameError(f"request frame of {n_bytes} bytes > {self.geo.max_request}")
                req_id, budget_ns, rows = wire.decode_request(await reader.readexactly(n_bytes), self.geo)
                if not rows:
                    if req_id == 0 and budget_ns == wire.SUBSCRIBE_BUDGET and self.s.v2.c43.on:
                        subscribed = True  # C43: this worker gets our backlog on every change
                        self.q.subscribe(writer)
                        continue
                    gone = inflight.pop(req_id, None)
                    if gone is not None and gone.cancel():  # the MicroBatcher skips cancelled items
                        self.metrics.inc("owner_cancels")
                    continue
                self._last_work = time.monotonic()
                if self.q.draining and subscribed:
                    self.metrics.inc("owner_redirects")
                    writer.write(wire.encode_redirect(req_id, "guard owner draining"))
                    continue
                self._submit(req_id, budget_ns, rows, writer, inflight, pending)
        except wire.FrameError as exc:  # unauthenticated listener: drop the connection, never the engine
            self.metrics.inc("owner_bad_frames")
            sys.stderr.write(json.dumps({"event": "guard_owner_bad_frame", "peer": str(peer), "error": str(exc)}) + "\n")
        except (asyncio.IncompleteReadError, ConnectionError):
            pass  # the worker went away: its queued windows are cancelled below, never run
        finally:
            self.clients -= 1
            self.q.subscribers.discard(writer)
            for t in pending:
                t.cancel()
            writer.close()

    def _submit(self, req_id: int, budget_ns: int, rows: list[object], writer: asyncio.StreamWriter,
                inflight: dict[int, asyncio.Future[GuardResult]], pending: set[asyncio.Task[None]]) -> None:
        assert self.q is not None
        deadline = time.perf_counter_ns() + budget_ns  # re-anchored on this host's clock
        self.metrics.inc("owner_requests")
        cost = padded_cost(rows, self.s.guard_seq_buckets)  # type: ignore[arg-type]
        entry = self.q.admit(cost, len(rows), budget_ns)
        if isinstance(entry, float):
            writer.write(wire.encode_response(req_id, GuardResult(
                False, (), 0, 0, 0, "guard owner queue full", retry_after_s=entry)))
            return
        self.metrics.inc("owner_windows", len(rows))
        fut = self.backend.submit(rows, Budget(deadline))  # type: ignore[arg-type]  # FIFO into the ONE thread
        inflight[req_id] = fut
        fut.add_done_callback(lambda f, r=req_id, e=entry: self._finished(inflight, r, e))
        task = asyncio.ensure_future(self._reply(req_id, fut, writer))
        pending.add(task)
        task.add_done_callback(pending.discard)

    def _finished(self, inflight: dict[int, asyncio.Future[GuardResult]], req_id: int, entry: Entry) -> None:
        inflight.pop(req_id, None)
        assert self.q is not None
        self.q.finish(entry)

    async def _reply(self, req_id: int, fut: asyncio.Future[GuardResult], writer: asyncio.StreamWriter) -> None:
        try:
            res = await fut
        except asyncio.CancelledError:
            return  # cancelled by the worker: nothing to report
        if writer.is_closing():
            return  # the worker went away: nobody to answer
        try:
            writer.write(wire.encode_response(req_id, res))
        except (RuntimeError, OSError):
            pass


def run_owner(s: Settings, index: int, gpu: bool, model_hash: str) -> None:
    import uvloop

    owner = GuardOwner(s, index, gpu=gpu, model_hash=model_hash)
    try:
        uvloop.run(owner.serve())
    finally:
        if isinstance(owner.metrics, ShmRegistry):
            owner.metrics.close()
