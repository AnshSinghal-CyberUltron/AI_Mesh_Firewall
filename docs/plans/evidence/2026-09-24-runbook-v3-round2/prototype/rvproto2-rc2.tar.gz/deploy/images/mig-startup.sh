#!/bin/bash
# rvproto-2 MIG startup script (instance template metadata `startup-script`), one per role:
#   metadata  rv-role        gateway | guard
#             rv-image       asia-south1-docker.pkg.dev/ai-mesh-firewall/rv-r2/<gateway|guard>@sha256:...
#             rv-env         KEY=VALUE lines passed to the container (RV_REDIS_URL, RV_DATABASE_URL, ...)
#             rv-hmac-secret (optional) projects/<p>/secrets/<name>/versions/latest -> RV_STATE_HMAC_KEY,
#                            read with the instance service account (roles/secretmanager.secretAccessor)
# Host images: gateway = Container-Optimized OS (cos-stable); guard = the rv-proto-unit family (Ubuntu
# DLVM, NVIDIA driver 580, docker + nvidia runtime; CUDA 13 in the image needs driver >= 580).
# Pair with mig-shutdown.sh as `shutdown-script`: `docker stop` = SIGTERM = drain (gateway: 15 s not-ready
# + up to 60 s in-flight streams; guard: redirect new windows, finish the queue, <= 30 s).
set -euo pipefail
MD=http://metadata.google.internal/computeMetadata/v1
md() { curl -sf -H 'Metadata-Flavor: Google' "$MD/$1"; }
ROLE=$(md instance/attributes/rv-role)
IMAGE=$(md instance/attributes/rv-image)
ENVF=/run/rv2.env
umask 077
md instance/attributes/rv-env > "$ENVF" || : > "$ENVF"
SECRET=$(md instance/attributes/rv-hmac-secret || true)
# JSON without jq/python (COS has neither): the API answers pretty-printed ("key": "value", one per line)
TOKEN=$(md instance/service-accounts/default/token | sed -nE 's/.*"access_token": *"([^"]+)".*/\1/p')
if [[ -n "$SECRET" ]]; then
  KEY=$(curl -sf -H "Authorization: Bearer $TOKEN" "https://secretmanager.googleapis.com/v1/$SECRET:access" \
        | sed -nE 's/.*"data": *"([^"]+)".*/\1/p' | base64 -d)
  [[ -n "$KEY" ]] || { echo "rv2: secret $SECRET has no payload" >&2; exit 1; }
  printf 'RV_STATE_HMAC_KEY=%s\n' "$KEY" >> "$ENVF"
fi
REGISTRY=${IMAGE%%/*}
export DOCKER_CONFIG=/var/lib/rv2/docker                    # writable on COS too (/root is read-only there)
mkdir -p "$DOCKER_CONFIG"
printf '%s' "$TOKEN" | docker login -u oauth2accesstoken --password-stdin "https://$REGISTRY" >/dev/null
# Container-Optimized OS ships a host firewall with policy INPUT DROP (only :22): with --network host the
# LB health checks and proxies could never reach the gateway / guard ports. Harmless on Ubuntu (policy ACCEPT).
envport() { local v; v=$(sed -n "s/^$1=//p" "$ENVF" | tail -1); echo "${v:-$2}"; }
PORTS=("$(envport RV_EXPORTER_PORT 9464)")
if [[ "$ROLE" == guard ]]; then PORTS+=(7070 7071 7072 7073 7074 7075 7076 7077); else PORTS+=("$(envport RV_PORT 8400)"); fi
if command -v iptables >/dev/null; then
  for p in "${PORTS[@]}"; do
    iptables -w -C INPUT -p tcp --dport "$p" -j ACCEPT 2>/dev/null || iptables -w -A INPUT -p tcp --dport "$p" -j ACCEPT
  done
fi
docker rm -f rv2 >/dev/null 2>&1 || true
docker pull -q "$IMAGE"
GPU=(); SHM=512m
if [[ "$ROLE" == guard ]]; then GPU=(--gpus all); SHM=1g; fi
docker run -d --name rv2 --restart=always --network host --shm-size "$SHM" \
  --ulimit nofile=1048576:1048576 --stop-timeout 85 "${GPU[@]}" --env-file "$ENVF" \
  -e RV_MONITORING_RESOURCE=gce_instance "$IMAGE" "$ROLE"
