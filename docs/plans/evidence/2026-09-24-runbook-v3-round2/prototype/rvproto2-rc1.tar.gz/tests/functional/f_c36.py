"""F-C36: FLUSHALL of the store under load, with an engaged org kill switch and a revoked key.

  python tests/functional/f_c36.py on|gap|off
     on   re-hydrator running (1 s period)
     gap  re-hydrator stopped at the FLUSHALL and restarted 10 s later: a gap longer than the 5 s staleness
          ceiling, so valid keys MUST see 503 (never 401/403) until the restore
     off  negative control: frozen-1 state layout and readers (C36 off)

Load: 3 keys at ~15 req/s each (JSON): key-a (org-a, valid), key-b (org-b, org then KILLED), key-q (org-q,
key then REVOKED). t=8 s: kill org-b + revoke key-q (on: control plane, Postgres first; off: frozen tools).
t=14 s: FLUSHALL. On: the re-hydrator (1 s period) restores from Postgres. Off: nothing restores.
PASS (on): 0 requests of org-b admitted and 0 with key-q accepted after the change settled (1 refresh
period); every non-200 for key-a is 503 (never 401/403); the store re-hydrated (bound measured from
the FLUSHALL to the re-hydrator's restore); key-a back to 200 after the restore; org-b still refused.
Negative control (off) is expected to FAIL those checks (reproducing the frozen-1 defects).
"""

from __future__ import annotations

import asyncio
import json
import sys
import time
from collections import Counter
from pathlib import Path

import aiohttp

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ftlib as F  # noqa: E402

KEYS = {"a": "sk-rv-org-a-0001", "b": "sk-rv-org-b-0001", "q": "sk-rv-org-q-0001"}


async def client(port: int, stop_at: float, rec: list[dict[str, object]]) -> None:
    body = {"model": "gpt-4o-mini", "messages": [{"role": "user", "content": "hello, a short answer please"}],
            "max_tokens": 16}
    async with aiohttp.ClientSession() as s:
        async def one(name: str, key: str) -> None:
            t = time.time()
            try:
                async with s.post(f"http://127.0.0.1:{port}/v1/chat/completions", json=body,
                                  headers={"authorization": f"Bearer {key}"}, timeout=aiohttp.ClientTimeout(total=10)) as r:
                    txt = await r.text()
                    code = ""
                    if r.status != 200:
                        try:
                            code = json.loads(txt)["error"]["code"]
                        except (ValueError, KeyError, TypeError):
                            code = txt[:60]
                    rec.append({"t": t, "k": name, "status": r.status, "code": code})
            except (aiohttp.ClientError, asyncio.TimeoutError) as exc:
                rec.append({"t": t, "k": name, "status": 0, "code": type(exc).__name__})

        tasks = []
        while time.time() < stop_at:
            for name, key in KEYS.items():
                tasks.append(asyncio.create_task(one(name, key)))
            await asyncio.sleep(1 / 15)
        await asyncio.gather(*tasks)


def main(mode: str) -> int:
    F.stop_all()
    out = Path.home() / "rv2" / "logs" / f"f_c36_{mode}"
    F.valkey("flushall")
    port, env = 8400, {"RV_GUARD_TOPOLOGY": "owner", "WEB_CONCURRENCY": "4", "RV_PORT": "8400",
                       "RV_FIX_C36": "off" if mode == "off" else "on", "RV_KS_REFRESH_MS": "500",
                       "RV_KS_STALE_MS": "5000"}
    if mode != "off":
        F.control("init-db")
        F.control("seed")
    else:
        import subprocess

        subprocess.run([F.PY, "tools/seed.py", "redis://127.0.0.1:16379/0", "--flush"], cwd=F.TREE, check=True,
                       capture_output=True)
    F.synthprov(out)
    F.start("rvproto", [F.PY, "-m", "rvproto.serve"], out, **env)
    reh = F.start("rehydrator", [F.PY, "-m", "rvproto.control", "rehydrate"], out) if mode != "off" else None
    F.wait_ready(port)
    rec: list[dict[str, object]] = []
    t0 = time.time()
    marks: dict[str, float] = {}

    async def scenario() -> None:
        load = asyncio.create_task(client(port, t0 + 40, rec))
        await asyncio.sleep(8)
        if mode != "off":
            F.control("killswitch", "org", "org-b", "on")
            F.control("key-revoke", KEYS["q"])
        else:
            import subprocess

            subprocess.run([F.PY, "tools/killswitch.py", "redis://127.0.0.1:16379/0", "org", "org-b", "on"],
                           cwd=F.TREE, check=True, capture_output=True)
            import hashlib  # frozen-1 revocation: drop the key from rv:keys and bump rv:auth_epoch
            h = hashlib.sha256(KEYS["q"].encode()).hexdigest()
            F.valkey("hdel", "rv:keys", h)
            F.valkey("incr", "rv:auth_epoch")
        marks["changed"] = time.time()
        await asyncio.sleep(6)
        if mode == "gap" and reh is not None:
            F.stop(reh, timeout=5)
        marks["flushall"] = time.time()
        F.valkey("flushall")
        if mode == "gap":
            await asyncio.sleep(10)
            marks["rehydrator_restarted"] = time.time()
            F.start("rehydrator", [F.PY, "-m", "rvproto.control", "rehydrate"], out)
        await load

    asyncio.run(scenario())
    settle = marks["changed"] + 1.5
    after = [r for r in rec if float(r["t"]) >= settle]  # type: ignore[arg-type]
    by = {k: Counter((r["status"], r["code"]) for r in after if r["k"] == k) for k in KEYS}
    b_admitted = sum(1 for r in after if r["k"] == "b" and r["status"] == 200)
    q_accepted = sum(1 for r in after if r["k"] == "q" and r["status"] == 200)
    gap = [r for r in rec if float(r["t"]) >= marks["flushall"]]  # type: ignore[arg-type]
    a_bad = [r for r in gap if r["k"] == "a" and r["status"] in (401, 403)]
    a_503 = [float(r["t"]) for r in gap if r["k"] == "a" and r["status"] == 503]  # type: ignore[arg-type]
    a_ok_after = [float(r["t"]) for r in gap if r["k"] == "a" and r["status"] == 200 and a_503 and float(r["t"]) > max(a_503)]  # type: ignore[arg-type]
    restored = None
    if reh is not None:
        for line in (out / "rehydrator.log").read_text().splitlines():
            try:
                d = json.loads(line)
            except ValueError:
                continue
            if d.get("event") == "rehydrated" and float(d["detected_at"]) >= marks["flushall"]:
                restored = max(restored or 0.0, float(d["restored_at"]))
    result = {
        "mode": mode, "requests": len(rec), "marks": marks, "after_change": {k: dict(map(lambda x: (str(x[0]), x[1]), v.items())) for k, v in by.items()},
        "org_b_admitted_after_kill": b_admitted, "key_q_accepted_after_revoke": q_accepted,
        "key_a_401_403_in_gap": len(a_bad), "key_a_503_in_gap": len(a_503),
        "gap_first_503_s": round(min(a_503) - marks["flushall"], 3) if a_503 else None,
        "gap_last_503_s": round(max(a_503) - marks["flushall"], 3) if a_503 else None,
        "rehydrated_after_flush_s": round(restored - marks["flushall"], 3) if restored else None,
        "key_a_200_after_restore": len(a_ok_after),
    }
    ok = (b_admitted == 0 and q_accepted == 0 and not a_bad and (mode == "off" or bool(restored))
          and bool(a_ok_after or not a_503) and (mode != "gap" or bool(a_503)))
    result["verdict"] = ("PASS" if ok else "FAIL") + (" (expected FAIL: negative control)" if mode == "off" else "")
    F.save(f"f_c36_{mode}", result)
    F.stop_all()
    print(json.dumps(result, indent=1, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1] if len(sys.argv) > 1 else "on"))
