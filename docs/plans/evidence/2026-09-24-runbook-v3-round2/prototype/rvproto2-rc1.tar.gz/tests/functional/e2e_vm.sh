#!/usr/bin/env bash
# The PROTO_SPEC E2E suite (tests/e2e) against rvproto-2 on the dev VM: C38/C10/C43 ON (defaults),
# C36 OFF (the suite seeds and inspects the frozen-1 store layout), CPU guard per worker (as round 1's
# local acceptance: its dev SLO AMF_TARGET_P99_MS=2000 is declared for C10 as RV_OWNER_QUEUE_MS=2000),
# synthprov as the provider. Usage: bash tests/functional/e2e_vm.sh [extra NAME=VALUE ...]
set -uo pipefail
source ~/rv2/env.sh
L=~/rv2/logs/e2e; rm -rf $L; mkdir -p $L
pkill -f "[r]vproto.serve"; pkill -f "[s]ynthprov"; sleep 1; rm -f /dev/shm/rv2m-* /dev/shm/rv2-node-*
sudo docker exec rv2-redis valkey-cli flushall >/dev/null
$PY tools/seed.py redis://127.0.0.1:16379/0 --flush > $L/seed.json
setsid nohup ~/rv2/bin/synthprov -listen 127.0.0.1:18080 -record $L/provider-records.jsonl -ttft 50ms -itl 5ms -tokens 20 \
  > $L/synthprov.log 2>&1 < /dev/null &
env RV_FIX_C36=off RV_GUARD_BACKEND=local_cpu RV_GUARD_CPU_THREADS=2 RV_GUARD_DEADLINE_MS=5000 AMF_TARGET_P99_MS=2000 \
  RV_OWNER_QUEUE_MS=2000 WEB_CONCURRENCY=2 RV_ADMIN_HOOKS=1 RV_GUARD_BATCH=8 RV_GUARD_WAIT_US=1000 RV_GUARD_SEQ_BUCKETS=64,128,256,512 "$@" \
  setsid nohup $PY -m rvproto.serve > $L/rvproto.log 2>&1 < /dev/null &
for i in $(seq 1 240); do curl -sf -m 2 localhost:8400/readyz > $L/readyz.json 2>/dev/null && break; sleep 1; done
head -c 200 $L/readyz.json; echo
PROVIDER_KIND=synthprov PROVIDER_RECORDS=$L/provider-records.jsonl timeout ${E2E_TIMEOUT:-900} $PY -m pytest tests/e2e ${E2E_ARGS:--q} -p no:cacheprovider -rs \
  --junitxml=$L/junit.xml > $L/pytest.txt 2>&1; rc=$?
tail -15 $L/pytest.txt
pkill -f "[r]vproto.serve"; pkill -f "[s]ynthprov"
echo "E2E_RC=$rc"
