"""F-DRAIN: guard discovery + guard drain + gateway drain under load (autoscaling support).

  python tests/functional/f_drain.py

Phase G (guards, simulated engines, discovery through the store): one gateway (4 workers) starts with
NO static owner and becomes ready once owner A registers; owner B joins live; under constant load owner A
gets SIGTERM (drain: re-registers draining, REDIRECTs new work, finishes its queue, exits); owner C joins
later; then every owner registration is wiped from the store for 2.5 s (as a flush or a failover to an
empty replica does) while B and C keep running. PASS: no request fails because of a drain, a join or the
lost registrations (every non-200 is a capacity SHED counted by an owner, 0 UNAVAILABLE guard findings,
0 worker-side timeouts), the workers KEPT the live owners (guard_owner_kept_unregistered > 0), A drained
and exited 0 within its bound, and B and C both received work.
Phase W (gateway): SSE streams (~6 s each) in flight when the gateway launcher gets SIGTERM with
RV_DRAIN_ACCEPT_S=4: /readyz turns 503 at once, responses carry `connection: close` while it keeps
accepting, then it stops accepting and finishes in-flight streams within RV_DRAIN_S. PASS: every request
started before the SIGTERM completed (200 with [DONE], or a policy BLOCK), readyz 503 within 1 s, a
request during the accept window answered with `connection: close`, launcher exit code 0. (Requests olg
kept sending after the accept window are refused at connect: a load balancer has removed the node by then.)
"""

from __future__ import annotations

import json
import os
import signal
import sys
import threading
import time
from pathlib import Path

import redis

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import ftlib as F  # noqa: E402


def owner(out: Path, port: int) -> object:
    return F.start(f"owner{port}", [F.PY, "tests/functional/fake_engine_owner.py", "0"], out,
                   RV_GUARD_OWNER_LISTEN=f"tcp://127.0.0.1:{port}", RV_METRICS_TAG=f"fo{port}", RV_GUARD_BATCH="1",
                   RV_GUARD_SEQ_BUCKETS="512", RV_GUARD_MODEL_SHA256="sim", FAKE_PER_WINDOW_MS="2.0",
                   RV_GUARD_DRAIN_S="20", RV_GUARD_SOCKET_DIR=f"/tmp/rv2-fo{port}")  # own ready file per owner


def phase_g(out: Path) -> dict[str, object]:
    gw_env = {"RV_GUARD_TOPOLOGY": "remote", "RV_GUARD_DISCOVERY": "store", "RV_GUARD_MODEL_SHA256": "sim",
              "WEB_CONCURRENCY": "4", "RV_PORT": "8401", "RV_METRICS_TAG": "8401", "RV_EXPORTER_PORT": "9465"}
    F.start("gw", [F.PY, "-m", "rvproto.serve"], out, **gw_env)
    time.sleep(5)
    before_owner = F.http("http://127.0.0.1:8401/readyz", timeout=3)[0]
    a = owner(out, 7071)
    F.wait_ready(8401)
    b = owner(out, 7072)
    time.sleep(3)
    events: dict[str, float] = {}

    def script() -> None:
        time.sleep(20)
        events["sigterm_a"] = time.time()
        a.send_signal(signal.SIGTERM)  # type: ignore[attr-defined]
        a.wait(40)  # type: ignore[attr-defined]
        events["a_exited"] = time.time()
        events["a_rc"] = a.returncode  # type: ignore[attr-defined]
        time.sleep(5)
        events["start_c"] = time.time()
        owner(out, 7073)
        time.sleep(8)
        events["wipe_registrations"] = time.time()
        r = redis.Redis.from_url(os.environ["RV_REDIS_URL"])
        while time.time() - events["wipe_registrations"] < 2.5:  # longer than two discovery polls
            r.delete("{rv2}:guard:owners", *r.keys("{rv2}:guard:owner:*"))
            time.sleep(0.05)
        events["wipe_end"] = time.time()

    th = threading.Thread(target=script, daemon=True)
    th.start()
    reqs = F.measured(F.olg("http://127.0.0.1:8401", 120, 60, out / "olg_g", sse_frac=0.0, ramp=3, warmup=2))
    th.join(60)
    st: dict[str, int] = {}
    for r in reqs:
        st[str(r.get("status"))] = st.get(str(r.get("status")), 0) + 1
    ex = F.exporter(9465)
    c = ex["count"]
    per_owner, sheds = {}, 0
    from rvproto.runtime.exporter import Segment

    for port in (7071, 7072, 7073):
        p = Path(f"/dev/shm/rv2m-fo{port}-o0")
        if p.exists():
            cnt = Segment(p).export()["count"]
            per_owner[port] = cnt.get("owner_requests", 0)
            sheds += cnt.get("owner_shed", 0)
    log_a = (out / "owner7071.log").read_text()
    drained = [json.loads(x) for x in log_a.splitlines() if '"guard_owner_drained"' in x]
    res = {"readyz_before_any_owner": before_owner, "status": st, "events": events,
           "a_drained": drained[-1] if drained else None, "owner_requests_seen": per_owner,
           "redirects_seen_by_workers": c.get("guard_owner_redirects", 0), "drain_seen": c.get("guard_owner_drain_seen", 0),
           "owners_added": c.get("guard_owner_added", 0), "owners_removed": c.get("guard_owner_removed", 0),
           "owners_kept_unregistered": c.get("guard_owner_kept_unregistered", 0),
           "owner_sheds_b_c": sheds, "guard_unavailable_findings": c.get("guard_unavailable_findings", 0),
           "guard_owner_timeouts": c.get("guard_owner_timeouts", 0)}
    non200 = sum(v for k, v in st.items() if k != "200")
    res["pass"] = (before_owner == 503 and non200 <= sheds and c.get("guard_unavailable_findings", 0) == 0
                   and c.get("guard_owner_timeouts", 0) == 0 and bool(drained) and events.get("a_rc") == 0
                   and per_owner.get(7073, 0) > 0 and per_owner.get(7072, 0) > 0
                   and c.get("guard_owner_kept_unregistered", 0) > 0)
    F.stop_all()
    return res


def phase_w(out: Path) -> dict[str, object]:
    F.synthprov(out, flags="-ttft 150ms -itl 20ms")
    gw = F.start("unit", [F.PY, "-m", "rvproto.serve"], out, RV_GUARD_TOPOLOGY="owner", WEB_CONCURRENCY="4",
                 RV_PORT="8400", RV_DRAIN_ACCEPT_S="4", RV_DRAIN_S="30")
    F.wait_ready(8400)
    marks: dict[str, object] = {}

    def script() -> None:
        time.sleep(15)
        marks["sigterm"] = time.time()
        gw.send_signal(signal.SIGTERM)  # type: ignore[attr-defined]
        for _ in range(20):
            code, hdr, _ = F.http("http://127.0.0.1:8400/readyz", timeout=1)
            if code == 503:
                marks["readyz_503_after_s"] = round(time.time() - float(marks["sigterm"]), 3)  # type: ignore[arg-type]
                break
            time.sleep(0.05)
        body = json.dumps({"model": "gpt-4o-mini", "messages": [{"role": "user", "content": "hi"}], "max_tokens": 4}).encode()
        code, hdr, _ = F.http("http://127.0.0.1:8400/v1/chat/completions", data=body, timeout=10,
                              headers={"authorization": "Bearer sk-rv-org-a-0001", "content-type": "application/json"})
        marks["during_accept_window"] = {"status": code, "connection": hdr.get("connection")}
        gw.wait(60)  # type: ignore[attr-defined]
        marks["exited_after_s"] = round(time.time() - float(marks["sigterm"]), 3)  # type: ignore[arg-type]
        marks["rc"] = gw.returncode  # type: ignore[attr-defined]

    th = threading.Thread(target=script, daemon=True)
    th.start()
    reqs = F.olg("http://127.0.0.1:8400", 20, 25, out / "olg_w", sse_frac=1.0, ramp=2, warmup=2)
    th.join(90)
    sig = float(marks.get("sigterm", 0))  # type: ignore[arg-type]
    from datetime import datetime

    man = json.loads((out / "olg_w" / "manifest.json").read_text())
    t_start = datetime.fromisoformat(man["start_wall_utc"].replace("Z", "+00:00")[:26] + "+00:00").timestamp()
    pre = [r for r in reqs if t_start + int(r.get("sched_ns", 0)) / 1e9 < sig]
    incomplete = [r for r in pre if not (r.get("status") == 200 and r.get("done_seen"))
                  and not (r.get("status") == 403 and (r.get("disp") or "").upper() == "BLOCK")]
    res_pre = {"started_before_sigterm": len(pre), "status_pre": _count(pre, "status")}
    res = {"marks": marks, "requests": len(reqs), "status": _count(reqs, "status"), **res_pre,
           "incomplete_or_failed_among_started_before": len(incomplete), "err": _count(reqs, "err")}
    acc = marks.get("during_accept_window") or {}
    res["pass"] = (marks.get("rc") == 0 and not incomplete and float(marks.get("readyz_503_after_s", 9)) <= 1.0  # type: ignore[arg-type]
                   and acc.get("status") == 200 and acc.get("connection") == "close")  # type: ignore[union-attr]
    F.stop_all()
    return res


def _count(reqs: list[dict[str, object]], k: str) -> dict[str, int]:
    out: dict[str, int] = {}
    for r in reqs:
        out[str(r.get(k))] = out.get(str(r.get(k)), 0) + 1
    return out


def main() -> int:
    F.stop_all()
    out = Path.home() / "rv2" / "logs" / "f_drain"
    F.valkey("flushall")
    F.control("init-db")
    F.control("seed")
    F.synthprov(out)
    g = phase_g(out)
    w = phase_w(out)
    result = {"guard_phase": g, "gateway_phase": w, "verdict": "PASS" if g["pass"] and w["pass"] else "FAIL"}
    F.save("f_drain", result)
    print(json.dumps(result, indent=1, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
