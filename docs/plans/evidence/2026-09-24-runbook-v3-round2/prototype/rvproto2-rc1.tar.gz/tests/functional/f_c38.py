"""F-C38: loop isolation on the all-in-one unit (6 workers + the L4 owner), C4 per request from raw records.

  python tests/functional/f_c38.py on|off|burst [RATE]
     on     rvproto-2 defaults (metrics in shared memory + exporter, tokenizer thread pool, GC frozen)
     off    negative control: C38 off + the frozen-1 periodic metrics dump (RV_METRICS_DUMP_S=1)
     burst  on + RV_INJECT_CPU_BURST=0:50:1 (worker 0 busy-loops 50 ms every second); attribution in
            x-rv-stages so every request names its worker; C4 is reported for worker 0 and the others
Load: olg open loop (default 120 req/s), 70/30 SSE/JSON, headline corpus, -sample-mod 1 on olg AND synthprov.
C4 per request as the controller's c4_client_all.py (holdback excluded): JSON = client total minus the
provider's time; SSE = max(that, max over client events of arrival - emission of the provider piece that
released it); non-qualified = +inf. Loop lag / GC pauses per worker from the metric dumps (window deltas).
This is a FUNCTIONAL check on a g2-standard-8; the C38 claim itself (>= 200 RPS on g2-standard-24) is the
r2unit lane's measurement.
"""

from __future__ import annotations

import bisect
import json
import math
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ftlib as F  # noqa: E402


def c4_per_request(reqs: list[dict[str, object]], prov: dict[str, dict[str, object]]) -> list[tuple[float, bool, int]]:
    """(C4 ms, stream?, worker index or -1) per measured request."""
    out = []
    for c in reqs:
        stages = str(c.get("stages") or "")
        wk = -1
        if "attr:" in stages:
            for part in stages.split("attr:", 1)[1].split(";"):
                if part.startswith("wk="):
                    wk = int(part[3:])
        p = prov.get(str(c.get("rid")))
        ok = c.get("status") == 200 and c.get("done_seen") and not c.get("err") and p is not None
        if not ok:
            if c.get("status") in (400, 403, 422, 451) and (c.get("disp") or "").upper() == "BLOCK":
                continue  # policy stratum, not C4
            out.append((math.inf, bool(c.get("stream")), wk))
            continue
        total = (int(c["end_ns"]) - int(p["recv_to_last_ns"])) / 1e6  # type: ignore[call-overload,index]
        if not c.get("stream"):
            out.append((total, False, wk))
            continue
        e, P, a, C = p.get("emit_ns"), p.get("emit_cum"), c.get("arr_ns"), c.get("arr_cum")  # type: ignore[union-attr]
        if not (e and P and a and C and C[-1] == P[-1]):  # type: ignore[index]
            continue
        dm = max(a[k] - e[min(bisect.bisect_left(P, C[k]), len(P) - 1)] for k in range(len(a))) / 1e6  # type: ignore[index,arg-type]
        out.append((max(total, dm), True, wk))
    return out


def p99(xs: list[float]) -> float | None:
    if not xs:
        return None
    s = sorted(xs)
    return s[min(int(0.99 * len(s)), len(s) - 1)]


def main(mode: str, rate: float) -> int:
    F.stop_all()
    out = Path.home() / "rv2" / "logs" / f"f_c38_{mode}"
    F.valkey("flushall")
    F.control("init-db")
    F.control("seed")
    prov_dir = out / "prov"
    prov_dir.mkdir(parents=True, exist_ok=True)
    F.synthprov(out, flags=f"-ttft 150ms -itl 20ms -sample-mod 1 -record {prov_dir}/records.jsonl")
    env = {"RV_GUARD_TOPOLOGY": "owner", "WEB_CONCURRENCY": "6", "RV_PORT": "8400"}
    if mode == "off":
        env.update(RV_FIX_C38="off", RV_METRICS_DUMP_S="1")
    if mode == "burst":
        env.update(RV_INJECT_CPU_BURST="0:50:1", RV_ATTRIBUTION="stages")
    F.start("rvproto", [F.PY, "-m", "rvproto.serve"], out, **env)
    F.wait_ready(8400)
    time.sleep(2)
    mdir = "/dev/shm/rv2-metrics"
    ramp, warm, dur = 5, 15, 60
    import threading

    snaps: dict[str, dict[str, dict[str, object]]] = {}

    def snap(delay: float, key: str) -> None:
        time.sleep(delay)
        if mode != "off":
            F.http("http://127.0.0.1:9464/dump")
        else:
            time.sleep(1.2)  # the workers' own 1 s dumps
        snaps[key] = F.dump_files(mdir)

    ths = [threading.Thread(target=snap, args=(3 + ramp + warm, "a")),
           threading.Thread(target=snap, args=(3 + ramp + warm + dur - 2, "b"))]
    for t in ths:
        t.start()
    reqs = F.measured(F.olg("http://127.0.0.1:8400", rate, dur, out / "olg", ramp=ramp, warmup=warm))
    for t in ths:
        t.join()
    F.stop_all()  # synthprov flushes its records on exit
    prov = {}
    for r in F.read_jsonl(prov_dir, "records.jsonl"):
        rid = r.get("rid")
        if rid:
            prov[str(rid)] = r
    c4 = c4_per_request(reqs, prov)
    workers = {}
    for name, b in snaps.get("b", {}).items():
        a = snaps.get("a", {}).get(name)
        if not name.startswith("worker") or a is None:
            continue
        d = F.diff_export(a, b)
        lag = d["hist"].get("loop_lag_ns")
        gcs = {g: d["hist"].get(f'gc_pause_ns{{gen="{g}"}}') for g in (0, 1, 2)}
        workers[name] = {"loop_lag_p99_ms": round(F.hist_q(lag, 0.99), 3), "loop_lag_p999_ms": round(F.hist_q(lag, 0.999), 3),
                         "loop_lag_max_ms": round((lag or {}).get("max", 0) / 1e6, 3),
                         "gc_gen2_n": (gcs[2] or {}).get("n", 0), "gc_gen2_max_ms": round((gcs[2] or {}).get("max", 0) / 1e6, 3)}
    all_c4 = [x for x, _, _ in c4]
    result = {"mode": mode, "rate": rate, "measured": len(reqs), "c4_samples": len(c4),
              "c4_p99_ms": p99(all_c4), "c4_sse_p99_ms": p99([x for x, s, _ in c4 if s]),
              "c4_json_p99_ms": p99([x for x, s, _ in c4 if not s]),
              "infra": sum(1 for x in all_c4 if math.isinf(x)), "workers": workers}
    if mode == "burst":
        result["c4_p99_worker0_ms"] = p99([x for x, _, w in c4 if w == 0])
        result["c4_p99_other_workers_ms"] = p99([x for x, _, w in c4 if w > 0])
        result["requests_without_worker_attr"] = sum(1 for _, _, w in c4 if w < 0)
    ok = result["c4_p99_ms"] is not None and result["c4_p99_ms"] < 20 and result["infra"] <= 0.001 * max(len(c4), 1)
    if mode == "burst":
        o = result["c4_p99_other_workers_ms"]
        ok = o is not None and o < 20
    result["verdict"] = ("PASS" if ok else "FAIL") + (" (negative control)" if mode == "off" else "")
    F.save(f"f_c38_{mode}", result)
    print(json.dumps(result, indent=1, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1] if len(sys.argv) > 1 else "on", float(sys.argv[2]) if len(sys.argv) > 2 else 120))
