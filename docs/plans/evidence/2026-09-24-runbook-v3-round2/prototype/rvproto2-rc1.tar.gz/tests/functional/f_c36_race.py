"""F-C36-RACE: concurrent control-plane writers and re-hydrators against real Postgres + Valkey.

  python tests/functional/f_c36_race.py [SECONDS]      (env: RV_DATABASE_URL, RV_REDIS_URL, RV_STATE_HMAC_KEY)

4 writer threads (each toggles the kill switches of 2 orgs and adds / revokes API keys) and 2 re-hydrators
(50 ms period, no stale grace: they race the writers' own publishes on purpose) run for SECONDS (30).
A sampler reads the store's `ks` and `key` kinds (manifest + record set in one MULTI) every 2 ms, as the
gateways do, and verifies each sample like a gateway (signature, digest, never older than seen).
PASS: 0 unverifiable samples, 0 regressions, and every sampled manifest describes EXACTLY the Postgres
state at its version (rebuilt from rv2_log) -- a publish never labels a record set with another version
(a gateway would cache a revoked key as valid under the new auth epoch). Self-contained (no ftlib) so the
same file runs as a negative control inside an older image: `docker run ... gateway:<old> shell -c
"python /ft/f_c36_race.py"`.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import time
from collections import Counter
from pathlib import Path

import redis

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from rvproto.control.db import PgDB  # noqa: E402
from rvproto.control.writer import StateWriter  # noqa: E402
from rvproto.runtime.store import K2_KEYS, K2_KS, K2_META  # noqa: E402
from rvproto.runtime.versioned import (  # noqa: E402
    ZERO,
    StoreDataUnavailable,
    Version,
    digest,
    verify_meta,
    verify_set,
    version_of,
)

HASH = {"ks": K2_KS, "key": K2_KEYS}


def writer(i: int, until: float, stats: Counter[str]) -> None:
    w = StateWriter(PgDB(os.environ["RV_DATABASE_URL"]), redis.Redis.from_url(os.environ["RV_REDIS_URL"]),
                    os.environ["RV_STATE_HMAC_KEY"].encode(), actor=f"race-{i}")
    j, prev = 0, None
    while time.time() < until:
        w.killswitch("org", f"race-{i}-{j % 2}", bool((j // 2) % 2))
        stats["ks_writes"] += 1
        if j % 3 == 0:
            key = f"sk-race-{i}-{j}"
            w.key_add(key, "org-a", key_id=key, rate=1e6, burst=1e6)
            if prev is not None:
                w.key_revoke(prev)
            prev = key
            stats["key_writes"] += 2
        j += 1


def sampler(until: float, samples: dict[tuple[str, Version, str], float], stats: Counter[str], errors: list[str]) -> None:
    r = redis.Redis.from_url(os.environ["RV_REDIS_URL"])
    k = os.environ["RV_STATE_HMAC_KEY"].encode()
    seen = {"ks": ZERO, "key": ZERO}
    while time.time() < until:
        for kind in ("ks", "key"):
            pipe = r.pipeline(transaction=True)
            pipe.get(K2_META + kind)
            pipe.hvals(HASH[kind])
            meta_raw, raws = pipe.execute()
            stats["samples"] += 1
            try:
                meta = verify_meta(k, kind, meta_raw, not_before=seen[kind])
                verify_set(k, kind, meta, raws)
            except StoreDataUnavailable as exc:
                reason = "regressed" if "older" in str(exc) else "unverifiable"
                stats[f"{kind}_{reason}"] += 1
                if len(errors) < 20:
                    errors.append(f"{time.time():.3f} {kind}: {exc}")
                continue
            v = version_of(meta)
            seen[kind] = v
            samples.setdefault((kind, v, meta["digest"]), time.time())
        time.sleep(0.002)


def pg_digests(db: PgDB, kind: str, versions: list[Version]) -> dict[Version, str]:
    """The digest of Postgres's state of `kind` at each version, replayed from the append-only log."""
    with db.tx() as t:
        t.cur.execute("SELECT key, epoch, seq, hash, deleted FROM rv2_log WHERE kind = %s ORDER BY epoch, seq, id",
                      (kind,))
        log = [{"key": a, "epoch": int(b), "seq": int(c), "hash": d, "deleted": bool(e)} for a, b, c, d, e in t.cur.fetchall()]
    out: dict[Version, str] = {}
    cur: dict[str, dict[str, object]] = {}
    i = 0
    for v in sorted(set(versions)):
        while i < len(log) and Version(log[i]["epoch"], log[i]["seq"]) <= v:  # type: ignore[arg-type]
            cur[str(log[i]["key"])] = log[i]
            i += 1
        out[v] = digest(list(cur.values()))  # type: ignore[arg-type]
    return out


def main(seconds: float) -> int:
    until = time.time() + seconds
    env = dict(os.environ, RV_REHYDRATE_PERIOD_MS="50", RV_REHYDRATE_STALE_GRACE_MS="0")
    rehy = [subprocess.Popen([sys.executable, "-m", "rvproto.control", "rehydrate"], env=env, stdout=subprocess.DEVNULL,
                             stderr=subprocess.PIPE, cwd=str(Path(__file__).resolve().parents[2])) for _ in range(2)]
    stats: Counter[str] = Counter()
    samples: dict[tuple[str, Version, str], float] = {}
    errors: list[str] = []
    threads = [threading.Thread(target=writer, args=(i, until, stats)) for i in range(4)]
    threads.append(threading.Thread(target=sampler, args=(until + 2, samples, stats, errors)))
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    rehydrated = Counter()
    for p in rehy:
        p.terminate()
        _, err = p.communicate(timeout=10)
        for line in err.decode(errors="replace").splitlines():
            try:
                d = json.loads(line)
            except ValueError:
                continue
            if d.get("event") in ("rehydrated", "state_publish_skipped", "rehydrate_error"):
                rehydrated[f"{d['event']}:{d.get('reason', d.get('kind'))}"] += 1
    db = PgDB(os.environ["RV_DATABASE_URL"])
    mislabeled = []
    for kind in ("ks", "key"):
        want = pg_digests(db, kind, [v for (k, v, _) in samples if k == kind])
        mislabeled += [f"{kind} {v}: store digest {dig[:12]} != Postgres at that version {want[v][:12]}"
                       for (k, v, dig) in samples if k == kind and want[v] != dig]
    bad = stats["ks_unverifiable"] + stats["key_unverifiable"] + stats["ks_regressed"] + stats["key_regressed"]
    result = {"seconds": seconds, "stats": dict(stats), "distinct_manifests_sampled": len(samples),
              "mislabeled_manifests": len(mislabeled), "mislabeled_examples": mislabeled[:5],
              "sample_errors": errors[:10], "rehydrator_events": dict(rehydrated),
              "verdict": "PASS" if not bad and not mislabeled and len(samples) > 50 else "FAIL"}
    print(json.dumps(result, indent=1, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(float(sys.argv[1]) if len(sys.argv) > 1 else 30))
