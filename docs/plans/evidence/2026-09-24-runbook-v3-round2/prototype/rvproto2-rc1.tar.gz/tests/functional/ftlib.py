"""Functional-test helpers for the rvproto-2 dev VM (Valkey :16379 and Postgres :5432 in containers,
synthprov + olg from the READY harness in ~/rv2/bin, the GPU owner from ~/rv/models + ~/rv/trtcache).
Source ~/rv2/env.sh first. Processes are started in their own session and always stopped."""

from __future__ import annotations

import glob
import json
import os
import signal
import subprocess
import sys
import time
import urllib.request
from pathlib import Path
from typing import Any

HOME = Path.home()
TREE = HOME / "rv2" / "rvproto"
PY = str(HOME / "rv2" / "venv" / "bin" / "python")
BIN = HOME / "rv2" / "bin"
CORPORA = HOME / "rv2" / "corpora"
RESULTS = HOME / "rv2" / "results"
PROCS: list[subprocess.Popen[bytes]] = []


def log(msg: str, **kw: object) -> None:
    print(json.dumps({"t": round(time.time(), 3), "msg": msg, **kw}, default=str), flush=True)


def start(name: str, argv: list[str], logdir: Path, **env: str) -> subprocess.Popen[bytes]:
    logdir.mkdir(parents=True, exist_ok=True)
    full = dict(os.environ, **env)
    p = subprocess.Popen(argv, env=full, cwd=TREE, stdout=open(logdir / f"{name}.log", "ab"),
                         stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, start_new_session=True)
    PROCS.append(p)
    return p


def stop(p: subprocess.Popen[bytes], sig: int = signal.SIGTERM, timeout: float = 30) -> int | None:
    if p.poll() is None:
        try:
            os.killpg(p.pid, sig)
        except ProcessLookupError:
            pass
        try:
            p.wait(timeout)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid, signal.SIGKILL)
            p.wait(5)
    return p.returncode


def stop_all() -> None:
    for p in reversed(PROCS):
        stop(p, timeout=10)
    PROCS.clear()
    subprocess.run(["pkill", "-f", "[r]vproto.serve"], check=False)
    subprocess.run(["pkill", "-f", "[f]ake_engine_owner"], check=False)
    subprocess.run(["pkill", "-f", "[s]ynthprov"], check=False)
    time.sleep(1)
    for p in glob.glob("/dev/shm/rv2m-*") + glob.glob("/dev/shm/rv2-node-*"):
        Path(p).unlink(missing_ok=True)


def http(url: str, *, data: bytes | None = None, headers: dict[str, str] | None = None,
         timeout: float = 10) -> tuple[int, dict[str, str], bytes]:
    req = urllib.request.Request(url, data=data, headers=headers or {}, method="POST" if data else "GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, {k.lower(): v for k, v in r.headers.items()}, r.read()
    except urllib.error.HTTPError as e:
        return e.code, {k.lower(): v for k, v in e.headers.items()}, e.read()


def wait_ready(port: int, timeout: float = 240) -> dict[str, Any]:
    end = time.time() + timeout
    last: dict[str, Any] = {}
    while time.time() < end:
        try:
            code, _, body = http(f"http://127.0.0.1:{port}/readyz", timeout=2)
            last = json.loads(body)
            if code == 200 and last.get("ready"):
                return last
        except (OSError, ValueError):
            pass
        time.sleep(1)
    raise TimeoutError(f"port {port} not ready: {str(last)[:400]}")


def valkey(*args: str) -> str:
    return subprocess.run(["sudo", "docker", "exec", "rv2-redis", "valkey-cli", *args], capture_output=True,
                          text=True, check=True).stdout.strip()


def control(*args: str, **env: str) -> str:
    r = subprocess.run([PY, "-m", "rvproto.control", *args], cwd=TREE, capture_output=True, text=True,
                       env=dict(os.environ, **env))
    if r.returncode != 0:
        raise RuntimeError(f"control {args}: {r.stderr[-500:]}")
    return r.stdout.strip()


def synthprov(logdir: Path, port: int = 18080, flags: str = "-ttft 150ms -itl 20ms") -> subprocess.Popen[bytes]:
    p = start("synthprov", [str(BIN / "synthprov"), "-listen", f":{port}", *flags.split()], logdir)
    time.sleep(1)
    return p


def olg(target: str, rate: float, duration: int, out: Path, *, corpus: str = "headline-22M.jsonl",
        sse_frac: float = 0.7, auth: str = "sk-rv-org-a-0001", extra: tuple[str, ...] = (), ramp: int = 5,
        warmup: int = 5) -> list[dict[str, Any]]:
    """Run the READY open-loop generator (blocking); returns its per-request records."""
    out.mkdir(parents=True, exist_ok=True)
    authf = out / "auth"
    authf.write_text(f"Bearer {auth}")
    authf.chmod(0o600)
    start_at = int(time.time() * 1000) + 3000
    argv = [str(BIN / "olg"), "-targets", target, "-rate", str(rate), "-lg", "0", "-lg-count", "1", "-start-at",
            str(start_at), "-out", str(out), "-run-id", out.name, "-corpus", str(CORPORA / corpus), "-ramp", str(ramp),
            "-warmup", str(warmup), "-duration", str(duration), "-sse-frac", str(sse_frac), "-auth-file", str(authf),
            "-sample-mod", "1", *extra]
    with open(out / "olg.log", "wb") as fh:
        subprocess.run(argv, stdout=fh, stderr=subprocess.STDOUT, check=False, timeout=duration + ramp + warmup + 180)
    return read_jsonl(out, "requests.jsonl")


def read_jsonl(d: Path, name: str) -> list[dict[str, Any]]:
    f = d / name
    if f.exists():
        return [json.loads(x) for x in f.read_text().splitlines() if x.strip()]
    z = d / (name + ".zst")
    if z.exists():
        raw = subprocess.run(["zstd", "-dc", str(z)], capture_output=True, check=True).stdout.decode()
        return [json.loads(x) for x in raw.splitlines() if x.strip()]
    return []


def measured(reqs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """olg phase 2 = the measurement window (ph 0 ramp, 1 warm-up)."""
    return [r for r in reqs if r.get("ph") == 2]


def exporter(port: int = 9464) -> dict[str, Any]:
    return json.loads(http(f"http://127.0.0.1:{port}/metrics.json", timeout=10)[2])


def dump_files(metrics_dir: str) -> dict[str, dict[str, Any]]:
    out = {}
    for p in sorted(Path(metrics_dir).glob("*.json")):
        try:
            out[p.stem] = json.loads(p.read_text())
        except ValueError:
            continue
    return out


def hist_q(h: dict[str, Any] | None, q: float) -> float:
    """Quantile (ms) of an exported histogram {n, b: {bucket: count}, max}."""
    if not h or not h.get("n"):
        return 0.0
    sys.path.insert(0, str(TREE))
    from rvproto.runtime.metrics import _NBUCKETS, quantile_of

    counts = [0] * _NBUCKETS
    for k, c in h["b"].items():
        counts[int(k)] += c
    return quantile_of(counts, int(h["n"]), q, int(h["max"])) / 1e6


def mg1_ratio(owner_export: dict[str, Any], seconds: float) -> dict[str, float]:
    """Pollaczek-Khinchine check on ONE owner's own histograms (see proto-bench-split poisson_check.py)."""
    sys.path.insert(0, str(TREE))
    from rvproto.runtime.metrics import bucket_value

    ex = owner_export["hist"].get("guard_exec_ns")
    qh = owner_export["hist"].get("guard_queue_ns")
    if not ex or not qh or not ex["n"]:
        return {}
    n = ex["n"]
    es = ex["sum"] / n / 1e9
    es2 = sum(bucket_value(int(k)) ** 2 * c for k, c in ex["b"].items()) / n / 1e18
    lam = n / seconds
    rho = lam * es
    wpk = lam * es2 / (2 * (1 - rho)) if rho < 1 else float("inf")
    floor = hist_q(qh, 0.25) / 1e3
    wmeas = max(qh["sum"] / qh["n"] / 1e9 - floor, 0.0)
    return {"req_per_s": round(lam, 1), "rho": round(rho, 3), "wait_mean_ms": round(wmeas * 1e3, 3),
            "mg1_mean_ms": round(wpk * 1e3, 3), "ratio": round(wmeas / wpk, 3) if wpk else 0.0,
            "wait_p99_ms": round(hist_q(qh, 0.99), 3)}


def diff_export(a: dict[str, Any], b: dict[str, Any]) -> dict[str, Any]:
    """b - a for one process export (window deltas of histograms and counters)."""
    hist = {}
    for name, hb in b["hist"].items():
        ha = a["hist"].get(name, {"n": 0, "sum": 0, "b": {}})
        bk = {k: c - ha["b"].get(k, 0) for k, c in hb["b"].items() if c - ha["b"].get(k, 0)}
        hist[name] = {"n": hb["n"] - ha["n"], "sum": hb["sum"] - ha["sum"], "max": hb["max"], "b": bk}
    count = {k: v - a["count"].get(k, 0) for k, v in b["count"].items()}
    return {"hist": hist, "count": count, "gauge": b.get("gauge", {})}


def save(name: str, result: dict[str, Any]) -> Path:
    RESULTS.mkdir(parents=True, exist_ok=True)
    p = RESULTS / f"{name}.json"
    p.write_text(json.dumps(result, indent=1, default=str))
    log("saved", path=str(p), verdict=result.get("verdict"))
    return p
