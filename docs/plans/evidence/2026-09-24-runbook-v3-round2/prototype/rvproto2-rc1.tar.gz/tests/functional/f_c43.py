"""F-C43: load-aware guard routing, 3 gateways x 4 workers -> 3 owners (simulated B=1 engines), discovery.

  python tests/functional/f_c43.py on|off     (off = negative control: per-worker round-robin, C43 off)

Owners: tests/functional/fake_engine_owner.py (the real owner process; its one inference thread sleeps
0.2 ms + FAKE_PER_WINDOW_MS per window), each registered in the store; gateways find them by discovery
(no static addresses). Load: olg constant rate over the three gateways, per-owner utilisation ~0.6.
The simulated engine is 3x slower than an L4 (6 ms/window) to keep the load within one dev VM, so the
SLO the guard deadline derives from and the owner queue bound are scaled 3x as well (RV_SLO_MS=60,
RV_OWNER_QUEUE_MS=36): this test is about ROUTING; C10 must not shed because the simulated engine is slow.
Per owner, over the measurement window: mean queue wait / M/G/1 (Pollaczek-Khinchine) prediction, as
proto-bench-split poisson_check.py. PASS (on): every owner's ratio well below the round-1 0.65-0.71
(< 0.4 here) and below the same run with C43 off; the workers' guard wait p99 lower than off.
"""

from __future__ import annotations

import json
import re
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import ftlib as F  # noqa: E402

from rvproto.runtime.exporter import Segment  # noqa: E402

OWNER_PORTS = (7071, 7072, 7073)
GW_PORTS = (8401, 8402, 8403)
PER_WINDOW_MS = "6.0"
RATE, DUR = 180, 60


def owner_exports() -> dict[int, dict[str, object]]:
    out = {}
    for port in OWNER_PORTS:
        p = Path(f"/dev/shm/rv2m-fo{port}-o0")
        if p.exists():
            out[port] = Segment(p).export()
    return out


def main(mode: str) -> int:
    F.stop_all()
    out = Path.home() / "rv2" / "logs" / f"f_c43_{mode}"
    F.valkey("flushall")
    F.control("init-db")
    F.control("seed")
    F.synthprov(out)
    for port in OWNER_PORTS:
        F.start(f"owner{port}", [F.PY, "tests/functional/fake_engine_owner.py", "0"], out,
                RV_GUARD_OWNER_LISTEN=f"tcp://127.0.0.1:{port}", RV_METRICS_TAG=f"fo{port}", RV_GUARD_BATCH="1",
                RV_GUARD_SEQ_BUCKETS="512", RV_GUARD_MODEL_SHA256="sim", FAKE_PER_WINDOW_MS=PER_WINDOW_MS,
                RV_FIX_C43=mode, RV_OWNER_QUEUE_MS="36", RV_GUARD_SOCKET_DIR=f"/tmp/rv2-fo{port}")  # own ready file
    for port in GW_PORTS:
        F.start(f"gw{port}", [F.PY, "-m", "rvproto.serve"], out, RV_GUARD_TOPOLOGY="remote", RV_GUARD_DISCOVERY="store",
                RV_GUARD_MODEL_SHA256="sim", WEB_CONCURRENCY="4", RV_PORT=str(port), RV_METRICS_TAG=str(port),
                RV_EXPORTER_PORT=str(port + 1000), RV_GUARD_FLEET_WORKERS="12", RV_FIX_C43=mode, RV_SLO_MS="60")
    for port in GW_PORTS:
        F.wait_ready(port)
    routable = {}
    for _ in range(60):  # a valid run (either mode) routes over all three owners from every gateway
        routable = {p: int(re.search(r"owners (\d+)/", F.wait_ready(p)["guard"]["detail"]).group(1)) for p in GW_PORTS}  # type: ignore[union-attr]
        if all(n == len(OWNER_PORTS) for n in routable.values()):
            break
        time.sleep(0.5)
    time.sleep(3)  # every worker has discovered all three owners
    detail = F.wait_ready(GW_PORTS[0])["guard"]["detail"]
    targets = ",".join(f"http://127.0.0.1:{p}" for p in GW_PORTS)
    holder: dict[str, object] = {}

    def snap_at(delay: float, key: str) -> None:
        time.sleep(delay)
        holder[key] = (time.time(), owner_exports(), [F.exporter(p + 1000) for p in GW_PORTS])

    import threading

    ramp, warm = 5, 10
    th0 = threading.Thread(target=snap_at, args=(3 + ramp + warm, "t0"))  # olg starts ~3 s after launch
    th1 = threading.Thread(target=snap_at, args=(3 + ramp + warm + DUR - 1, "t1"))
    th0.start()
    th1.start()
    reqs = F.measured(F.olg(targets, RATE, DUR, out / "olg", sse_frac=0.0, ramp=ramp, warmup=warm))
    th0.join()
    th1.join()
    (t0, o0, g0), (t1, o1, g1) = holder["t0"], holder["t1"]  # type: ignore[misc]
    secs = t1 - t0
    ratios = {port: F.mg1_ratio(F.diff_export(o0[port], o1[port]), secs) for port in OWNER_PORTS if port in o0 and port in o1}
    gw = [F.diff_export(a, b) for a, b in zip(g0, g1, strict=True)]
    waits = [F.hist_q(x["hist"].get("t_guard_wait_ns"), 0.99) for x in gw]
    st: dict[str, int] = {}
    for r in reqs:
        st[str(r.get("status"))] = st.get(str(r.get("status")), 0) + 1
    sheds = {port: {k: v for k, v in F.diff_export(o0[port], o1[port])["count"].items() if k.startswith("owner_shed")}
             for port in OWNER_PORTS if port in o0 and port in o1}
    result = {"mode": mode, "discovered": detail[:300], "owners_routable_per_gateway": routable, "offered": len(reqs),
              "status": st, "owner_sheds": sheds,
              "owner_mg1": ratios, "gateway_guard_wait_p99_ms": [round(w, 3) for w in waits],
              "window_s": round(secs, 1)}
    ok = bool(ratios) and all(v.get("ratio", 1) < 0.4 for v in ratios.values()) and len(ratios) == 3
    result["verdict"] = ("PASS" if ok else "FAIL") + (" (negative control)" if mode == "off" else "")
    if len(ratios) != len(OWNER_PORTS) or any(n != len(OWNER_PORTS) for n in routable.values()):
        result["verdict"] = f"INVALID: {len(ratios)} of {len(OWNER_PORTS)} owners served"
    F.save(f"f_c43_{mode}", result)
    F.stop_all()
    print(json.dumps(result, indent=1, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1] if len(sys.argv) > 1 else "on"))
