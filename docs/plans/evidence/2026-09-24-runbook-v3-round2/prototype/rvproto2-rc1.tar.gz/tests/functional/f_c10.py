"""F-C10: 3x overload of ONE guard owner (all-in-one unit, real L4 owner slowed by RV_INJECT_OWNER_DELAY_MS).

  python tests/functional/f_c10.py on|off [NAME=VALUE ...]   (off = negative control: frozen-1 admission)
Both are run with the round-1 unit-lane configuration AMF_TARGET_P99_MS=1000 (which lifted the frozen
per-worker bounds); off also pins RV_GUARD_DEADLINE_MS=20 as round 1 did, so the frozen owner queue may
hold ~1 s of work against a 20 ms deadline. On ignores the AMF target for every guard bound (separate knobs).

Load: olg open loop at 3x the owner's capacity for 30 s, org-b (FAIL_OPEN posture: an UNAVAILABLE guard
lets the request through without the detector = a FAIL_OPEN event), 70/30 SSE/JSON, headline corpus.
PASS (on): sheds happen AT THE OWNER (owner_shed > 0) as 503 + Retry-After; 0 FAIL_OPEN (no 200 with
sem:U); 0 guard deadline expiries; admitted work waits at most the owner bound (owner guard_queue_ns p99
<= RV_OWNER_QUEUE_MS x 1.1); the derived guard deadline is below the SLO. The injected 4 ms/window makes
multi-window executions themselves exceed the SLO, so t_input is reported, not judged. Off is expected to
show FAIL_OPEN > 0.
"""

from __future__ import annotations

import json
import sys
import threading
import time
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ftlib as F  # noqa: E402

RATE, DUR = 300, 30


def probe_retry_after(port: int, stop: threading.Event, out: list[dict[str, str]]) -> None:
    body = json.dumps({"model": "gpt-4o-mini", "messages": [{"role": "user", "content": "probe " * 40}],
                       "max_tokens": 8}).encode()
    while not stop.is_set():
        code, hdr, _ = F.http(f"http://127.0.0.1:{port}/v1/chat/completions", data=body, timeout=10,
                              headers={"authorization": "Bearer sk-rv-org-b-0001", "content-type": "application/json"})
        if code == 503:
            out.append({"retry-after": hdr.get("retry-after", ""), "retry-after-ms": hdr.get("retry-after-ms", "")})
        time.sleep(0.2)


def main(mode: str, extra: dict[str, str]) -> int:
    F.stop_all()
    out = Path.home() / "rv2" / "logs" / f"f_c10_{mode}"
    F.valkey("flushall")
    F.control("init-db")
    F.control("seed")
    F.synthprov(out)
    port = 8400
    F.start("rvproto", [F.PY, "-m", "rvproto.serve"], out, RV_GUARD_TOPOLOGY="owner", WEB_CONCURRENCY="6",
            RV_PORT=str(port), RV_FIX_C10=mode, RV_INJECT_OWNER_DELAY_MS="4", RV_METRICS_DUMP_S="0", **extra)
    F.wait_ready(port)
    before = F.exporter()
    stop, ra = threading.Event(), []
    th = threading.Thread(target=probe_retry_after, args=(port, stop, ra), daemon=True)
    th.start()
    reqs = F.measured(F.olg(f"http://127.0.0.1:{port}", RATE, DUR, out / "olg", auth="sk-rv-org-b-0001"))
    stop.set()
    after = F.exporter()
    st = Counter(r.get("status", 0) for r in reqs)
    fail_open = sum(1 for r in reqs if r.get("status") == 200 and "sem:U" in (r.get("stages") or ""))
    owners = after.get("owners", [])
    ob = {o["owner"]: o for o in before.get("owners", [])}
    owner_counts = {o["owner"]: {k: v - ob.get(o["owner"], {}).get("count", {}).get(k, 0)
                                 for k, v in o["count"].items() if k.startswith("owner_shed") or k == "owner_requests"}
                    for o in owners}
    wc = {k: after["count"].get(k, 0) - before["count"].get(k, 0)
          for k in ("guard_deadline_expired", "guard_unavailable_findings", "guard_owner_sheds", "admitted")}
    summ = after.get("summary", {})
    deadlines = sorted({round(float(pw["gauge"].get("guard_deadline_ms", 0)), 2) for pw in after.get("per_worker", [])})
    t_input_p99 = summ.get("t_input_ns", {}).get("p99_ms")
    owner_q = [o["summary"].get("guard_queue_ns", {}).get("p99_ms") for o in owners]
    owner_x = [o["summary"].get("guard_exec_ns", {}).get("p99_ms") for o in owners]
    result = {"mode": mode, "env": extra, "offered": len(reqs), "status": {str(k): v for k, v in sorted(st.items())},
              "fail_open_200_with_sem_U": fail_open, "owner": owner_counts, "worker": wc,
              "retry_after_probes": len(ra), "retry_after_present": sum(1 for x in ra if x["retry-after"]),
              "retry_after_ms_sample": [x["retry-after-ms"] for x in ra[:5]],
              "derived_guard_deadline_ms": deadlines, "t_input_p99_ms_cumulative": t_input_p99,
              "owner_queue_p99_ms": owner_q, "owner_exec_p99_ms": owner_x}
    sheds_at_owner = sum(v.get("owner_shed", 0) for v in owner_counts.values())
    ok = (sheds_at_owner > 0 and fail_open == 0 and wc["guard_deadline_expired"] == 0 and st.get(503, 0) > 0
          and (not ra or all(x["retry-after"] for x in ra)) and all(q is not None and q <= 12 * 1.1 for q in owner_q)
          and all(d < 20 for d in deadlines))
    result["verdict"] = ("PASS" if ok else "FAIL") + (" (negative control)" if mode == "off" else "")
    F.save(f"f_c10_{mode}", result)
    F.stop_all()
    print(json.dumps(result, indent=1, default=str))
    return 0


if __name__ == "__main__":
    m = sys.argv[1] if len(sys.argv) > 1 else "on"
    ex = dict(kv.split("=", 1) for kv in sys.argv[2:])
    ex.setdefault("AMF_TARGET_P99_MS", "1000")
    if m == "off":
        ex.setdefault("RV_GUARD_DEADLINE_MS", "20")
    raise SystemExit(main(m, ex))
