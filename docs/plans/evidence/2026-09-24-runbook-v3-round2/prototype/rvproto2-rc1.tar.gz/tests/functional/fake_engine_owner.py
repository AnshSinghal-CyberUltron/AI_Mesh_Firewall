"""A guard owner process whose engine is SIMULATED on its one inference thread (functional tests of
routing, admission and drain without a GPU per owner): each batch of windows sleeps
FAKE_BASE_MS + FAKE_PER_WINDOW_MS x windows (x U(1-FAKE_JITTER, 1+FAKE_JITTER)) and answers p = 0.001.
Everything else is the real owner (owner.py, owner_queue.py, wire.py, discovery registration).

  RV_GUARD_OWNER_LISTEN=tcp://127.0.0.1:7071 RV_GUARD_TOKENIZER=... python tests/functional/fake_engine_owner.py 0
"""

from __future__ import annotations

import os
import random
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from rvproto.detect.guard import owner  # noqa: E402
from rvproto.detect.guard.local_onnx import LocalOnnxBackend  # noqa: E402
from rvproto.runtime.config import load_settings  # noqa: E402

BASE = float(os.environ.get("FAKE_BASE_MS", "0.2")) / 1000
PER = float(os.environ.get("FAKE_PER_WINDOW_MS", "2.0")) / 1000
JIT = float(os.environ.get("FAKE_JITTER", "0.1"))


class SimEngine(LocalOnnxBackend):
    def _make_session(self) -> object:
        self.providers = ["SimulatedEngine"]
        return object()

    def _warmup(self) -> float:
        return 1 * self.max_seq / (BASE + PER)  # tokens/s of a 1-window batch, like the real warm-up

    def _infer(self, ids: np.ndarray, mask: np.ndarray) -> np.ndarray:
        time.sleep((BASE + PER * ids.shape[0]) * random.uniform(1 - JIT, 1 + JIT))
        return np.tile(np.array([[3.0, -3.9]], dtype=np.float32), (ids.shape[0], 1))


if __name__ == "__main__":
    owner.LocalOnnxBackend = SimEngine  # type: ignore[misc,assignment]
    owner.run_owner(load_settings(), int(sys.argv[1]), gpu=False, model_hash=os.environ.get("RV_GUARD_MODEL_SHA256", "sim"))
