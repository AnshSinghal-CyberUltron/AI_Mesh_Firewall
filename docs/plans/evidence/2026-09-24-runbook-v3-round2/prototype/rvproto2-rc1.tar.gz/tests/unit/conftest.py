"""Unit-test session hygiene: fake owners write C38 shared-memory metric segments under a per-session
tag; remove whatever a killed process left behind."""

from __future__ import annotations

import os
from collections.abc import Iterator
from pathlib import Path

import pytest

TAG = f"ut{os.getpid()}"


@pytest.fixture(scope="session", autouse=True)
def _shm_tag() -> Iterator[None]:
    os.environ.setdefault("RV_METRICS_TAG", TAG)
    yield
    for p in Path("/dev/shm").glob(f"rv2m-{TAG}-*"):
        p.unlink(missing_ok=True)
