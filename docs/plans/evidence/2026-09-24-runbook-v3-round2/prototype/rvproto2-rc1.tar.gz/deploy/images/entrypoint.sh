#!/bin/sh
# rvproto-2 container entrypoint.
#   gateway            launcher: HTTP workers on RV_PORT (8400) + node exporter on RV_EXPORTER_PORT (9464)
#   guard              guard node: one owner per GPU on tcp://RV_GUARD_LISTEN_HOST:7070+i (default: the
#                      container's primary IP; register RV_GUARD_ADVERTISE=host:port behind NAT/pods)
#   unit               all-in-one: owners + workers (RV_GUARD_TOPOLOGY=owner)
#   control ARGS...    control-plane writer (python -m rvproto.control ARGS)
#   rehydrator         the C36 re-hydrator (python -m rvproto.control rehydrate)
#   prebuild           build/verify the TensorRT engine cache for the visible GPUs, print it, exit
#   shell              /bin/sh
set -eu
SITE=$(python -c "import site; print(site.getsitepackages()[0])")
if [ -d "$SITE/tensorrt_libs" ]; then  # the pip CUDA/cuDNN/TensorRT libraries of the guard image
  LD=$SITE/tensorrt_libs
  for d in "$SITE"/nvidia/*/lib "$SITE"/nvidia/cu13/lib; do [ -d "$d" ] && LD=$LD:$d; done
  export LD_LIBRARY_PATH=$LD:${LD_LIBRARY_PATH:-}
fi
if [ -z "${RV_GUARD_MODEL_SHA256:-}" ] && [ -f "$RV_HOME/models/pg2-22M.onnx.sha256" ]; then
  RV_GUARD_MODEL_SHA256=$(cut -d' ' -f1 "$RV_HOME/models/pg2-22M.onnx.sha256"); export RV_GUARD_MODEL_SHA256
fi
ulimit -n "$(ulimit -Hn)" 2>/dev/null || true
cmd=${1:-gateway}; [ $# -gt 0 ] && shift
case "$cmd" in
  gateway) exec python -m rvproto.serve "$@" ;;
  unit) export RV_GUARD_TOPOLOGY=owner; exec python -m rvproto.serve "$@" ;;
  guard)
    IP=${RV_GUARD_LISTEN_HOST:-$(python -c "import socket; s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.connect(('10.255.255.255', 1)); print(s.getsockname()[0])")}
    export RV_GUARD_OWNER_LISTEN=${RV_GUARD_OWNER_LISTEN:-tcp://$IP:7070}
    exec python -m rvproto.serve --guard-node "$@" ;;
  control) exec python -m rvproto.control "$@" ;;
  rehydrator) exec python -m rvproto.control rehydrate "$@" ;;
  prebuild) exec python tools/prebuild_trt.py ;;
  shell) exec /bin/sh "$@" ;;
  *) exec "$cmd" "$@" ;;
esac
