#!/usr/bin/env bash
# build.sh TAG [push]: build the rvproto-2 images on a build host (the r2impl dev VM: docker + an L4 +
# ~/rv/models + ~/rv/trtcache from the rv-proto-unit image), then optionally push to
#   asia-south1-docker.pkg.dev/ai-mesh-firewall/rv-r2/{gateway,guard}:TAG
# and write images/<TAG>.digests (repo@sha256 per image).
set -euo pipefail
TAG=${1:?tag}; PUSH=${2:-}
REG=asia-south1-docker.pkg.dev/ai-mesh-firewall/rv-r2
HERE=$(cd "$(dirname "$0")" && pwd)
CTX=$(mktemp -d /tmp/rv2ctx.XXXX)
trap 'rm -rf "$CTX"' EXIT
rsync -a --exclude .venv --exclude __pycache__ --exclude .hypothesis --exclude .pytest_cache --exclude .run \
  "$HOME/rv2/rvproto/" "$CTX/rvproto/"
cp -a "$HOME/rv2/vendor" "$CTX/vendor"
mkdir -p "$CTX/models" "$CTX/trtcache"
cp "$HOME/rv/models/tokenizer-22M.json" "$HOME/rv/models/pg2-22M.onnx" "$CTX/models/"
(cd "$CTX/models" && sha256sum pg2-22M.onnx > pg2-22M.onnx.sha256)
# the PG2-22M exact 1x512 fp16 engine for sm_89 (the smaller of the two cached engines; the other is 86M)
ENG=$(ls -S "$HOME"/rv/trtcache/*_fp16_sm89.engine | tail -1)
cp "$ENG" "${ENG%.engine}.profile" "$CTX/trtcache/"
cp "$HOME"/rv/trtcache/TensorrtExecutionProvider_cache_sm89.timing "$CTX/trtcache/"
printf '%s\n' '**/__pycache__' > "$CTX/.dockerignore"
sudo docker build -q -f "$HERE/Dockerfile.gateway" -t "$REG/gateway:$TAG" "$CTX"
sudo docker build -q -f "$HERE/Dockerfile.guard" -t "$REG/guard:$TAG" "$CTX"
sudo docker images --format '{{.Repository}}:{{.Tag}} {{.ID}} {{.Size}}' | grep "rv-r2/.*:$TAG"
if [[ "$PUSH" == push ]]; then
  gcloud auth print-access-token | sudo docker login -u oauth2accesstoken --password-stdin https://asia-south1-docker.pkg.dev >/dev/null
  out="$HERE/$TAG.digests"; : > "$out"
  for img in gateway guard; do
    sudo docker push -q "$REG/$img:$TAG" >/dev/null
    sudo docker inspect --format '{{index .RepoDigests 0}}' "$REG/$img:$TAG" | tee -a "$out"
  done
fi
