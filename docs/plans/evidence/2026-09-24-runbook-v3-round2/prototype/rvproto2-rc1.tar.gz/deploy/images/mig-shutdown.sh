#!/bin/bash
# rvproto-2 MIG shutdown script: SIGTERM the container and give it the drain bound (see mig-startup.sh).
docker stop -t 85 rv2 >/dev/null 2>&1 || true
