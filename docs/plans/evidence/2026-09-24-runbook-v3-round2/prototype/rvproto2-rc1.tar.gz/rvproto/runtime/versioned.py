"""C36: versioned, signed state records (shared by the gateways' readers and the control-plane writer).

Postgres (Cloud SQL) is the source of truth; the store (Memorystore) holds a published copy.
Every record carries (epoch, seq), the sha256 of its canonical body, an explicit `deleted` flag (an
explicit OFF record: a revoked key, a switched-off kill switch, an offboarded org) and an HMAC-SHA256
signature by the control plane (RV_STATE_HMAC_KEY). Versions are per kind and strictly increasing:
every write is (epoch, seq + 1); a rollback to older CONTENT is a signed write at (epoch + 1, 0), so
versions never go backwards. Each kind has a signed manifest {epoch, seq, count, digest} covering the
complete record set; writers and the re-hydrator put the records and the manifest in ONE transaction.

A reader treats the store as UNAVAILABLE (StoreDataUnavailable, handled exactly like a store outage)
when a manifest is missing, its signature or digest does not verify, or its version is older than a
version this process has already applied (a failed-over replica or a partial restore) -- never as
"no such tenant", "invalid key" or "switch off".
"""

from __future__ import annotations

import hashlib
import hmac
from dataclasses import dataclass
from typing import Any

import orjson

KINDS = ("plan", "key", "ks", "budget")


class StoreDataUnavailable(Exception):
    """The store's copy of durable state is missing, unverifiable or older than already seen."""


@dataclass(frozen=True, slots=True, order=True)
class Version:
    epoch: int
    seq: int

    def __str__(self) -> str:
        return f"{self.epoch}.{self.seq}"


ZERO = Version(0, 0)


def canonical(body: Any) -> bytes:
    return orjson.dumps(body, option=orjson.OPT_SORT_KEYS)


def body_hash(body: Any) -> str:
    return hashlib.sha256(canonical(body)).hexdigest()


def _mac(key: bytes, text: str) -> str:
    return hmac.new(key, text.encode(), hashlib.sha256).hexdigest()


def record_sig(key: bytes, kind: str, rkey: str, v: Version, h: str, deleted: bool, op: str) -> str:
    return _mac(key, f"rec\n{kind}\n{rkey}\n{v.epoch}\n{v.seq}\n{h}\n{int(deleted)}\n{op}")


def digest(records: list[dict[str, Any]]) -> str:
    lines = sorted(f"{r['key']}|{r['epoch']}|{r['seq']}|{r['hash']}|{int(bool(r['deleted']))}" for r in records)
    return hashlib.sha256("\n".join(lines).encode()).hexdigest()


def meta_sig(key: bytes, kind: str, v: Version, count: int, dig: str) -> str:
    return _mac(key, f"meta\n{kind}\n{v.epoch}\n{v.seq}\n{count}\n{dig}")


def make_record(key: bytes, kind: str, rkey: str, body: Any, v: Version, *, deleted: bool = False,
                op: str = "put") -> dict[str, Any]:
    h = body_hash(body)
    return {"kind": kind, "key": rkey, "epoch": v.epoch, "seq": v.seq, "hash": h, "deleted": deleted, "op": op,
            "sig": record_sig(key, kind, rkey, v, h, deleted, op), "body": body}


def make_meta(key: bytes, kind: str, v: Version, records: list[dict[str, Any]]) -> dict[str, Any]:
    dig = digest(records)
    return {"kind": kind, "epoch": v.epoch, "seq": v.seq, "count": len(records), "digest": dig,
            "sig": meta_sig(key, kind, v, len(records), dig)}


def version_of(d: dict[str, Any]) -> Version:
    return Version(int(d["epoch"]), int(d["seq"]))


def verify_record(key: bytes, kind: str, raw: bytes | dict[str, Any]) -> dict[str, Any]:
    rec = orjson.loads(raw) if isinstance(raw, (bytes, bytearray, str)) else raw
    try:
        v = version_of(rec)
        ok = (rec["kind"] == kind and rec["hash"] == body_hash(rec["body"]) and hmac.compare_digest(
            rec["sig"], record_sig(key, kind, rec["key"], v, rec["hash"], bool(rec["deleted"]), rec.get("op", "put"))))
    except (KeyError, TypeError, ValueError) as exc:
        raise StoreDataUnavailable(f"{kind} record malformed: {exc}") from exc
    if not ok:
        raise StoreDataUnavailable(f"{kind} record {rec.get('key')!r} fails its signature or hash")
    return rec


def verify_meta(key: bytes, kind: str, raw: bytes | None, *, not_before: Version) -> dict[str, Any]:
    if raw is None:
        raise StoreDataUnavailable(f"{kind} manifest missing (store empty, flushed or not yet re-hydrated)")
    try:
        meta = orjson.loads(raw)
        v = version_of(meta)
        ok = meta["kind"] == kind and hmac.compare_digest(
            meta["sig"], meta_sig(key, kind, v, int(meta["count"]), meta["digest"]))
    except (KeyError, TypeError, ValueError) as exc:
        raise StoreDataUnavailable(f"{kind} manifest malformed: {exc}") from exc
    if not ok:
        raise StoreDataUnavailable(f"{kind} manifest fails its signature")
    if v < not_before:
        raise StoreDataUnavailable(f"{kind} manifest {v} is older than {not_before} already applied (regressed store)")
    return meta


def verify_set(key: bytes, kind: str, meta: dict[str, Any], raws: list[bytes]) -> list[dict[str, Any]]:
    """The complete record set of a kind, checked against its manifest (count, digest, versions)."""
    recs = [verify_record(key, kind, r) for r in raws]
    mv = version_of(meta)
    if len(recs) != int(meta["count"]) or digest(recs) != meta["digest"]:
        raise StoreDataUnavailable(f"{kind} record set does not match its manifest {mv} (partial or mixed state)")
    if any(version_of(r) > mv for r in recs):
        raise StoreDataUnavailable(f"{kind} record newer than its manifest {mv}")
    return recs
