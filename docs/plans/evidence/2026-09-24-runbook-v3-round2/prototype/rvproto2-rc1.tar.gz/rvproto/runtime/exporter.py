"""C38 node exporter: reads every shared-memory metrics segment of this node OFF the serving loops.

Runs as threads of the launcher (gateway / all-in-one unit) or of the guard-node supervisor:
  dumps     <RV_METRICS_DIR>/{worker,owner}-<i>.json in the frozen-1 dump format (harness samplers keep
            working): every RV_METRICS_DUMP_S (0 = never periodic), within ~50 ms of a process's SIGUSR1
            (the process only stamps a request word in its segment), on the launcher's SIGUSR1, on GET /dump
  HTTP      RV_EXPORTER_HOST:RV_EXPORTER_PORT  /metrics (Prometheus text: merged histograms, counters,
            per-process gauges, autoscaling signals)  /metrics.json  /signals  /dump
  signals   every RV_EXPORT_S: window loop-lag p99/p99.9, CPU cores busy (from /proc), request rate,
            active streams / inflight, owner queue (windows, ms: time-averaged from the owners'
            backlog integrals), GPU utilisation (nvidia-smi); optionally pushed to Cloud Monitoring
"""

from __future__ import annotations

import json
import math
import mmap
import os
import subprocess
import threading
import time
from collections.abc import Callable
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import numpy as np

from rvproto.runtime.metrics import _NBUCKETS, merge, prometheus, quantile_of, summarize
from rvproto.runtime.shm_metrics import H_WORDS, HDR_WORDS, I_DIRLEN, I_DUMPREQ, I_GEN, MAGIC, SHM_DIR, DIR_BYTES

def _stem(role: str) -> str:
    return {"w": "worker", "o": "owner"}.get(role, role)


class Segment:
    """Read-only view of one process's segment."""

    def __init__(self, path: Path) -> None:
        self.path = path
        role_idx = path.name.rsplit("-", 1)[1]
        self.role, self.index = role_idx[0], int(role_idx[1:])
        fd = os.open(path, os.O_RDONLY)
        try:
            self.inode = os.fstat(fd).st_ino
            self.mm = mmap.mmap(fd, 0, prot=mmap.PROT_READ)
        finally:
            os.close(fd)
        self.head = np.frombuffer(self.mm, dtype="<i8", count=HDR_WORDS)
        if int(self.head[0]) != MAGIC:
            raise ValueError(f"{path}: not an rvproto-2 metrics segment")
        self.n_hist, self.n_count, self.n_gauge = (int(x) for x in self.head[4:7])
        self.h_off = HDR_WORDS * 8 + DIR_BYTES
        self.c_off = self.h_off + self.n_hist * H_WORDS * 8
        self.g_off = self.c_off + self.n_count * 8

    @property
    def pid(self) -> int:
        return int(self.head[2])

    def alive(self) -> bool:
        try:
            os.kill(self.pid, 0)
            return True
        except OSError:
            return False

    def directory(self) -> dict[str, dict[str, int]]:
        for _ in range(100):
            g0 = int(self.head[I_GEN])
            n = int(self.head[I_DIRLEN])
            raw = bytes(self.mm[HDR_WORDS * 8 : HDR_WORDS * 8 + n])
            if g0 % 2 == 0 and int(self.head[I_GEN]) == g0:
                return json.loads(raw) if raw else {"h": {}, "c": {}, "g": {}}
            time.sleep(0.0005)
        raise TimeoutError(f"{self.path}: directory kept changing")

    def export(self) -> dict[str, object]:
        d = self.directory()
        hist: dict[str, object] = {}
        for name, slot in d["h"].items():
            # a private copy: the owning process keeps writing its segment (numpy reductions over a live
            # buffer can fail when non-zero buckets appear mid-call)
            a = np.frombuffer(self.mm, dtype="<i8", count=H_WORDS, offset=self.h_off + slot * H_WORDS * 8).copy()
            b = a[4:]
            nz = np.nonzero(b)[0]
            hist[name] = {"n": int(a[0]), "sum": int(a[1]), "max": int(a[2]), "min": int(a[3]),
                          "b": {str(int(i)): int(b[i]) for i in nz}}
        c = np.frombuffer(self.mm, dtype="<i8", count=self.n_count, offset=self.c_off)
        g = np.frombuffer(self.mm, dtype="<f8", count=self.n_gauge, offset=self.g_off)
        gauges = {k: float(g[s]) for k, s in d["g"].items() if not math.isnan(float(g[s]))}
        started = int(self.head[9]) / 1e9
        return {"worker": self.index, "pid": self.pid, "exported_at": time.time(), "uptime_s": time.time() - started,
                "hist": hist, "count": {k: int(c[s]) for k, s in d["c"].items()}, "gauge": gauges}

    def dump_requested(self) -> int:
        return int(self.head[I_DUMPREQ])

    def gauge_value(self, name: str) -> float | None:
        """One gauge without a full export (the directory is re-read only when its generation moves)."""
        gen = int(self.head[I_GEN])
        if getattr(self, "_dir_gen", None) != gen:
            self._dir = self.directory()
            self._dir_gen = gen
        slot = self._dir["g"].get(name)
        if slot is None:
            return None
        v = float(np.frombuffer(self.mm, dtype="<f8", count=1, offset=self.g_off + slot * 8)[0])
        return None if math.isnan(v) else v


def _inode(p: Path) -> int:
    try:
        return p.stat().st_ino
    except OSError:
        return -1


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:  # another user's process
        return True
    return True


def _cpu_ticks(pid: int) -> int | None:
    try:
        f = Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()
        return int(f[11]) + int(f[12])
    except (OSError, IndexError, ValueError):
        return None


def _gpu_util() -> list[float]:
    try:
        out = subprocess.run(["nvidia-smi", "--query-gpu=utilization.gpu", "--format=csv,noheader,nounits"],
                             capture_output=True, text=True, timeout=5).stdout
        return [float(x) for x in out.split() if x.strip()]
    except (OSError, subprocess.SubprocessError, ValueError):
        return []


def _hist_delta(new: dict[str, object] | None, old: dict[str, object] | None) -> tuple[list[int], int, int]:
    """Bucket counts of (new - old) for one merged histogram export (dense list)."""
    counts = [0] * _NBUCKETS
    if new is None:
        return counts, 0, 0
    for k, v in new["b"].items():  # type: ignore[union-attr]
        counts[int(k)] += v
    if old is not None:
        for k, v in old["b"].items():  # type: ignore[union-attr]
            counts[int(k)] -= v
    n = int(new["n"]) - (int(old["n"]) if old is not None else 0)  # type: ignore[call-overload]
    return counts, n, int(new["max"])  # type: ignore[call-overload]


class NodeExporter:
    def __init__(self, *, tag: str, kind: str, metrics_dir: str, dump_s: float, host: str, port: int,
                 export_s: float, draining: Callable[[], bool], push: Callable[[dict[str, float]], None] | None,
                 expect_workers: int = 0) -> None:
        self.tag, self.kind = tag, kind  # kind: "gateway" | "guard" | "unit"
        self.expect_workers = expect_workers
        self._node_ready: bool | None = None
        self.metrics_dir, self.dump_s = metrics_dir, dump_s
        self.host, self.port, self.export_s = host, port, export_s
        self.draining, self.push = draining, push
        self.segs: dict[str, Segment] = {}
        self.signals: dict[str, float] = {}
        self._last: dict[str, object] = {}
        self._stop = threading.Event()
        self._lock = threading.Lock()
        self._dump_lock = threading.Lock()
        self._dumped: dict[str, int] = {}
        self.httpd: ThreadingHTTPServer | None = None
        self.loop_errors = 0
        self.push_errors = 0
        self._err_logged = 0.0

    # ---- segments ----
    def refresh(self) -> list[Segment]:
        with self._lock:
            live = {p.name: p for p in Path(SHM_DIR).glob(f"rv2m-{self.tag}-*")}
            for name in [n for n in self.segs if n not in live]:
                del self.segs[name]
            for name, p in live.items():
                seg = self.segs.get(name)
                if seg is None or not seg.alive() or _inode(p) != seg.inode:
                    try:
                        self.segs[name] = Segment(p)
                    except (OSError, ValueError):
                        continue
            return [s for s in self.segs.values() if s.alive()]

    def exports(self) -> list[tuple[Segment, dict[str, object]]]:
        out = []
        for seg in self.refresh():
            try:
                out.append((seg, seg.export()))
            except (OSError, ValueError, TimeoutError):
                continue
        return out

    def dump(self, only: set[str] | None = None) -> int:
        """Called by the dump loop, GET /dump and the launcher's SIGUSR1 (three threads): one at a time, and
        a temporary name of this process (another launcher may share the directory)."""
        if not self.metrics_dir:
            return 0
        Path(self.metrics_dir).mkdir(parents=True, exist_ok=True)
        n = 0
        with self._dump_lock:
            for seg, ex in self.exports():
                if only is not None and seg.path.name not in only:
                    continue
                path = Path(self.metrics_dir) / f"{_stem(seg.role)}-{seg.index}.json"
                tmp = path.with_name(f"{path.name}.{os.getpid()}.tmp")
                tmp.write_text(json.dumps(ex))
                tmp.replace(path)
                n += 1
        return n

    def prune_dumps(self) -> int:
        """Remove dump files whose process no longer runs (a restart with fewer workers, a crash):
        /metrics/all and the harness samplers read every worker-*/owner-* file in the directory."""
        if not self.metrics_dir:
            return 0
        n = 0
        d = Path(self.metrics_dir)
        for p in [*d.glob("worker-*.json"), *d.glob("owner-*.json")]:
            try:
                pid = int(json.loads(p.read_bytes()).get("pid", 0))
            except (OSError, ValueError, TypeError, AttributeError):
                continue
            if pid > 0 and not _pid_alive(pid):
                p.unlink(missing_ok=True)
                n += 1
        return n

    # ---- loops ----
    def _guarded(self, loop: str, fn: Callable[[], None]) -> None:
        """One loop iteration; an error is counted and logged (at most every 10 s), never fatal: node
        readiness and the signals depend on these threads staying alive."""
        try:
            fn()
        except Exception as exc:  # noqa: BLE001
            self.loop_errors += 1
            if time.monotonic() - self._err_logged >= 10:
                self._err_logged = time.monotonic()
                _log("exporter_loop_error", loop=loop, errors=self.loop_errors, error=repr(exc)[:300])

    def _dump_loop(self) -> None:
        state = {"last_periodic": 0.0, "last_prune": time.monotonic()}
        while not self._stop.wait(0.05):
            self._guarded("dump", lambda: self._dump_tick(state))

    def _dump_tick(self, state: dict[str, float]) -> None:
        want = set()
        for seg in self.refresh():
            req = seg.dump_requested()
            if req and self._dumped.get(seg.path.name) != req:
                self._dumped[seg.path.name] = req
                want.add(seg.path.name)
        if want:
            self.dump(want)
        if self.expect_workers:
            self._node_readiness()
        if self.dump_s > 0 and time.monotonic() - state["last_periodic"] >= self.dump_s:
            state["last_periodic"] = time.monotonic()
            self.dump()
        if time.monotonic() - state["last_prune"] >= 5.0:
            state["last_prune"] = time.monotonic()
            self.prune_dumps()

    def _node_readiness(self) -> None:
        """Node readiness = EVERY worker ready (SO_REUSEPORT spreads connections over all of them, so a
        load balancer must not see the node ready while one worker is not). Workers read the file in /readyz."""
        segs = [s for s in self.refresh() if s.role == "w"]
        vals = [s.gauge_value("worker_ready") for s in segs]
        n_ready = sum(1 for v in vals if v == 1.0)
        ready = len(segs) >= self.expect_workers and n_ready == len(segs)
        if ready != self._node_ready:
            self._node_ready = ready
            p = Path(SHM_DIR) / f"rv2-node-{self.tag}.json"
            tmp = p.with_suffix(".tmp")
            tmp.write_text(json.dumps({"ready": ready, "workers_ready": n_ready, "workers": len(segs),
                                       "expect": self.expect_workers, "t": time.time()}))
            tmp.replace(p)

    def _signal_loop(self) -> None:
        st: dict[str, object] = {"t": time.monotonic(), "ticks": {}, "merged": None, "owner": {}}
        while not self._stop.wait(self.export_s):
            self._guarded("signals", lambda: self._signal_tick(st))

    def _signal_tick(self, st: dict[str, object]) -> None:
        now = time.monotonic()
        ex = self.exports()
        ticks = {seg.pid: _cpu_ticks(seg.pid) for seg, _ in ex}
        workers = [e for seg, e in ex if seg.role == "w"]
        owners = [(seg, e) for seg, e in ex if seg.role == "o"]
        merged = merge(workers) if workers else None
        sig = self._window(now - st["t"], merged, st["merged"], ticks, st["ticks"], owners, st["owner"])  # type: ignore[operator,arg-type]
        sig["exporter_loop_errors"] = float(self.loop_errors)
        st.update(t=now, ticks=ticks, merged=merged, owner={seg.path.name: e for seg, e in owners})
        if self.push is not None:
            try:
                self.push(sig)
            except Exception as exc:  # noqa: BLE001 - monitoring is best effort; never stop the exporter
                self.push_errors += 1
                _log("monitoring_push_failed", errors=self.push_errors, error=repr(exc)[:300])
            sig["monitoring_push_errors"] = float(self.push_errors)
        with self._lock:
            self.signals = sig

    def _window(self, dt: float, merged: dict[str, object] | None, prev: dict[str, object] | None,
                ticks: dict[int, int | None], prev_ticks: dict[int, int | None],
                owners: list[tuple[Segment, dict[str, object]]], prev_owner: dict[str, object]) -> dict[str, float]:
        hz = os.sysconf("SC_CLK_TCK")
        sig: dict[str, float] = {"window_s": dt, "draining": 1.0 if self.draining() else 0.0,
                                 "node_cpus": float(os.cpu_count() or 1)}
        busy = sum((t - prev_ticks[p]) for p, t in ticks.items() if t is not None and prev_ticks.get(p) is not None)
        sig["cpu_cores_busy"] = busy / hz / dt if dt > 0 else 0.0
        sig["cpu_utilization"] = sig["cpu_cores_busy"] / sig["node_cpus"]
        if merged is not None:
            counts, n, vmax = _hist_delta(merged["hist"].get("loop_lag_ns"), (prev or {"hist": {}})["hist"].get("loop_lag_ns"))  # type: ignore[union-attr]
            sig["loop_lag_p99_ms"] = quantile_of(counts, n, 0.99, vmax) / 1e6
            sig["loop_lag_p999_ms"] = quantile_of(counts, n, 0.999, vmax) / 1e6
            adm = merged["count"].get("admitted", 0)  # type: ignore[union-attr]
            prev_adm = (prev or {"count": {}})["count"].get("admitted", 0)  # type: ignore[union-attr]
            sig["requests_per_s"] = (adm - prev_adm) / dt if dt > 0 and prev is not None else 0.0
            gauges = [pw.get("gauge", {}) for pw in merged.get("per_worker", [])]  # type: ignore[union-attr]
            for g in ("active_streams", "inflight_requests"):
                sig[g] = float(sum(x.get(g, 0.0) for x in gauges))
        if owners:
            self._owner_signals(sig, dt, owners, prev_owner)
        if self.kind in ("guard", "unit"):
            util = _gpu_util()
            if util:
                sig["gpu_utilization"] = sum(util) / len(util) / 100.0
                sig["gpus"] = float(len(util))
        return sig

    @staticmethod
    def _owner_signals(sig: dict[str, float], dt: float, owners: list[tuple[Segment, dict[str, object]]],
                       prev_owner: dict[str, object]) -> None:
        q_ns = q_win = reqs = sheds = 0.0
        q_now = []
        for seg, e in owners:
            c, g = e["count"], e["gauge"]  # type: ignore[index]
            p = prev_owner.get(seg.path.name)
            pc = p["count"] if p is not None else {}  # type: ignore[index]
            q_ns += (c.get("owner_backlog_ns_x_s", 0) - pc.get("owner_backlog_ns_x_s", 0))  # type: ignore[union-attr]
            q_win += (c.get("owner_windows_x_ms", 0) - pc.get("owner_windows_x_ms", 0)) / 1000.0  # type: ignore[union-attr]
            reqs += c.get("owner_requests", 0) - pc.get("owner_requests", 0)  # type: ignore[union-attr]
            sheds += c.get("owner_shed", 0) - pc.get("owner_shed", 0)  # type: ignore[union-attr]
            q_now.append(g.get("owner_backlog_ns", 0.0) / 1e6)  # type: ignore[union-attr]
        n = len(owners)
        if dt > 0 and prev_owner:
            sig["owner_queue_ms_avg"] = q_ns / dt / 1e6 / n
            sig["owner_queue_windows_avg"] = q_win / dt / n
            sig["owner_requests_per_s"] = reqs / dt
            sig["owner_shed_per_s"] = sheds / dt
        sig["owner_queue_ms_now_max"] = max(q_now) if q_now else 0.0
        sig["owners"] = float(n)

    # ---- HTTP ----
    def render(self) -> str:
        workers = [e for seg, e in self.exports() if seg.role == "w"]
        text = prometheus(merge(workers)) if workers else ""
        with self._lock:
            sig = dict(self.signals)
        lines = [f'rv2_signal{{kind="{self.kind}",name="{k}"}} {v}' for k, v in sorted(sig.items())]
        return text + "\n".join(lines) + "\n"

    def json_all(self) -> dict[str, object]:
        ex = self.exports()
        workers = [e for seg, e in ex if seg.role == "w"]
        merged = merge(workers) if workers else {"workers": 0, "hist": {}, "count": {}, "per_worker": []}
        merged["summary"] = summarize(merged["hist"])  # type: ignore[arg-type]
        merged["owners"] = [{"owner": e["worker"], "pid": e["pid"], "exported_at": e["exported_at"], "count": e["count"],
                             "gauge": e["gauge"], "summary": summarize(e["hist"])} for seg, e in ex if seg.role == "o"]  # type: ignore[arg-type]
        with self._lock:
            merged["signals"] = dict(self.signals)
        merged["generated_at"] = time.time()
        return merged

    def start(self, handler: Callable[[NodeExporter], type[BaseHTTPRequestHandler]] | None = None) -> None:
        """handler: the HTTP surface (edge/exporter_http.py; injected by the composition root)."""
        self._guarded("prune", self.prune_dumps)  # files a previous run of this node left behind
        threading.Thread(target=self._dump_loop, name="rv2-exporter-dump", daemon=True).start()
        threading.Thread(target=self._signal_loop, name="rv2-exporter-signals", daemon=True).start()
        if self.port > 0 and handler is not None:
            self.httpd = ThreadingHTTPServer((self.host, self.port), handler(self))
            threading.Thread(target=self.httpd.serve_forever, name="rv2-exporter-http", daemon=True).start()

    def stop(self) -> None:
        self._stop.set()
        if self.httpd is not None:
            self.httpd.shutdown()

    def cleanup(self) -> None:
        for p in Path(SHM_DIR).glob(f"rv2m-{self.tag}-*"):
            p.unlink(missing_ok=True)
        (Path(SHM_DIR) / f"rv2-node-{self.tag}.json").unlink(missing_ok=True)


def _log(event: str, **kw: object) -> None:
    import sys

    sys.stderr.write(json.dumps({"event": event, "t": time.time(), **kw}, default=str) + "\n")
