"""C38 loop hygiene for serving processes: GC pauses measured always, GC tuned when C38 is on,
and the CPU-burst fault injector used by the loop-isolation test (one worker, every period).

A cyclic-GC pass runs synchronously on whichever thread allocates; a generation-2 pass over a large
heap stalls the event loop for tens of ms. gc.freeze() after startup moves every object that lives
for the whole process into the permanent generation (never scanned again), and higher thresholds
make young-generation passes rarer and the (now small) older passes cheaper.
"""

from __future__ import annotations

import asyncio
import gc
import time

from rvproto.runtime.config import Settings
from rvproto.runtime.metrics import Registry


def install_gc_probe(metrics: Registry) -> None:
    """gc_pause_ns{gen="0|1|2"} for every collection (cheap: two clock reads per collection)."""
    hists = {g: metrics.h(f'gc_pause_ns{{gen="{g}"}}') for g in (0, 1, 2)}
    started = [0]

    def cb(phase: str, info: dict[str, int]) -> None:
        if phase == "start":
            started[0] = time.perf_counter_ns()
        elif started[0]:
            hists[info.get("generation", 2)].record(time.perf_counter_ns() - started[0])
            started[0] = 0

    gc.callbacks.append(cb)


def tune_gc(s: Settings) -> dict[str, object]:
    """Call once startup is complete (C38 on). Returns what was applied, for the startup log."""
    c = s.v2.c38
    if not c.on:
        return {"gc": "unchanged (C38 off)"}
    gc.collect()
    gc.set_threshold(*c.gc_threshold)
    if c.gc_freeze:
        gc.freeze()
    return {"gc_threshold": gc.get_threshold(), "gc_frozen": gc.get_freeze_count()}


async def cpu_burst(s: Settings, metrics: Registry) -> None:
    """RV_INJECT_CPU_BURST=<worker>:<ms>:<period_s>: busy-loop THIS worker's event loop (test fault)."""
    cfg = s.v2.c38.cpu_burst
    if cfg is None or cfg[0] != s.worker_index:
        return
    _, ms, period = cfg
    burst_ns = int(ms * 1e6)
    while True:
        await asyncio.sleep(period)
        t = time.perf_counter_ns()
        while time.perf_counter_ns() - t < burst_ns:
            pass
        metrics.inc("injected_cpu_bursts")
