"""rvproto-2 settings: the four fixes (each behind its own flag, default ON) and the knobs they add.

Every flag set to `off` restores the rvproto-frozen-1 behaviour of that area, so each fix has a
negative control on the same build:
  RV_FIX_C38  loop isolation: metrics in shared memory + off-loop exporter, tokenizer encode_batch in a
              thread pool (TOKENIZERS_PARALLELISM=false), GC frozen after startup with raised thresholds
  RV_FIX_C10  owner-level admission: per-worker guard cap advisory; owner queue bound, input queue, guard
              deadline and store timeout are separate knobs (no AMF_TARGET_P99_MS coupling); the owner
              sheds any request whose predicted wait + execution exceeds its remaining budget
  RV_FIX_C43  load-aware guard routing: owners push their backlog to subscribed workers on every change;
              workers route each guard call to the owner with the least estimated backlog
  RV_FIX_C36  durable state: versioned, signed records with explicit OFF records; missing or regressed
              store data is UNAVAILABLE (503), never "unknown tenant" / 401 for a valid key
"""

from __future__ import annotations

from dataclasses import dataclass

V2_DEFAULTS: tuple[tuple[str, str], ...] = (
    ("RV_FIX_C38", "on"),
    ("RV_FIX_C10", "on"),
    ("RV_FIX_C43", "on"),
    ("RV_FIX_C36", "on"),
    # C38 loop isolation
    ("RV_GC_FREEZE", "on"),  # gc.freeze() once startup is complete (C38 on only)
    ("RV_GC_THRESHOLD", "50000,50,100"),  # gc.set_threshold (C38 on only)
    ("RV_INJECT_CPU_BURST", ""),  # test fault: "<worker>:<ms>:<period_s>" busy-loop on that worker's event loop
    ("RV_EXPORTER_PORT", "9464"),  # launcher / guard-node exporter: /metrics (Prometheus), /metrics.json; 0 = off
    ("RV_EXPORTER_HOST", "0.0.0.0"),
    ("RV_SHM_SLOTS", "96,512,512"),  # shared-memory metric slots per process: histograms, counters, gauges
    # C10 owner-level admission
    ("RV_SLO_MS", "20"),  # the processing SLO the guard deadline is derived from
    ("RV_GUARD_DEADLINE_MARGIN_MS", "2"),  # headroom kept for output-phase processing
    ("RV_GUARD_DEADLINE_MIN_MS", "4"),
    ("RV_GUARD_DEADLINE_WINDOW_S", "10"),  # rolling window of the non-guard input-stage p99
    ("RV_OWNER_QUEUE_MS", "12"),  # owner queue bound: milliseconds of work at the owner's measured rate
    ("RV_INPUT_QUEUE_CAP", ""),  # per-worker input-phase bound; empty => none (C10 on) / contract (C10 off)
    ("RV_STORE_TIMEOUT_MS", "25"),  # store op timeout on the request path (C10 on; off: the contract's AMF target)
    # C43 routing + guard discovery + drain
    ("RV_GUARD_DISCOVERY", ""),  # store | static; empty => store when RV_GUARD_TOPOLOGY=remote and no RV_GUARD_OWNER_ADDRS
    ("RV_GUARD_DISCOVERY_MS", "1000"),
    ("RV_GUARD_REGISTER_TTL_MS", "3000"),
    ("RV_GUARD_ADVERTISE", ""),  # host:port owners register (empty => the TCP listen address)
    ("RV_GUARD_ROUTE_EPS_US", "250"),  # owners within this estimated backlog of the minimum tie (random pick)
    ("RV_GUARD_DRAIN_S", "30"),  # owner drain bound after SIGTERM
    ("RV_DRAIN_ACCEPT_S", "15"),  # gateway: keep accepting (readyz 503, connection: close) this long after SIGTERM
    ("RV_DRAIN_S", "60"),  # gateway: then stop accepting and finish in-flight streams within this bound
    ("RV_ATTRIBUTION", "header"),  # off | header (x-rv-attr) | stages (also appended to x-rv-stages)
    ("RV_INJECT_OWNER_DELAY_MS", "0"),  # test fault: extra delay before each owner execution
    # C36 durable state
    ("RV_STATE_HMAC_KEY", ""),  # record signing key (control plane and gateways); required when C36 is on
    ("RV_DATABASE_URL", ""),  # Postgres DSN (control-plane writer and re-hydrator only)
    ("RV_REHYDRATE_PERIOD_MS", "1000"),
    ("RV_BUDGET_CHECKPOINT_S", "5"),
    # autoscaling signals
    ("RV_EXPORT_S", "10"),  # exporter window for loop-lag / queue / CPU signals
    ("RV_CLOUD_MONITORING", "off"),  # on: push the signals as Cloud Monitoring custom metrics
    ("RV_MONITORING_RESOURCE", "gce_instance"),  # gce_instance | k8s_pod
    ("RV_MONITORING_PREFIX", "custom.googleapis.com/rv2"),
)


def _flag(raw: str, name: str) -> bool:
    v = raw.strip().lower()
    if v not in ("on", "off"):
        raise ValueError(f"{name}={raw!r} (on | off)")
    return v == "on"


def _ints(raw: str, n: int, name: str) -> tuple[int, ...]:
    parts = tuple(int(x) for x in raw.split(",") if x.strip())
    if len(parts) != n or min(parts) < 0:
        raise ValueError(f"{name}={raw!r} needs {n} non-negative integers")
    return parts


def _burst(raw: str) -> tuple[int, float, float] | None:
    if not raw.strip():
        return None
    w, ms, period = raw.split(":")
    out = int(w), float(ms), float(period)
    if out[1] <= 0 or out[2] <= 0:
        raise ValueError(f"RV_INJECT_CPU_BURST={raw!r} (<worker>:<ms>:<period_s>, both positive)")
    return out


@dataclass(frozen=True, slots=True)
class LoopIsolation:
    on: bool
    gc_freeze: bool
    gc_threshold: tuple[int, int, int]
    cpu_burst: tuple[int, float, float] | None
    exporter_port: int
    exporter_host: str
    shm_slots: tuple[int, int, int]


@dataclass(frozen=True, slots=True)
class Admission:
    on: bool
    slo_ms: float
    deadline_margin_ms: float
    deadline_min_ms: float
    deadline_window_s: float
    owner_queue_ms: float
    input_queue_cap: int | None
    store_timeout_ms: float


@dataclass(frozen=True, slots=True)
class Routing:
    on: bool
    discovery: str  # "store" | "static"
    discovery_ms: float
    register_ttl_ms: float
    advertise: str
    route_eps_ns: int
    guard_drain_s: float
    drain_accept_s: float
    drain_s: float
    attribution: str
    inject_owner_delay_ms: float


@dataclass(frozen=True, slots=True)
class Durable:
    on: bool
    hmac_key: str
    database_url: str
    rehydrate_period_ms: float
    budget_checkpoint_s: float


@dataclass(frozen=True, slots=True)
class Signals:
    export_s: float
    cloud_monitoring: bool
    resource: str
    prefix: str


@dataclass(frozen=True, slots=True)
class V2:
    c38: LoopIsolation
    c10: Admission
    c43: Routing
    c36: Durable
    signals: Signals


def load_v2(get: dict[str, str], *, topology: str, static_addrs: bool) -> V2:
    t = _ints(get["RV_GC_THRESHOLD"], 3, "RV_GC_THRESHOLD")
    c38 = LoopIsolation(
        on=_flag(get["RV_FIX_C38"], "RV_FIX_C38"),
        gc_freeze=_flag(get["RV_GC_FREEZE"], "RV_GC_FREEZE"),
        gc_threshold=(t[0], t[1], t[2]),
        cpu_burst=_burst(get["RV_INJECT_CPU_BURST"]),
        exporter_port=int(get["RV_EXPORTER_PORT"]),
        exporter_host=get["RV_EXPORTER_HOST"],
        shm_slots=_shm_slots(get["RV_SHM_SLOTS"]),
    )
    iq = get["RV_INPUT_QUEUE_CAP"].strip()
    c10 = Admission(
        on=_flag(get["RV_FIX_C10"], "RV_FIX_C10"),
        slo_ms=float(get["RV_SLO_MS"]),
        deadline_margin_ms=float(get["RV_GUARD_DEADLINE_MARGIN_MS"]),
        deadline_min_ms=float(get["RV_GUARD_DEADLINE_MIN_MS"]),
        deadline_window_s=float(get["RV_GUARD_DEADLINE_WINDOW_S"]),
        owner_queue_ms=float(get["RV_OWNER_QUEUE_MS"]),
        input_queue_cap=int(iq) if iq else None,
        store_timeout_ms=float(get["RV_STORE_TIMEOUT_MS"]),
    )
    disc = get["RV_GUARD_DISCOVERY"].strip() or ("store" if topology == "remote" and not static_addrs else "static")
    if disc not in ("store", "static"):
        raise ValueError(f"RV_GUARD_DISCOVERY={disc!r} (store | static)")
    attr = get["RV_ATTRIBUTION"].strip().lower()
    if attr not in ("off", "header", "stages"):
        raise ValueError(f"RV_ATTRIBUTION={attr!r} (off | header | stages)")
    c43 = Routing(
        on=_flag(get["RV_FIX_C43"], "RV_FIX_C43"),
        discovery=disc,
        discovery_ms=float(get["RV_GUARD_DISCOVERY_MS"]),
        register_ttl_ms=float(get["RV_GUARD_REGISTER_TTL_MS"]),
        advertise=get["RV_GUARD_ADVERTISE"].strip(),
        route_eps_ns=int(float(get["RV_GUARD_ROUTE_EPS_US"]) * 1000),
        guard_drain_s=float(get["RV_GUARD_DRAIN_S"]),
        drain_accept_s=float(get["RV_DRAIN_ACCEPT_S"]),
        drain_s=float(get["RV_DRAIN_S"]),
        attribution=attr,
        inject_owner_delay_ms=float(get["RV_INJECT_OWNER_DELAY_MS"]),
    )
    c36 = Durable(
        on=_flag(get["RV_FIX_C36"], "RV_FIX_C36"),
        hmac_key=get["RV_STATE_HMAC_KEY"],
        database_url=get["RV_DATABASE_URL"],
        rehydrate_period_ms=float(get["RV_REHYDRATE_PERIOD_MS"]),
        budget_checkpoint_s=float(get["RV_BUDGET_CHECKPOINT_S"]),
    )
    res = get["RV_MONITORING_RESOURCE"].strip()
    if res not in ("gce_instance", "k8s_pod"):
        raise ValueError(f"RV_MONITORING_RESOURCE={res!r} (gce_instance | k8s_pod)")
    signals = Signals(
        export_s=float(get["RV_EXPORT_S"]),
        cloud_monitoring=_flag(get["RV_CLOUD_MONITORING"], "RV_CLOUD_MONITORING"),
        resource=res,
        prefix=get["RV_MONITORING_PREFIX"].rstrip("/"),
    )
    _check(c10)
    return V2(c38, c10, c43, c36, signals)


def _shm_slots(raw: str) -> tuple[int, int, int]:
    h, c, g = _ints(raw, 3, "RV_SHM_SLOTS")
    return h, c, g


def _check(c10: Admission) -> None:
    if c10.deadline_min_ms <= 0 or c10.deadline_min_ms > c10.slo_ms:
        raise ValueError("RV_GUARD_DEADLINE_MIN_MS must be in (0, RV_SLO_MS]")
    if c10.owner_queue_ms <= 0:
        raise ValueError("RV_OWNER_QUEUE_MS must be positive")
    if c10.input_queue_cap is not None and c10.input_queue_cap < 1:
        raise ValueError("RV_INPUT_QUEUE_CAP must be >= 1")


def describe_v2(v: V2) -> dict[str, object]:
    out: dict[str, object] = {}
    for group in ("c38", "c10", "c43", "c36", "signals"):
        g = getattr(v, group)
        d = {f: getattr(g, f) for f in g.__slots__}  # type: ignore[attr-defined]
        if group == "c36":
            d["hmac_key"] = "<set>" if v.c36.hmac_key else ""
            d["database_url"] = "<set>" if v.c36.database_url else ""
        out[group] = d
    return out
