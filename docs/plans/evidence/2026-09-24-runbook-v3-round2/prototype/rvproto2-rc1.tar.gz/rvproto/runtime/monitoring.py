"""Autoscaling signals as Cloud Monitoring custom metrics (RV_CLOUD_MONITORING=on), pushed by the node
exporter thread (never a serving loop) once per RV_EXPORT_S window.

Metric types: <RV_MONITORING_PREFIX>/<kind>/<signal>, e.g. custom.googleapis.com/rv2/gateway/loop_lag_p99_ms,
custom.googleapis.com/rv2/guard/owner_queue_ms_avg, custom.googleapis.com/rv2/guard/gpu_utilization.
Monitored resource: gce_instance (MIG autoscaler: per-instance utilisation target) from the metadata
server, or k8s_pod (GKE HPA through the custom-metrics adapter) from RV_K8S_{PROJECT,LOCATION,CLUSTER,
NAMESPACE,POD}. Auth: the instance's / pod's service account token from the metadata server.
Standard library only (urllib); a failed push is counted by the exporter and never stops it.
"""

from __future__ import annotations

import json
import os
import time
import urllib.request
from datetime import datetime, timezone

from rvproto.runtime.config import Settings

MD = "http://metadata.google.internal/computeMetadata/v1/"
PUSHED = ("loop_lag_p99_ms", "loop_lag_p999_ms", "cpu_utilization", "cpu_cores_busy", "requests_per_s",
          "active_streams", "inflight_requests", "owner_queue_ms_avg", "owner_queue_windows_avg",
          "owner_queue_ms_now_max", "owner_requests_per_s", "owner_shed_per_s", "gpu_utilization", "draining")


def _md(path: str) -> str:
    req = urllib.request.Request(MD + path, headers={"Metadata-Flavor": "Google"})
    with urllib.request.urlopen(req, timeout=2) as resp:
        return resp.read().decode()


class CloudMonitoring:
    def __init__(self, s: Settings, kind: str) -> None:
        self.kind = "guard" if kind == "guard" else "gateway" if kind == "gateway" else "unit"
        self.prefix = s.v2.signals.prefix
        self.resource_type = s.v2.signals.resource
        self.project = os.environ.get("RV_K8S_PROJECT") or _md("project/project-id")
        self._token: tuple[str, float] | None = None
        self.resource = self._resource()

    def _resource(self) -> dict[str, object]:
        if self.resource_type == "k8s_pod":
            e = os.environ
            return {"type": "k8s_pod", "labels": {
                "project_id": self.project, "location": e.get("RV_K8S_LOCATION", ""),
                "cluster_name": e.get("RV_K8S_CLUSTER", ""), "namespace_name": e.get("RV_K8S_NAMESPACE", "default"),
                "pod_name": e.get("RV_K8S_POD", os.uname().nodename)}}
        zone = _md("instance/zone").rsplit("/", 1)[-1]
        return {"type": "gce_instance", "labels": {"project_id": self.project, "instance_id": _md("instance/id"),
                                                    "zone": zone}}

    def token(self) -> str:
        if self._token is None or self._token[1] < time.time() + 60:
            d = json.loads(_md("instance/service-accounts/default/token"))
            self._token = (d["access_token"], time.time() + float(d["expires_in"]))
        return self._token[0]

    def payload(self, sig: dict[str, float], now: float | None = None) -> dict[str, object]:
        ts = datetime.fromtimestamp(now or time.time(), tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        series = [{"metric": {"type": f"{self.prefix}/{self.kind}/{name}"}, "resource": self.resource,
                   "metricKind": "GAUGE", "valueType": "DOUBLE",
                   "points": [{"interval": {"endTime": ts}, "value": {"doubleValue": float(sig[name])}}]}
                  for name in PUSHED if name in sig]
        return {"timeSeries": series}

    def push(self, sig: dict[str, float]) -> None:
        body = json.dumps(self.payload(sig)).encode()
        if body == b'{"timeSeries": []}':
            return
        req = urllib.request.Request(
            f"https://monitoring.googleapis.com/v3/projects/{self.project}/timeSeries", data=body, method="POST",
            headers={"Authorization": f"Bearer {self.token()}", "Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            resp.read()
