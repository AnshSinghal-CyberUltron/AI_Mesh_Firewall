"""Shared-state client (Redis). Pool size and op timeout derive from the contract."""

from __future__ import annotations

import redis.asyncio as aioredis
from redis.exceptions import RedisError

from rvproto.runtime.contract import Bounds, ResourceContract
from rvproto.runtime.versioned import StoreDataUnavailable

# C36: a missing / unverifiable / regressed copy of durable state is handled exactly like an outage
StoreError = (RedisError, OSError, TimeoutError, StoreDataUnavailable)

# Redis key layout (prototype-owned; unfrozen per runbook §10.2.1).
K_KEYS = "rv:keys"  # hash: sha256(api key) -> principal json
K_AUTH_EPOCH = "rv:auth_epoch"
K_KILLSWITCH = "rv:killswitch"  # "1" => serve nothing
K_KILLSWITCH_ORGS = "rv:killswitch:org"  # hash: org -> "1" => that org is disabled
K_KILLSWITCH_MODELS = "rv:killswitch:model"  # hash: model -> "1" => that model is disabled
K_PLAN_VERSIONS = "rv:plan_versions"  # hash: org -> version
K_PLAN_PREFIX = "rv:plan:"  # string json per org
K_PLAN_CHANNEL = "rv:plan:updates"
K_BUDGET_PREFIX = "rv:budget:"  # int tokens remaining per org
K_AUDIT_PREFIX = "rv:audit:"  # stream per org

# rvproto-2 layout. Every key carries the hash tag {rv2} so multi-key reads/writes (MULTI, pipelines,
# Lua) stay in ONE slot on a cluster-mode store (Memorystore for Valkey / Redis Cluster) too.
K2 = "{rv2}:"
K2_META = K2 + "meta:"  # + kind: signed manifest {kind, epoch, seq, count, digest, sig} (C36)
K2_PLAN = K2 + "plan:"  # + org: signed plan record (C36)
K2_PLAN_INDEX = K2 + "plan_index"  # hash org -> "epoch.seq" (C36)
K2_KEYS = K2 + "keys"  # hash sha256(api key) -> signed principal record (explicit OFF = revoked) (C36)
K2_KS = K2 + "ks"  # hash scope ("global" | "org:<id>" | "model:<id>") -> signed {"on": bool} record (C36)
K2_BUDGET = K2 + "budget:"  # + org: remaining tokens (C36; missing => UNAVAILABLE, never exhausted)
K2_BUDGET_META = K2 + "budget_meta"  # hash org -> signed {"limit": n} record (C36)
K2_BUDGET_GEN = K2 + "budget_gen:"  # + org: "epoch.seq" of the budget record the counter was set from (C36)
K2_UPDATES = K2 + "updates"  # pub/sub: kind names after a write or a re-hydration (C36)
K2_GUARD_OWNERS = K2 + "guard:owners"  # set of owner ids (discovery)
K2_GUARD_OWNER = K2 + "guard:owner:"  # + id: owner registration with a TTL (discovery)

# C36: a missing counter is NOT an exhausted budget: -1 => UNAVAILABLE (503) until re-hydrated
LEASE_LUA_V2 = """
if redis.call('EXISTS', KEYS[1]) == 0 then return -1 end
local remaining = tonumber(redis.call('GET', KEYS[1]))
if remaining <= 0 then return 0 end
local grant = tonumber(ARGV[1])
if remaining < grant then grant = remaining end
redis.call('DECRBY', KEYS[1], grant)
return grant
"""

LEASE_LUA = """
local remaining = tonumber(redis.call('GET', KEYS[1]) or '0')
if remaining <= 0 then return 0 end
local grant = tonumber(ARGV[1])
if remaining < grant then grant = remaining end
redis.call('DECRBY', KEYS[1], grant)
return grant
"""


def connect(url: str, contract: ResourceContract, bounds: Bounds, *, timeout_s: float | None = None) -> aioredis.Redis:
    """timeout_s: the request-path op timeout (C10: its own knob); None = the contract target (frozen-1)."""
    if timeout_s is None:
        timeout_s = contract.target_p99_ms / 1000.0
    pool = aioredis.BlockingConnectionPool.from_url(
        url,
        max_connections=bounds.redis_connections,
        timeout=timeout_s,
        socket_timeout=timeout_s,
        socket_connect_timeout=timeout_s,
        decode_responses=False,
    )
    return aioredis.Redis(connection_pool=pool)


def connect_background(url: str, contract: ResourceContract, bounds: Bounds) -> aioredis.Redis:
    """Background refreshers/writers: bounded by the same pool, longer op timeout
    (a multiple of the refresh period is not a capacity value)."""
    pool = aioredis.BlockingConnectionPool.from_url(
        url, max_connections=bounds.redis_connections, decode_responses=False
    )
    return aioredis.Redis(connection_pool=pool)
