"""C38: per-process metrics in shared memory, read by an exporter in ANOTHER process.

A serving process only ever does O(1) in-place updates (a bucket increment, a counter add, a gauge
store) on a file mapped from /dev/shm; it never serialises, merges or exposes metrics on its event
loop. The exporter (runtime/exporter.py, in the launcher / guard-node supervisor) maps every segment
of its node read-only and renders dumps, Prometheus text and the autoscaling signals off-loop.

Segment layout (little-endian int64 words unless noted), one file per process:
  header   [0] magic  [1] layout version  [2] pid  [3] worker/owner index  [4] n_hist  [5] n_count
           [6] n_gauge  [7] directory generation (odd while being rewritten)  [8] directory bytes
           [9] started_at (ns)  [10] dump request (ns; set by SIGUSR1, cleared by the exporter)
  dir      JSON {"h": {name: slot}, "c": {...}, "g": {...}} (the only variable-size part)
  hist     n_hist x (4 + NBUCKETS): n, sum, max, min(-1 = none), bucket counts (metrics.bucket_of)
  count    n_count words
  gauge    n_gauge float64 (NaN = unset)
Files are raw /dev/shm entries (not multiprocessing.shared_memory: in Python 3.12 an attaching
process registers the segment with its resource tracker and unlinks it at exit).
"""

from __future__ import annotations

import json
import math
import mmap
import os
import time
from collections.abc import Iterator, MutableMapping
from pathlib import Path

from rvproto.runtime.metrics import _NBUCKETS, Histogram, Registry, bucket_of

SHM_DIR = "/dev/shm"
MAGIC = 0x52563253484D  # "RV2SHM"
VERSION = 1
HDR_WORDS = 16
DIR_BYTES = 1 << 16
H_WORDS = 4 + _NBUCKETS
I_GEN, I_DIRLEN, I_DUMPREQ = 7, 8, 10


def segment_name(tag: str, role: str, index: int) -> str:
    return f"rv2m-{tag}-{role}{index}"


def segment_size(n_hist: int, n_count: int, n_gauge: int) -> int:
    return HDR_WORDS * 8 + DIR_BYTES + (n_hist * H_WORDS + n_count + n_gauge) * 8


class ShmHistogram:
    """Histogram-compatible view over one slot of the segment (record() is the hot path)."""

    __slots__ = ("counts", "hdr")

    def __init__(self, hdr: memoryview, counts: memoryview) -> None:
        self.hdr = hdr
        self.counts = counts

    def record(self, v: int) -> None:
        self.counts[bucket_of(v)] += 1
        h = self.hdr
        h[0] += 1
        h[1] += v
        if v > h[2]:
            h[2] = v
        if h[3] < 0 or v < h[3]:
            h[3] = v

    @property
    def n(self) -> int:
        return int(self.hdr[0])

    @property
    def total(self) -> int:
        return int(self.hdr[1])

    @property
    def vmax(self) -> int:
        return int(self.hdr[2])

    @property
    def vmin(self) -> int:
        return int(self.hdr[3])

    def quantile(self, q: float) -> float:
        return Histogram.quantile(self, q)  # type: ignore[arg-type]

    def export(self) -> dict[str, object]:
        return Histogram.export(self)  # type: ignore[arg-type]


class _Gauges(MutableMapping[str, float]):
    """name -> float gauge stored in the segment; deleting frees the slot (value NaN)."""

    def __init__(self, reg: ShmRegistry) -> None:
        self.reg = reg

    def __getitem__(self, name: str) -> float:
        v = self.reg.gmv[self.reg.gslot[name]]
        if math.isnan(v):
            raise KeyError(name)
        return v

    def __setitem__(self, name: str, v: float) -> None:
        self.reg.set(name, v)

    def __delitem__(self, name: str) -> None:
        slot = self.reg.gslot.pop(name)
        self.reg.gmv[slot] = math.nan
        self.reg.gfree.append(slot)
        self.reg.publish_dir()

    def __iter__(self) -> Iterator[str]:
        return iter([k for k, s in self.reg.gslot.items() if not math.isnan(self.reg.gmv[s])])

    def __len__(self) -> int:
        return sum(1 for _ in self)


class ShmRegistry(Registry):
    """Registry API over a /dev/shm segment. Slot overflow degrades to process-local (unexported)
    metrics and is counted, never an exception on the request path."""

    def __init__(self, worker: int, *, tag: str, role: str, slots: tuple[int, int, int]) -> None:
        super().__init__(worker)
        self.n_hist, self.n_count, self.n_gauge = slots
        self.path = Path(SHM_DIR) / segment_name(tag, role, worker)
        size = segment_size(*slots)
        self.path.unlink(missing_ok=True)  # a NEW inode: an exporter still mapping a dead process's file is safe
        fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_RDWR, 0o600)
        try:
            os.ftruncate(fd, size)
            self.mm = mmap.mmap(fd, size)
        finally:
            os.close(fd)
        words = memoryview(self.mm).cast("q")
        self.head = words[:HDR_WORDS]
        self.dir_off = HDR_WORDS * 8
        h0 = (self.dir_off + DIR_BYTES) // 8
        self.hmv = words[h0 : h0 + self.n_hist * H_WORDS]
        c0 = h0 + self.n_hist * H_WORDS
        self.cmv = words[c0 : c0 + self.n_count]
        g0 = (c0 + self.n_count) * 8
        self.gmv = memoryview(self.mm)[g0 : g0 + self.n_gauge * 8].cast("d")
        for i in range(self.n_gauge):
            self.gmv[i] = math.nan
        self.hslot: dict[str, int] = {}
        self.cslot: dict[str, int] = {}
        self.gslot: dict[str, int] = {}
        self.gfree: list[int] = []
        self._local = Registry(worker)  # overflow: kept in-process, not exported
        for i, v in enumerate((MAGIC, VERSION, os.getpid(), worker, self.n_hist, self.n_count, self.n_gauge, 0, 0,
                               time.time_ns())):
            self.head[i] = v
        self.gauge = _Gauges(self)  # type: ignore[assignment]
        self.publish_dir()

    def publish_dir(self) -> None:
        raw = json.dumps({"h": self.hslot, "c": self.cslot, "g": self.gslot}, separators=(",", ":")).encode()
        if len(raw) > DIR_BYTES:
            raise RuntimeError("metrics directory exceeds its region")
        self.head[I_GEN] += 1  # odd: being rewritten
        self.mm[self.dir_off : self.dir_off + len(raw)] = raw
        self.head[I_DIRLEN] = len(raw)
        self.head[I_GEN] += 1

    def h(self, name: str) -> Histogram:
        hist = self.hist.get(name)
        if hist is not None:
            return hist
        slot = len(self.hslot)
        if slot >= self.n_hist:
            self._local.inc("metrics_slot_overflow")
            hist = self.hist[name] = Histogram()
            return hist
        base = slot * H_WORDS
        self.hmv[base + 3] = -1
        hist = self.hist[name] = ShmHistogram(self.hmv[base : base + 4], self.hmv[base + 4 : base + H_WORDS])  # type: ignore[assignment]
        self.hslot[name] = slot
        self.publish_dir()
        return hist

    def inc(self, name: str, by: int = 1) -> None:
        slot = self.cslot.get(name)
        if slot is None:
            if len(self.cslot) >= self.n_count:
                self._local.inc(name, by)
                return
            slot = self.cslot[name] = len(self.cslot)
            self.publish_dir()
        self.cmv[slot] += by

    def set(self, name: str, v: float) -> None:
        slot = self.gslot.get(name)
        if slot is None:
            if self.gfree:
                slot = self.gfree.pop()
            elif len(self.gslot) < self.n_gauge:
                slot = len(self.gslot)
            else:
                self._local.set(name, v)
                return
            self.gslot[name] = slot
            self.publish_dir()
        self.gmv[slot] = float(v)

    @property  # type: ignore[override]
    def count(self) -> dict[str, int]:
        out = {k: int(self.cmv[s]) for k, s in self.cslot.items()}
        out.update(self._local.count)
        return out

    @count.setter
    def count(self, _v: dict[str, int]) -> None:  # Registry.__init__ assigns it; the segment is the store
        pass

    def request_dump(self) -> None:
        """SIGUSR1: ask the exporter for a fresh dump of this process (O(1), safe in a handler)."""
        self.head[I_DUMPREQ] = time.time_ns()

    def close(self) -> None:
        self.path.unlink(missing_ok=True)


def make_registry(index: int, *, on: bool, tag: str, role: str, slots: tuple[int, int, int]) -> Registry:
    """C38 on: a shared-memory registry the exporter can read; off: the frozen-1 in-process registry."""
    if not on:
        return Registry(index)
    return ShmRegistry(index, tag=tag, role=role, slots=slots)


def metrics_tag(default: str) -> str:
    """Segments of one node share a tag (set by the launcher / guard-node supervisor for its children)."""
    return os.environ.get("RV_METRICS_TAG") or default
