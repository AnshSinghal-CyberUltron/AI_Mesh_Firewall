"""Pure ASGI application: lifespan + routing. t0 is taken at ASGI entry, before auth."""

from __future__ import annotations

import asyncio
import contextlib
import signal
import time

from rvproto.edge import errors, ops
from rvproto.edge.chat import ChatHandler
from rvproto.edge.http import Receive, Scope, Send, header_map, request_id
from rvproto.detect.guard import discovery
from rvproto.edge.state import State, _log, build_state, start_guard
from rvproto.runtime.loopguard import cpu_burst, install_gc_probe, tune_gc
from rvproto.runtime.shm_metrics import ShmRegistry


def _closing(send: Send) -> Send:
    """While draining, every response asks the client (the LB) to close its keep-alive connection."""

    async def wrapped(msg: dict[str, object]) -> None:
        if msg["type"] == "http.response.start":
            msg = dict(msg, headers=[*msg.get("headers", []), (b"connection", b"close")])  # type: ignore[misc]
        await send(msg)

    return wrapped


class RvApp:
    def __init__(self) -> None:
        self.st: State | None = None
        self.chat: ChatHandler | None = None

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        t0 = time.perf_counter_ns()
        kind = scope["type"]
        if kind == "http":
            st, chat = self.st, self.chat
            assert st is not None and chat is not None
            if st.draining_since is not None:
                send = _closing(send)
            if scope["path"] == "/v1/chat/completions":
                if scope["method"] == "POST":
                    return await chat.handle(scope, receive, send, t0)
                spec = errors.method_not_allowed(scope["method"])
            elif await ops.handle(st, scope, receive, send):
                return None
            else:
                spec = errors.not_found(scope["path"])
            return await errors.send_error(send, spec, request_id(header_map(scope)))
        if kind == "lifespan":
            return await self._lifespan(receive, send)
        return None

    async def _lifespan(self, receive: Receive, send: Send) -> None:
        while True:
            msg = await receive()
            if msg["type"] == "lifespan.startup":
                try:
                    await self._startup()
                except Exception as exc:
                    _log("startup_failed", error=repr(exc))
                    await send({"type": "lifespan.startup.failed", "message": repr(exc)})
                    return
                await send({"type": "lifespan.startup.complete"})
            elif msg["type"] == "lifespan.shutdown":
                await self._shutdown()
                await send({"type": "lifespan.shutdown.complete"})
                return

    async def _startup(self) -> None:
        st = await build_state()
        self.st = st
        self.chat = ChatHandler(st)
        st.tasks = [
            asyncio.create_task(st.ks.run()),
            asyncio.create_task(st.plans.run()),
            asyncio.create_task(st.audit.run()),
            asyncio.create_task(start_guard(st)),
        ]
        if st.s.guard_topology == "remote" and st.s.v2.c43.discovery == "store":
            st.tasks.append(asyncio.create_task(discovery.watch(
                st.redis_bg, period_s=st.s.v2.c43.discovery_ms / 1000.0, model_hash=st.guard.model_hash,
                apply=st.guard.set_endpoints)))  # type: ignore[union-attr]
        st.tasks.append(asyncio.create_task(self._loop_lag(st)))
        install_gc_probe(st.metrics)
        if isinstance(st.metrics, ShmRegistry):  # C38: the node exporter dumps/exposes; SIGUSR1 only asks for it
            asyncio.get_running_loop().add_signal_handler(signal.SIGUSR1, st.metrics.request_dump)
        elif st.s.metrics_dir:
            st.tasks.append(asyncio.create_task(self._dump_metrics(st)))
        if st.s.v2.c38.cpu_burst is not None:
            st.tasks.append(asyncio.create_task(cpu_burst(st.s, st.metrics)))
        asyncio.get_running_loop().add_signal_handler(signal.SIGUSR2, self._drain)
        _log("loop_hygiene", worker=st.s.worker_index, **tune_gc(st.s))

    def _drain(self) -> None:
        st = self.st
        if st is not None and st.draining_since is None:
            st.draining_since = time.time()
            st.metrics.set("draining", 1)
            _log("worker_draining", worker=st.s.worker_index)

    async def _loop_lag(self, st: State) -> None:
        """Event-loop lag: how late a short sleep wakes up (GIL holders, sync work, stalls). Also keeps the
        worker_ready gauge current for the node exporter's node-level readiness (C38)."""
        period = st.s.ks_refresh_ms / 5000.0
        k = 0
        while True:
            t = time.perf_counter_ns()
            await asyncio.sleep(period)
            st.metrics.observe("loop_lag_ns", max(time.perf_counter_ns() - t - int(period * 1e9), 0))
            k += 1
            if k % 5 == 0:
                st.metrics.set("worker_ready", 1.0 if ops.worker_ready_now(st) else 0.0)
            if k % 10 == 0 and isinstance(st.metrics, ShmRegistry):
                ops._gauges(st)  # C38: no scrape reaches the worker; keep its live gauges current (O(orgs))

    async def _dump_metrics(self, st: State) -> None:
        def dump() -> None:
            ops._gauges(st)
            st.metrics.dump(st.s.metrics_dir)

        # li experiment: SIGUSR1 = on-demand dump; RV_METRICS_DUMP_S=0 disables the periodic dump
        asyncio.get_running_loop().add_signal_handler(signal.SIGUSR1, dump)
        if st.s.metrics_dump_s <= 0:
            await asyncio.Event().wait()
        while True:
            await asyncio.sleep(st.s.metrics_dump_s)
            dump()

    async def _shutdown(self) -> None:
        st = self.st
        if st is None:
            return
        await st.audit.drain(st.s.ks_stale_ms / 1000.0)
        for t in st.tasks:
            t.cancel()
        for t in st.tasks:
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await t
        if st.s.metrics_dir and not isinstance(st.metrics, ShmRegistry):
            ops._gauges(st)
            st.metrics.dump(st.s.metrics_dir)
        await st.provider.close()
        await st.guard.close()
        await st.redis.aclose()
        await st.redis_bg.aclose()
        if isinstance(st.metrics, ShmRegistry):
            st.metrics.close()
