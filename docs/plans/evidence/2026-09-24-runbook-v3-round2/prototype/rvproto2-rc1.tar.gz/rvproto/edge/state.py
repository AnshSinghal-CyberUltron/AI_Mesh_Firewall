"""Per-worker component graph, built in the ASGI lifespan (never module-level state)."""

from __future__ import annotations

import asyncio
import dataclasses
import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import redis.asyncio as aioredis

from rvproto.admit.admission import Admission
from rvproto.admit.deadline import DeadlineController, FixedDeadline
from rvproto.admit.identity import Identity
from rvproto.admit.killswitch import KillSwitch
from rvproto.admit.overload import LoadGate
from rvproto.admit.state_v2 import VersionedIdentity, VersionedKillSwitch
from rvproto.admit.quota import Gcra, TokenLease
from rvproto.audit.sink import AuditSink
from rvproto.detect.deterministic import DeterministicDetectors
from rvproto.detect.guard.factory import build
from rvproto.detect.matcher import Matcher
from rvproto.detect.semantic import SemanticDetector
from rvproto.dispatch.provider import ProviderClient
from rvproto.edge.inspect import NoScanInspector, PlanInspector, Verifier
from rvproto.plan.snapshot import PlanSnapshot
from rvproto.plan.snapshot_v2 import VersionedPlanSnapshot
from rvproto.runtime import contract as rc
from rvproto.runtime.config import Settings, describe, load_settings
from rvproto.runtime.metrics import Registry
from rvproto.runtime.shm_metrics import make_registry, metrics_tag
from rvproto.runtime.store import StoreError, connect, connect_background

if TYPE_CHECKING:
    from rvproto.detect.guard.factory import GuardImpl


@dataclass
class State:
    s: Settings
    contract: rc.ResourceContract
    logs: tuple[str, ...]
    bounds: rc.Bounds
    metrics: Registry
    redis: aioredis.Redis
    redis_bg: aioredis.Redis
    identity: Identity | VersionedIdentity
    ks: KillSwitch | VersionedKillSwitch
    admission: Admission
    plans: PlanSnapshot | VersionedPlanSnapshot
    matcher: Matcher
    det: DeterministicDetectors
    verifier: Verifier
    guard: GuardImpl
    sem: SemanticDetector
    audit: AuditSink
    provider: ProviderClient
    guard_deadline_ms: float
    gate: LoadGate
    deadline: DeadlineController | FixedDeadline
    guard_error: str | None = None
    active_streams: int = 0
    tasks: list[asyncio.Task[None]] = field(default_factory=list)
    inspectors: dict[tuple[str, str], PlanInspector] = field(default_factory=dict)
    tok_pool: ThreadPoolExecutor | None = None  # li experiment (RV_TOKENIZE_IN_THREAD=1) / C38
    draining_since: float | None = None  # SIGUSR2 from the launcher: readyz 503, connection: close

    def inspector(self, plan: object) -> PlanInspector:
        key = (plan.org_id, plan.version)  # type: ignore[attr-defined]
        ins = self.inspectors.get(key)
        if ins is None:
            cls = PlanInspector if self.s.exp_output_scan else NoScanInspector  # experiment flag
            ins = self.inspectors[key] = cls(self.matcher, self.det, plan)  # type: ignore[arg-type]
        return ins

    def stream_ceiling(self) -> int:
        return rc.stream_ceiling(self.contract, self.active_streams)


def _state_readers(s: Settings, metrics: Registry, redis: aioredis.Redis, redis_bg: aioredis.Redis) -> tuple[
        Identity | VersionedIdentity, KillSwitch | VersionedKillSwitch, PlanSnapshot | VersionedPlanSnapshot]:
    """C36 on: versioned, signed state (missing / regressed => 503); off: the frozen-1 readers."""
    if s.v2.c36.on:
        if not s.v2.c36.hmac_key:
            raise ValueError("RV_FIX_C36=on needs RV_STATE_HMAC_KEY (the control plane's record signing key)")
        k = s.v2.c36.hmac_key.encode()
        vid = VersionedIdentity(redis, k)
        vks = VersionedKillSwitch(redis_bg, metrics, k, refresh_ms=s.ks_refresh_ms, stale_ms=s.ks_stale_ms, identity=vid)
        return vid, vks, VersionedPlanSnapshot(redis_bg, metrics, k, reconcile_ms=s.plan_reconcile_ms,
                                               stale_ms=s.ks_stale_ms)
    identity = Identity(redis)
    ks = KillSwitch(redis_bg, metrics, refresh_ms=s.ks_refresh_ms, stale_ms=s.ks_stale_ms, on_epoch=identity.on_epoch)
    return identity, ks, PlanSnapshot(redis_bg, metrics, reconcile_ms=s.plan_reconcile_ms, stale_ms=s.ks_stale_ms)


def _store_timeout_s(s: Settings, contract: rc.ResourceContract) -> float:
    """C10: the request-path store timeout is its own knob; frozen-1 used the AMF target."""
    return s.v2.c10.store_timeout_ms / 1000.0 if s.v2.c10.on else contract.target_p99_ms / 1000.0


def _log(event: str, **kw: object) -> None:
    sys.stderr.write(json.dumps({"event": event, "t": time.time(), **kw}, default=str) + "\n")
    sys.stderr.flush()


async def build_state() -> State:
    s = load_settings()
    contract, logs = rc.load()
    bounds = rc.derive(contract, s)
    metrics = make_registry(s.worker_index, on=s.v2.c38.on, tag=metrics_tag(str(s.port)), role="w",
                            slots=s.v2.c38.shm_slots)
    redis = connect(s.redis_url, contract, bounds, timeout_s=_store_timeout_s(s, contract))
    redis_bg = connect_background(s.redis_url, contract, bounds)
    identity, ks, plans = _state_readers(s, metrics, redis, redis_bg)
    try:
        await ks.refresh_once()
    except StoreError as exc:
        _log("killswitch_initial_refresh_failed", error=repr(exc))
    lease = TokenLease(redis, metrics, chunk_tokens=bounds.lease_chunk_tokens, durable=s.v2.c36.on)
    await plans.load_all()
    matcher = Matcher()
    det = DeterministicDetectors(matcher)
    guard = build(s, metrics)
    sem = SemanticDetector(s.guard_tokenizer, guard, window=s.window_tokens,
                           overlap=s.window_overlap, max_windows=s.max_windows,
                           model_hash=guard.model_hash)
    audit = AuditSink(redis_bg, metrics, stream_maxlen=s.audit_stream_maxlen)
    audit_rate = await audit.calibrate()
    bounds = rc.derive(contract, s, audit_rate=audit_rate)
    assert bounds.audit_queue is not None
    audit.configure(bounds.audit_queue)
    provider = ProviderClient(s, bounds, metrics)
    await provider.start()
    deadline = s.guard_deadline_ms if s.guard_deadline_ms is not None else contract.target_p99_ms
    c10 = s.v2.c10
    ctl: DeadlineController | FixedDeadline = (
        DeadlineController(metrics, slo_ms=c10.slo_ms, margin_ms=c10.deadline_margin_ms, min_ms=c10.deadline_min_ms,
                           window_s=c10.deadline_window_s, fixed_ms=s.guard_deadline_ms)
        if c10.on else FixedDeadline(deadline))
    gate = LoadGate(metrics, inflight_cap=contract.connection_budget())
    st = State(s, contract, logs, bounds, metrics, redis, redis_bg, identity, ks,
               Admission(identity, ks, Gcra(), lease), plans, matcher, det,
               Verifier(matcher, s.decode_budget), guard, sem, audit, provider, deadline, gate, ctl)
    if s.tokenize_in_thread:
        st.tok_pool = ThreadPoolExecutor(max_workers=s.tokenize_threads, thread_name_prefix="rv-tok")
    _log("startup", worker=s.worker_index, settings=describe(s), matcher=matcher.engine,
         contract=rc.describe(contract, logs, bounds), audit_drain_rate=audit_rate,
         guard_deadline_ms=deadline)
    return st


async def start_guard(st: State) -> None:
    """Warm the guard (TRT engine build can take minutes), then derive guard bounds."""
    try:
        await st.guard.start()
    except Exception as exc:  # stays not-ready; requests get UNAVAILABLE
        st.guard_error = repr(exc)
        _log("guard_start_failed", worker=st.s.worker_index, error=repr(exc))
        return
    hint = st.guard.capacity_hint()
    guard_q = None
    if hint is not None:
        st.contract = rc.with_guard(st.contract, hint.tokens_per_second)
        guard_q = rc.derive(st.contract, st.s).guard_queue_tokens
        st.bounds = dataclasses.replace(st.bounds, guard_queue_tokens=guard_q)
        windows_per_s = hint.tokens_per_second / st.s.window_tokens
        c10 = st.s.v2.c10
        # C10: the input queue has its own knob (none by default); frozen-1 derived it from the AMF target
        input_cap = c10.input_queue_cap if c10.on else st.contract.queue_depth(windows_per_s)
        shared_owner = st.s.guard_topology in ("owner", "remote")
        if c10.on and not shared_owner:  # in_process: this worker's own engine IS the owner; bound it in ms of work
            guard_q = int(hint.tokens_per_second * c10.owner_queue_ms / 1000.0)
            st.bounds = dataclasses.replace(st.bounds, guard_queue_tokens=guard_q)
        st.gate.configure_guard(input_cap=input_cap, guard_cap_tokens=guard_q or 0,
                                tokens_per_s=hint.tokens_per_second, advisory=c10.on and shared_owner)
        st.metrics.set("guard_tokens_per_s", hint.tokens_per_second)
    _log("guard_ready", worker=st.s.worker_index, backend=st.guard.name, detail=st.guard.detail,
         guard_queue_tokens=guard_q, input_queue_cap=st.gate.input_cap)
