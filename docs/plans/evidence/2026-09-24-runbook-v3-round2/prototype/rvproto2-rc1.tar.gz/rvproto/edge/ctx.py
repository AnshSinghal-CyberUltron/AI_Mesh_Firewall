"""Request-scoped frozen context values shared by chat.py and respond.py."""

from __future__ import annotations

from dataclasses import dataclass

from rvproto.admit.admission import Grant
from rvproto.domain.decision import Decision, DispatchAuthorization
from rvproto.domain.plan import ExecutionPlan
from rvproto.domain.request import ChatRequest


@dataclass(frozen=True, slots=True)
class Ctx:
    rid: str
    t0: int
    chat: ChatRequest
    grant: Grant
    plan: ExecutionPlan
    passthrough: tuple[tuple[str, str], ...]
    ticket: int  # admission ticket (admit/overload.py)


@dataclass(frozen=True, slots=True)
class InputResult:
    decision: Decision
    auth: DispatchAuthorization | None
    body: bytes
    verification: str
    stages: str
    audited: bool
    guard_wait_ns: int = 0
    attr: str = ""  # C43/C38 attribution (x-rv-attr): tokenise, guard queue/exec/rtt, owner, deadline


def attr_of(tok_ns: int, res: object | None, deadline_ms: float, worker: int = -1) -> str:
    """Compact per-request attribution; values in ms (3 decimals), owner as host:port, wk = gateway worker."""
    parts = [f"wk={worker}", f"tok={tok_ns / 1e6:.3f}", f"dl={deadline_ms:.1f}"]
    if res is not None:
        parts += [f"gq={res.queue_ns / 1e6:.3f}", f"ge={res.exec_ns / 1e6:.3f}",  # type: ignore[attr-defined]
                  f"grtt={res.rtt_ns / 1e6:.3f}", f"go={res.owner or '-'}"]  # type: ignore[attr-defined]
    return ";".join(parts)


def headers_for(ctx: Ctx, disposition: str, stages: str, attr: str = "", mode: str = "off") -> list[tuple[bytes, bytes]]:
    """mode (RV_ATTRIBUTION): off | header (x-rv-attr) | stages (also appended to x-rv-stages as `attr:<...>`
    so the READY loadgen, which records x-rv-stages, keeps it per request)."""
    if attr and mode == "stages":
        stages = f"{stages},attr:{attr}"
    out = [(b"x-rv-disposition", disposition.encode()),
           (b"x-rv-plan-version", ctx.plan.version.encode()),
           (b"x-rv-stages", stages.encode())]
    if attr and mode != "off":
        out.append((b"x-rv-attr", attr.encode()))
    return out


def blocked_stages(stages: str, audited: bool) -> str:
    return f"{stages},dispatch:S,out:S,audit:{'E' if audited else 'U'}"
