"""C38 exporter HTTP surface (served by the launcher / guard-node supervisor process, never by a worker):
/metrics (Prometheus text), /metrics.json, /signals, /dump. The data comes from runtime/exporter.py."""

from __future__ import annotations

import json
from http.server import BaseHTTPRequestHandler

from rvproto.runtime.exporter import NodeExporter


def handler(exp: NodeExporter) -> type[BaseHTTPRequestHandler]:
    class H(BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # noqa: N802
            try:
                self._get()
            except Exception as exc:  # noqa: BLE001 - answer 500, never drop the connection without a response
                body = json.dumps({"error": repr(exc)[:300]}).encode()
                self.send_response(500)
                self.send_header("content-type", "application/json")
                self.send_header("content-length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

        def _get(self) -> None:
            if self.path == "/metrics":
                body, ctype = exp.render().encode(), "text/plain; version=0.0.4"
            elif self.path == "/metrics.json":
                body, ctype = json.dumps(exp.json_all()).encode(), "application/json"
            elif self.path == "/signals":
                with exp._lock:
                    body, ctype = json.dumps(exp.signals).encode(), "application/json"
            elif self.path == "/dump":
                body, ctype = json.dumps({"dumped": exp.dump()}).encode(), "application/json"
            else:
                body, ctype = b'{"error":"unknown path"}', "application/json"
                self.send_response(404)
                self.send_header("content-type", ctype)
                self.send_header("content-length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            self.send_response(200)
            self.send_header("content-type", ctype)
            self.send_header("content-length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, fmt: str, *args: object) -> None:
            return

    return H
