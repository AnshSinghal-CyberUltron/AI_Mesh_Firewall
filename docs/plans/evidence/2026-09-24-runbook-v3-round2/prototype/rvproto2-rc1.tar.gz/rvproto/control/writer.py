"""C36 control-plane writer: Postgres (Cloud SQL) FIRST, then publish to the store (Memorystore).

A write commits to Postgres (the source of truth) and only then publishes the kind's complete, signed
record set + manifest to the store in one MULTI/EXEC, followed by a pub/sub nudge. If the publish fails
the write is still durable; the re-hydrator (rehydrate.py) republishes within its period.
Publishes never move the store backwards: the set is read as one Postgres snapshot, and the MULTI/EXEC
runs under WATCH of the manifest, skipped when the store already holds a newer verified manifest (a slow
publisher of an older snapshot -- a writer racing the re-hydrator -- loses to the newer one).
Replaces tools/seed.py, tools/plan_update.py, tools/killswitch.py and tools/quota.py for rvproto-2.
"""

from __future__ import annotations

import hashlib
import json
import sys
import time
from typing import Any

import orjson
import redis

from rvproto.control.db import DB
from rvproto.plan.compiler import compile_plan
from rvproto.runtime.store import (
    K2_BUDGET,
    K2_BUDGET_GEN,
    K2_BUDGET_META,
    K2_KEYS,
    K2_KS,
    K2_META,
    K2_PLAN,
    K2_PLAN_INDEX,
    K2_UPDATES,
)
from rvproto.runtime.versioned import (
    ZERO,
    StoreDataUnavailable,
    Version,
    make_meta,
    make_record,
    verify_meta,
    version_of,
)

HASHES = (("key", K2_KEYS), ("ks", K2_KS), ("budget", K2_BUDGET_META))


def _log(event: str, **kw: object) -> None:
    sys.stderr.write(json.dumps({"event": event, "t": time.time(), **kw}, default=str) + "\n")


def key_hash(api_key: str) -> str:
    return hashlib.sha256(api_key.encode()).hexdigest()


class StateWriter:
    def __init__(self, db: DB, r: redis.Redis, hmac_key: bytes, *, actor: str = "rvproto.control") -> None:
        self.db = db
        self.r = r
        self.k = hmac_key
        self.actor = actor

    # ---- the one write path ----
    def put(self, kind: str, rkey: str, body: Any, *, deleted: bool = False, op: str = "put",
            epoch_bump: bool = False) -> Version:
        with self.db.tx() as t:
            v = t.version(kind, lock=True)
            nv = Version(v.epoch + 1, 0) if epoch_bump else Version(v.epoch, v.seq + 1)
            t.upsert(make_record(self.k, kind, rkey, body, nv, deleted=deleted, op=op), self.actor)
            t.set_version(kind, nv)
        _log("state_write", kind=kind, key=rkey if kind != "key" else rkey[:12] + "...", version=str(nv), op=op,
             deleted=deleted)
        self.publish_safe(kind)
        return nv

    def repair_epoch(self, kind: str) -> Version:
        """The store holds a version Postgres never issued (divergence): move Postgres to a new epoch so the
        republished state is newer than anything a gateway has applied (never a regression)."""
        with self.db.tx() as t:
            v = t.version(kind, lock=True)
            nv = Version(v.epoch + 1, 0)
            t.set_version(kind, nv)
        _log("state_epoch_repair", kind=kind, version=str(nv))
        return nv

    def publish_safe(self, kind: str) -> bool:
        try:
            self.publish(kind)
            return True
        except (redis.RedisError, OSError) as exc:
            _log("state_publish_failed", kind=kind, error=repr(exc)[:300], note="durable in Postgres; re-hydrator republishes")
            return False

    def publish(self, kind: str) -> int | None:
        """The kind's COMPLETE record set + manifest in one MULTI/EXEC; returns the record count, or None when
        the store already holds a newer verified manifest (nothing written)."""
        v, recs = self.db.snapshot(kind)
        meta = make_meta(self.k, kind, v, recs)
        with self.r.pipeline(transaction=True) as pipe:
            for _ in range(20):
                try:
                    pipe.watch(K2_META + kind)
                    cur = self._stored_version(kind, pipe.get(K2_META + kind))
                    if cur is not None and cur > v:
                        _log("state_publish_skipped", kind=kind, version=str(v), store_version=str(cur))
                        return None
                    pipe.multi()
                    self._stage(pipe, kind, recs, meta)
                    pipe.execute()
                    return len(recs)
                except redis.WatchError:  # another publisher committed in between: re-check
                    continue
        raise redis.RedisError(f"{kind}: publish kept racing other publishers")

    def _stored_version(self, kind: str, raw: bytes | None) -> Version | None:
        if raw is None:
            return None
        try:
            return version_of(verify_meta(self.k, kind, raw, not_before=ZERO))
        except StoreDataUnavailable:
            return None  # a missing or forged manifest never blocks a publish

    @staticmethod
    def _stage(pipe: Any, kind: str, recs: list[dict[str, Any]], meta: dict[str, Any]) -> None:
        if kind == "plan":
            for rec in recs:
                pipe.set(K2_PLAN + rec["key"], orjson.dumps(rec))
            pipe.delete(K2_PLAN_INDEX)
            if recs:
                pipe.hset(K2_PLAN_INDEX, mapping={rec["key"]: orjson.dumps(
                    {k: rec[k] for k in ("key", "epoch", "seq", "hash", "deleted")}) for rec in recs})
        else:
            name = dict(HASHES)[kind]
            pipe.delete(name)
            if recs:
                pipe.hset(name, mapping={rec["key"]: orjson.dumps(rec) for rec in recs})
        pipe.set(K2_META + kind, orjson.dumps(meta))
        pipe.publish(K2_UPDATES, kind)

    # ---- domain operations ----
    def plan_set(self, doc: dict[str, Any]) -> Version:
        compile_plan(doc)  # the control plane rejects invalid plans at save time
        return self.put("plan", str(doc["org_id"]), doc)

    def plan_delete(self, org: str) -> Version:
        return self.put("plan", org, {"org_id": org}, deleted=True, op="offboard")

    def key_add(self, api_key: str, org: str, *, key_id: str, rate: float, burst: float) -> Version:
        return self.put("key", key_hash(api_key), {"key_id": key_id, "org_id": org, "rate_per_s": rate, "burst": burst})

    def key_revoke(self, api_key: str | None = None, *, hashed: str | None = None) -> Version:
        h = hashed or key_hash(api_key or "")
        cur = {r["key"]: r for r in self.db.records("key")}.get(h)
        body = cur["body"] if cur is not None else {"key_id": "unknown", "org_id": "unknown", "rate_per_s": 0, "burst": 0}
        return self.put("key", h, body, deleted=True, op="revoke")

    def killswitch(self, scope: str, name: str | None, on: bool) -> Version:
        rkey = "global" if scope == "global" else f"{scope}:{name}"
        return self.put("ks", rkey, {"on": on})  # "off" is an explicit record, never an absence

    def budget_set(self, org: str, tokens: int) -> Version:
        """The live counter restarts from the new limit, tagged (atomically) with the budget record version it
        counts down: checkpoints of an older budget are never restored over it (rehydrate.py)."""
        v = self.put("budget", org, {"limit": tokens})
        try:
            self.r.mset({K2_BUDGET + org: tokens, K2_BUDGET_GEN + org: str(v)})
        except (redis.RedisError, OSError) as exc:
            _log("budget_counter_set_failed", org=org, error=repr(exc)[:200], note="the re-hydrator resets it")
        return v

    def rollback(self, log_id: int) -> Version:
        """Restore the content of one logged write as a NEW, signed version at a new epoch."""
        with self.db.tx() as t:
            entry = t.log_entry(log_id)
        if entry is None:
            raise KeyError(f"no log entry {log_id}")
        return self.put(entry["kind"], entry["key"], entry["body"], deleted=entry["deleted"], op="rollback",
                        epoch_bump=True)
