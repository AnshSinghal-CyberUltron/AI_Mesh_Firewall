"""C36 re-hydrator: restore the store's copy of durable state from Postgres.

Every RV_REHYDRATE_PERIOD_MS, per kind: compare the store's manifest with Postgres (version, count,
digest). Missing, unverifiable, older or different => republish the complete kind from Postgres (one
MULTI/EXEC). An older store is re-checked after RV_REHYDRATE_STALE_GRACE_MS first (a writer publishes
right after its commit; that in-flight publish is not a fault). A store manifest NEWER than Postgres (a
version Postgres never issued) is repaired by moving Postgres to a new epoch first, so gateways never see
a regression.
Budget counters: every counter carries the version of the budget record it counts down
({rv2}:budget_gen:<org>, set atomically with it). Counters are checkpointed to Postgres with that version
every RV_BUDGET_CHECKPOINT_S. A vanished counter is restored from the checkpoint OF THE CURRENT budget
version, else from the limit (a checkpoint taken before a budget reset is never restored over it), so the
overshoot after a flush is bounded by one checkpoint period. A counter of an older budget version (a
budget_set whose counter write was lost) is reset to the limit. Repairs are compare-and-set on the
version tag, so they never overwrite a concurrent budget_set.

Every restore is logged as {"event": "rehydrated", kind, reason, detected_at, restored_at, took_ms,
records}; the re-hydration bound = detection period + took_ms (the gap as clients see it starts at the
fault and ends at restored_at plus one gateway refresh period).
"""

from __future__ import annotations

import json
import sys
import time
from typing import Any

import redis

from rvproto.control.db import DB
from rvproto.control.writer import StateWriter
from rvproto.runtime.store import K2_BUDGET, K2_BUDGET_GEN, K2_META
from rvproto.runtime.versioned import KINDS, ZERO, StoreDataUnavailable, Version, digest, verify_meta, version_of

# KEYS counter, gen; ARGV expected gen ("" = none), value, new gen, mode (missing | reset | gen)
BUDGET_CAS = """
local g = redis.call('GET', KEYS[2]) or ''
if g ~= ARGV[1] then return 0 end
if ARGV[4] == 'gen' then redis.call('SET', KEYS[2], ARGV[3]) return 1 end
if ARGV[4] == 'missing' and redis.call('EXISTS', KEYS[1]) == 1 then return 0 end
redis.call('SET', KEYS[1], ARGV[2])
redis.call('SET', KEYS[2], ARGV[3])
return 1
"""


def _log(event: str, **kw: object) -> None:
    sys.stderr.write(json.dumps({"event": event, "t": time.time(), **kw}, default=str) + "\n")
    sys.stderr.flush()


class Rehydrator:
    def __init__(self, db: DB, r: redis.Redis, writer: StateWriter, *, period_ms: float, checkpoint_s: float,
                 stale_grace_ms: float = 250.0) -> None:
        self.db = db
        self.r = r
        self.w = writer
        self.period_s = period_ms / 1000.0
        self.checkpoint_s = checkpoint_s
        self.stale_grace_s = stale_grace_ms / 1000.0
        self.events: list[dict[str, Any]] = []
        self._cas = r.register_script(BUDGET_CAS)

    def diagnose(self, kind: str) -> str | None:
        """None when the store's copy of `kind` equals Postgres; else the reason to restore."""
        pg_v, recs = self.db.snapshot(kind)
        raw = self.r.get(K2_META + kind)
        if raw is None:
            return "missing"
        try:
            meta = verify_meta(self.w.k, kind, raw, not_before=ZERO)
        except StoreDataUnavailable:
            return "invalid"
        sv = version_of(meta)
        if sv > pg_v:
            return "store_ahead"
        if sv < pg_v:
            return "stale"
        if int(meta["count"]) != len(recs) or meta["digest"] != digest(recs):
            return "digest"
        return None

    def check_once(self) -> list[dict[str, Any]]:
        out = []
        for kind in KINDS:
            t0 = time.time()
            try:
                reason = self.diagnose(kind)
                if reason == "stale" and self.stale_grace_s > 0:
                    time.sleep(self.stale_grace_s)
                    reason = self.diagnose(kind)
                if reason is None:
                    continue
                if reason == "store_ahead":
                    self.w.repair_epoch(kind)
                n = self.w.publish(kind)
            except (redis.RedisError, OSError, StoreDataUnavailable) as exc:
                _log("rehydrate_error", kind=kind, error=repr(exc)[:300])
                continue
            if n is None:  # a newer publish landed first: nothing to restore
                continue
            t1 = time.time()
            ev = {"kind": kind, "reason": reason, "detected_at": t0, "restored_at": t1,
                  "took_ms": round((t1 - t0) * 1000, 2), "records": n}
            _log("rehydrated", **ev)
            out.append(ev)
        try:
            done = self.repair_budgets()
        except (redis.RedisError, OSError) as exc:
            _log("rehydrate_error", kind="budget_counters", error=repr(exc)[:300])
        else:
            if done:
                _log("rehydrated_budget_counters", repairs=done)
        self.events.extend(out)
        return out

    def budget_repairs(self) -> list[tuple[str, str, int, Version, str]]:
        """(org, mode, value, version, expected tag) for every live budget whose store counter does not count
        down the current budget record: missing, untagged (adopt it) or of an older budget (reset)."""
        live = [r for r in self.db.records("budget") if not r["deleted"]]
        if not live:
            return []
        vals = self.r.mget([k for r in live for k in (K2_BUDGET + r["key"], K2_BUDGET_GEN + r["key"])])
        cps = self.db.checkpoints()
        out = []
        for i, rec in enumerate(live):
            org, v, limit = rec["key"], version_of(rec), int(rec["body"]["limit"])
            n, raw = vals[2 * i], vals[2 * i + 1]
            tag = raw.decode() if raw is not None else ""
            if n is None:
                cp = cps.get(org)
                out.append((org, "missing", cp[0] if cp is not None and cp[1] == v else limit, v, tag))
            elif not tag:
                out.append((org, "gen", 0, v, tag))
            elif tag != str(v):
                out.append((org, "reset", limit, v, tag))
        return out

    def repair_budgets(self) -> list[str]:
        done = []
        for org, mode, value, v, tag in self.budget_repairs():
            if self._cas(keys=[K2_BUDGET + org, K2_BUDGET_GEN + org], args=[tag, value, str(v), mode]):
                done.append(f"{org}:{mode}")
        return done

    def checkpoint(self) -> int:
        """Copy every tagged counter (counter and tag read in ONE command) to Postgres."""
        orgs = [r["key"] for r in self.db.records("budget") if not r["deleted"]]
        if not orgs:
            return 0
        vals = self.r.mget([k for o in orgs for k in (K2_BUDGET + o, K2_BUDGET_GEN + o)])
        rows = {}
        for i, o in enumerate(orgs):
            n, raw = vals[2 * i], vals[2 * i + 1]
            if n is not None and raw is not None:
                epoch, _, seq = raw.decode().partition(".")
                try:
                    rows[o] = (int(n), Version(int(epoch), int(seq)))
                except ValueError:
                    continue  # an unparsable tag: the repair round re-tags it
        self.db.checkpoint(rows)
        return len(rows)

    def run(self) -> None:
        _log("rehydrator_start", period_s=self.period_s, checkpoint_s=self.checkpoint_s)
        last_cp = 0.0
        while True:
            try:  # a database failover (Cloud SQL) or a store fault only delays the next round
                self.check_once()
                if time.monotonic() - last_cp >= self.checkpoint_s:
                    last_cp = time.monotonic()
                    self.checkpoint()
            except Exception as exc:  # noqa: BLE001 - psycopg / redis / network errors alike
                _log("rehydrate_round_failed", error=repr(exc)[:300])
            time.sleep(self.period_s)
