"""rvproto-2 control-plane CLI (C36): every write goes to Postgres first, then the store.

  export RV_DATABASE_URL=postgresql://USER:PASS@HOST:5432/DB  RV_REDIS_URL=redis://HOST:6379/0
  export RV_STATE_HMAC_KEY=<shared with the gateways; never printed>
  python -m rvproto.control init-db
  python -m rvproto.control seed [--quota-budget N] [--extra-key KEY:ORG ...]
  python -m rvproto.control plan-set FILE.json | plan-update ORG VERSION [--rule R --mode M --action A]
  python -m rvproto.control plan-delete ORG
  python -m rvproto.control key-add KEY ORG [--key-id ID] [--rate R] [--burst B] | key-revoke KEY
  python -m rvproto.control killswitch global|org|model [NAME] on|off
  python -m rvproto.control budget-set ORG TOKENS
  python -m rvproto.control rollback LOG_ID
  python -m rvproto.control rehydrate [--once]            (the re-hydrator; --once = one check, print events)
  python -m rvproto.control verify                         (store vs Postgres per kind; exit 1 on divergence)
API keys are never printed; outputs name the key by the first 12 hex digits of its sha256.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time

import redis

from rvproto.control.db import PgDB
from rvproto.control.rehydrate import Rehydrator
from rvproto.control.writer import StateWriter, key_hash
from rvproto.plan.fixtures import tenants

TEST_KEYS = (("sk-rv-org-a-0001", "key-a-1", "org-a"), ("sk-rv-org-b-0001", "key-b-1", "org-b"),
             ("sk-rv-org-q-0001", "key-q-1", "org-q"))  # test keys (not secrets), as tools/seed.py


def _env(name: str) -> str:
    v = os.environ.get(name, "")
    if not v:
        raise SystemExit(f"{name} is not set")
    return v


def _writer() -> StateWriter:
    db = PgDB(_env("RV_DATABASE_URL"))
    r = redis.Redis.from_url(os.environ.get("RV_REDIS_URL", "redis://127.0.0.1:6379/0"), socket_timeout=5)
    return StateWriter(db, r, _env("RV_STATE_HMAC_KEY").encode(), actor=os.environ.get("RV_ACTOR", "rvproto.control"))


def _out(**kw: object) -> None:
    print(json.dumps({"t": time.time(), **kw}, default=str))


def seed(w: StateWriter, a: argparse.Namespace) -> None:
    keys = {k: (kid, org) for k, kid, org in TEST_KEYS}
    for i, kv in enumerate(a.extra_key):
        k, org = kv.rsplit(":", 1)
        keys[k] = (f"key-extra-{i}", org)
    for k, (kid, org) in keys.items():
        w.key_add(k, org, key_id=kid, rate=a.rate, burst=a.burst)
    for org, doc in tenants().items():
        w.plan_set(doc)
        w.budget_set(org, a.quota_budget if org == "org-q" else a.budget)
        w.killswitch("org", org, False)  # explicit OFF records
    w.killswitch("global", None, False)
    _out(seeded_keys=[key_hash(k)[:12] for k in keys], orgs=list(tenants()))


def _plan_update(w: StateWriter, a: argparse.Namespace) -> None:
    cur = {r["key"]: r for r in w.db.records("plan")}.get(a.org)
    if cur is None or cur["deleted"]:
        raise SystemExit(f"no live plan for {a.org}")
    doc = dict(cur["body"], version=a.version)
    for rule in doc["rules"]:
        if rule["rule_id"] == a.rule:
            rule["mode"] = a.mode or rule["mode"]
            rule["action"] = a.action or rule["action"]
    v = w.plan_set(doc)
    _out(org=a.org, plan_version=a.version, state_version=str(v), published_at=time.time())


def _verify(w: StateWriter) -> int:
    rh = Rehydrator(w.db, w.r, w, period_ms=1000, checkpoint_s=5)
    bad = {k: rh.diagnose(k) for k in ("plan", "key", "ks", "budget")}
    _out(verify={k: v or "ok" for k, v in bad.items()})
    return 1 if any(bad.values()) else 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m rvproto.control")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("init-db")
    p = sub.add_parser("seed")
    p.add_argument("--budget", type=int, default=10**13)
    p.add_argument("--quota-budget", type=int, default=2500)
    p.add_argument("--rate", type=float, default=1e6)
    p.add_argument("--burst", type=float, default=1e6)
    p.add_argument("--extra-key", action="append", default=[])
    sub.add_parser("plan-set").add_argument("file")
    p = sub.add_parser("plan-update")
    for x in ("org", "version"):
        p.add_argument(x)
    for x in ("--rule", "--mode", "--action"):
        p.add_argument(x)
    sub.add_parser("plan-delete").add_argument("org")
    p = sub.add_parser("key-add")
    p.add_argument("key")
    p.add_argument("org")
    p.add_argument("--key-id", default="")
    p.add_argument("--rate", type=float, default=1e6)
    p.add_argument("--burst", type=float, default=1e6)
    sub.add_parser("key-revoke").add_argument("key")
    p = sub.add_parser("killswitch")
    p.add_argument("scope", choices=("global", "org", "model"))
    p.add_argument("rest", nargs="+")
    p = sub.add_parser("budget-set")
    p.add_argument("org")
    p.add_argument("tokens", type=int)
    sub.add_parser("rollback").add_argument("log_id", type=int)
    sub.add_parser("rehydrate").add_argument("--once", action="store_true")
    sub.add_parser("verify")
    a = ap.parse_args(argv)
    if a.cmd == "init-db":
        PgDB(_env("RV_DATABASE_URL")).init_schema()
        _out(init_db="ok")
        return 0
    w = _writer()
    if a.cmd == "seed":
        seed(w, a)
    elif a.cmd == "plan-set":
        with open(a.file) as fh:
            doc = json.load(fh)
        _out(org=doc["org_id"], state_version=str(w.plan_set(doc)))
    elif a.cmd == "plan-update":
        _plan_update(w, a)
    elif a.cmd == "plan-delete":
        _out(org=a.org, state_version=str(w.plan_delete(a.org)))
    elif a.cmd == "key-add":
        v = w.key_add(a.key, a.org, key_id=a.key_id or f"key-{key_hash(a.key)[:8]}", rate=a.rate, burst=a.burst)
        _out(key=key_hash(a.key)[:12], org=a.org, state_version=str(v))
    elif a.cmd == "key-revoke":
        _out(key=key_hash(a.key)[:12], revoked=True, state_version=str(w.key_revoke(a.key)), set_at=time.time())
    elif a.cmd == "killswitch":
        state = a.rest[-1]
        if state not in ("on", "off") or (a.scope != "global" and len(a.rest) != 2):
            raise SystemExit("killswitch global on|off | killswitch org|model NAME on|off")
        v = w.killswitch(a.scope, a.rest[0] if a.scope != "global" else None, state == "on")
        _out(scope=a.scope, key=a.rest[0] if a.scope != "global" else None, state=state, state_version=str(v),
             set_at=time.time())
    elif a.cmd == "budget-set":
        _out(org=a.org, tokens=a.tokens, state_version=str(w.budget_set(a.org, a.tokens)))
    elif a.cmd == "rollback":
        _out(rollback=a.log_id, state_version=str(w.rollback(a.log_id)))
    elif a.cmd == "rehydrate":
        rh = Rehydrator(w.db, w.r, w, period_ms=float(os.environ.get("RV_REHYDRATE_PERIOD_MS", "1000")),
                        checkpoint_s=float(os.environ.get("RV_BUDGET_CHECKPOINT_S", "5")),
                        stale_grace_ms=float(os.environ.get("RV_REHYDRATE_STALE_GRACE_MS", "250")))
        if a.once:
            _out(events=rh.check_once())
        else:
            rh.run()
    elif a.cmd == "verify":
        return _verify(w)
    return 0


if __name__ == "__main__":
    sys.exit(main())
