"""Entry point (outside the layered packages): launchers + worker + guard owner.

    python -m rvproto.serve                    # launcher: contract.workers() HTTP workers
                                               #   (+ local owners when RV_GUARD_TOPOLOGY=owner)
    python -m rvproto.serve --guard-node       # guard-only node (split topology): owners only
    python -m rvproto.serve --worker           # one worker (RV_WORKER_INDEX set by the launcher)
    python -m rvproto.serve --guard-owner <i>  # the process that owns GPU i

Workers bind the same port with SO_REUSEPORT (kernel load-balances connections);
worker i gets RV_WORKER_INDEX=i so local_gpu can pin GPU i % n_gpus (in_process) or
use owner i % n_owners (owner). A gateway-only node is the plain launcher with
RV_GUARD_TOPOLOGY=remote (workers only; owners on guard nodes, RV_GUARD_OWNER_ADDRS).
Launchers start owners before workers and restart an owner that dies; while it is down,
guard calls that need it are UNAVAILABLE.
"""

from __future__ import annotations

import json
import os
import signal
import socket
import subprocess
import sys
import threading
import time
from pathlib import Path

from rvproto.runtime import contract as rc
from rvproto.runtime.config import Settings, describe, load_settings
from rvproto.runtime.exporter import NodeExporter


def _socket(host: str, port: int, backlog: int) -> socket.socket:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
    sock.bind((host, port))
    sock.listen(backlog)
    sock.set_inheritable(True)
    return sock


def worker() -> None:
    s = load_settings()
    if s.v2.c38.on:  # before the tokenizers library starts its (per-process, num_cpus) rayon pool
        os.environ["TOKENIZERS_PARALLELISM"] = "false"
    import uvicorn

    from rvproto.edge.app import RvApp

    contract, _ = rc.load()
    bounds = rc.derive(contract, s)
    sock = _socket(s.host, s.port, bounds.listen_backlog)
    config = uvicorn.Config(
        RvApp(),
        loop="uvloop",
        http="httptools",
        lifespan="on",
        access_log=False,
        log_level="warning",
        limit_concurrency=bounds.limit_concurrency,
        backlog=bounds.listen_backlog,
        timeout_keep_alive=int(os.environ.get("RV_KEEPALIVE_S", "75")),
        timeout_graceful_shutdown=int(s.v2.c43.drain_s) if s.v2.c43.drain_accept_s > 0 else None,
        server_header=False,
        date_header=False,
    )
    uvicorn.Server(config).run(sockets=[sock])


def guard_owner(index: int) -> None:
    from rvproto.detect.guard.factory import model_hash
    from rvproto.detect.guard.owner import run_owner

    s = load_settings()
    run_owner(s, index, gpu=s.guard_backend == "local_gpu", model_hash=model_hash(s))


def _log(event: str, **kw: object) -> None:
    sys.stderr.write(json.dumps({"event": event, **kw}, default=str) + "\n")


def _env(s: Settings, tag: str) -> dict[str, str]:
    env = dict(os.environ, RV_METRICS_TAG=tag)
    if s.v2.c38.on:
        env["TOKENIZERS_PARALLELISM"] = "false"
    if s.guard_model and "RV_GUARD_MODEL_SHA256" not in env:
        from rvproto.detect.semantic import file_hash

        env["RV_GUARD_MODEL_SHA256"] = file_hash(s.guard_model)
    return env


def _exporter(s: Settings, tag: str, kind: str, draining: list[bool], expect_workers: int = 0) -> NodeExporter | None:
    """C38: one exporter per node, in this (non-serving) process; stale segments of this tag are removed."""
    if not s.v2.c38.on:
        return None
    push = None
    if s.v2.signals.cloud_monitoring:
        from rvproto.runtime.monitoring import CloudMonitoring

        push = CloudMonitoring(s, kind).push
    exp = NodeExporter(tag=tag, kind=kind, metrics_dir=s.metrics_dir, dump_s=s.metrics_dump_s,
                       host=s.v2.c38.exporter_host, port=s.v2.c38.exporter_port, export_s=s.v2.signals.export_s,
                       draining=lambda: draining[0], push=push, expect_workers=expect_workers)
    from rvproto.edge.exporter_http import handler

    exp.cleanup()
    exp.start(handler)
    signal.signal(signal.SIGUSR1, lambda signum, frame: threading.Thread(target=exp.dump, daemon=True).start())
    return exp


class Owners:
    """Supervisor of this node's guard owners (one per GPU; one for local_cpu)."""

    def __init__(self, s: Settings, env: dict[str, str]) -> None:
        from rvproto.detect.guard.factory import owner_count

        self.s = s
        self.n = owner_count(s)
        self.env = dict(env)
        if s.guard_backend == "local_gpu":
            self.env["RV_GUARD_N_GPUS"] = str(self.n)  # owners and workers agree on the GPU count
        sock_dir = Path(s.guard_socket_dir)
        sock_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
        for stale in sock_dir.glob("guard-*"):  # a stale .ready would admit workers to a dead owner
            stale.unlink()
        self.spawned: dict[int, float] = {}
        self.procs = {i: self._spawn(i) for i in range(self.n)}

    def _spawn(self, i: int) -> subprocess.Popen[bytes]:
        (Path(self.s.guard_socket_dir) / f"guard-{i}.sock.ready").unlink(missing_ok=True)
        self.spawned[i] = time.monotonic()
        return subprocess.Popen([sys.executable, "-m", "rvproto.serve", "--guard-owner", str(i)], env=self.env)

    def poll(self) -> None:
        """An owner death is an outage (UNAVAILABLE -> posture), not a stop: restart it, at most
        once per staleness period (crash-loop guard)."""
        for i, o in list(self.procs.items()):
            rc_ = o.poll()
            if rc_ is not None and time.monotonic() - self.spawned[i] >= self.s.ks_stale_ms / 1000:
                _log("guard_owner_exited", owner=i, pid=o.pid, returncode=rc_)
                self.procs[i] = self._spawn(i)
                _log("guard_owner_restarted", owner=i, pid=self.procs[i].pid)

    def stop(self, timeout: float = 10) -> None:
        """SIGTERM = the owner drains (finishes queued windows, redirects new ones) and exits."""
        for o in self.procs.values():
            if o.poll() is None:
                o.send_signal(signal.SIGTERM)
        deadline = time.monotonic() + timeout
        for o in self.procs.values():
            try:
                o.wait(timeout=max(deadline - time.monotonic(), 0.1))
            except subprocess.TimeoutExpired:
                o.kill()


def guard_node() -> int:
    """Guard-only node (split topology): owners listening per RV_GUARD_OWNER_LISTEN, no workers.
    SIGTERM = drain: every owner stops taking new windows (workers re-route), finishes its queue and
    exits within RV_GUARD_DRAIN_S; the supervisor then exits."""
    s = load_settings()
    contract, logs = rc.load()
    port = s.guard_owner_listen_tcp[1] if s.guard_owner_listen_tcp else s.port
    tag, draining = f"g{port}", [False]
    exporter = _exporter(s, tag, "guard", draining)
    owners = Owners(s, _env(s, tag))
    _log("guard_node", guard_owners=owners.n, listen_unix=s.guard_owner_listen_unix,
         listen_tcp=s.guard_owner_listen_tcp, settings=describe(s),
         contract=rc.describe(contract, logs, rc.derive(contract, s)))

    def _stop(signum: int, frame: object) -> None:
        draining[0] = True

    signal.signal(signal.SIGTERM, _stop)
    signal.signal(signal.SIGINT, _stop)
    while not draining[0]:
        owners.poll()
        time.sleep(0.2)
    _log("guard_node_draining", bound_s=s.v2.c43.guard_drain_s)
    owners.stop(timeout=s.v2.c43.guard_drain_s + 5)
    if exporter is not None:
        exporter.stop()
        exporter.cleanup()
    return 0


def _spawn_workers(n: int, env: dict[str, str]) -> list[subprocess.Popen[bytes]]:
    procs = []
    for i in range(n):
        wenv = dict(env, RV_WORKER_INDEX=str(i), RV_WORKER_COUNT=str(n))
        procs.append(subprocess.Popen([sys.executable, "-m", "rvproto.serve", "--worker"], env=wenv))
    return procs


def _signal_all(procs: list[subprocess.Popen[bytes]], sig: int) -> None:
    for p in procs:
        if p.poll() is None:
            p.send_signal(sig)


def launcher() -> int:
    """SIGTERM = drain: workers report not-ready (/readyz 503) and close keep-alive connections for
    RV_DRAIN_ACCEPT_S while the load balancer takes them out, then stop accepting and finish in-flight
    streams within RV_DRAIN_S (uvicorn graceful shutdown). RV_DRAIN_ACCEPT_S=0 = frozen-1 (immediate)."""
    s = load_settings()
    contract, logs = rc.load()
    bounds = rc.derive(contract, s)
    n = bounds.workers
    tag, draining = str(s.port), [False]
    local_owners = s.guard_topology == "owner" and s.guard_backend in ("local_cpu", "local_gpu")
    exporter = _exporter(s, tag, "unit" if local_owners else "gateway", draining, expect_workers=n)
    env = _env(s, tag)
    owners = None
    if local_owners:
        owners = Owners(s, env)
        env = owners.env
    _log("launcher", workers=n, guard_topology=s.guard_topology, guard_owners=owners.n if owners else 0,
         owner_addrs=s.guard_owner_addrs, settings=describe(s), contract=rc.describe(contract, logs, bounds))
    procs = _spawn_workers(n, env)
    stop_at: list[float | None] = [None]

    def _stop(signum: int, frame: object) -> None:
        if draining[0]:
            return
        draining[0] = True
        accept_s = s.v2.c43.drain_accept_s
        _log("launcher_draining", accept_s=accept_s, drain_s=s.v2.c43.drain_s)
        if accept_s > 0:
            _signal_all(procs, signal.SIGUSR2)  # workers: readyz 503 + connection: close
        stop_at[0] = time.monotonic() + accept_s

    signal.signal(signal.SIGTERM, _stop)
    signal.signal(signal.SIGINT, _stop)
    code = 0
    alive = list(procs)
    while alive:
        if stop_at[0] is not None and time.monotonic() >= stop_at[0]:
            stop_at[0] = None
            _signal_all(alive, signal.SIGTERM)  # stop accepting; finish in-flight within RV_DRAIN_S
        for p in list(alive):
            rc_ = p.poll()
            if rc_ is not None:
                alive.remove(p)
                if rc_ != 0 and not draining[0]:
                    code = rc_
                    _stop(signal.SIGTERM, None)
                    stop_at[0] = time.monotonic()
        if owners is not None and not draining[0]:
            owners.poll()
        time.sleep(0.2)
    if owners is not None:
        owners.stop(timeout=s.v2.c43.guard_drain_s + 5)
    if exporter is not None:
        exporter.stop()
        exporter.cleanup()
    return code


if __name__ == "__main__":
    if "--worker" in sys.argv:
        worker()
    elif "--guard-owner" in sys.argv:
        guard_owner(int(sys.argv[sys.argv.index("--guard-owner") + 1]))
    elif "--guard-node" in sys.argv:
        raise SystemExit(guard_node())
    else:
        raise SystemExit(launcher())
