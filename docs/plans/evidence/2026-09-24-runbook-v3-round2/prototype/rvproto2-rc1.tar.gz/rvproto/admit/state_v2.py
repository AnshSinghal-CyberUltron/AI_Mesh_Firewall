"""C36 readers for identity and kill switches over the versioned, signed store layout (runtime/versioned.py).

VersionedKillSwitch: one atomic read (MULTI) per refresh of the kill-switch manifest + records and the
key manifest. Every scope has an EXPLICIT record (the global switch must exist, "off" included), so a
flushed or partial store can never read as "no switch engaged": the refresh fails like an outage, the
RAM snapshot keeps serving until its staleness ceiling (a killed org stays killed), then every request
is refused 503 kill_switch_unavailable until the re-hydrator restores the store.
The key manifest's version is the auth epoch: any key write (a revocation) clears every worker's
principal cache within one refresh period.
VersionedIdentity: a cache miss reads the key record and the key manifest in one MULTI. Missing or
regressed manifest => StoreDataUnavailable (503 shared_state_unavailable), never 401 for a valid key;
manifest present and no record => 401 (never issued); explicit OFF record => 401 (revoked). A fetched
principal enters the cache only when the manifest version is the one this process has applied
(epoch-checked cache fill), so a stale replica cannot re-admit a key revoked at a newer version.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import sys
import time

import redis.asyncio as aioredis

from rvproto.domain.request import Principal
from rvproto.runtime.metrics import Registry
from rvproto.runtime.store import K2_KEYS, K2_KS, K2_META, StoreError
from rvproto.runtime.versioned import ZERO, StoreDataUnavailable, Version, verify_meta, verify_record, verify_set, version_of


class VersionedIdentity:
    def __init__(self, r: aioredis.Redis, hmac_key: bytes) -> None:
        self.r = r
        self.k = hmac_key
        self._cache: dict[str, Principal] = {}
        self.version = ZERO  # the key manifest version this process has applied

    def on_epoch(self, v: Version) -> None:
        if v > self.version:
            self._cache = {}
            self.version = v

    def cached(self, api_key: str) -> tuple[str, Principal | None]:
        h = hashlib.sha256(api_key.encode()).hexdigest()
        return h, self._cache.get(h)

    async def fetch(self, key_hash: str) -> Principal | None:
        """One shared-state round trip. Raises StoreError (incl. StoreDataUnavailable) on outage/gap."""
        pipe = self.r.pipeline(transaction=True)
        pipe.hget(K2_KEYS, key_hash)
        pipe.get(K2_META + "key")
        raw, meta_raw = await pipe.execute()
        meta = verify_meta(self.k, "key", meta_raw, not_before=self.version)
        mv = version_of(meta)
        if raw is None:
            return None  # the manifest proves the store is complete: this key was never issued
        rec = verify_record(self.k, "key", raw)
        if version_of(rec) > mv:
            raise StoreDataUnavailable("key record newer than its manifest")
        if rec["deleted"]:
            return None  # explicit OFF record: revoked
        d = rec["body"]
        p = Principal(key_id=str(d["key_id"]), org_id=str(d["org_id"]), rate_per_s=float(d["rate_per_s"]),
                      burst=float(d["burst"]), epoch=mv.epoch)
        self.on_epoch(mv)
        if mv == self.version:  # epoch-checked fill
            self._cache[key_hash] = p
        return p


class VersionedKillSwitch:
    def __init__(self, r: aioredis.Redis, metrics: Registry, hmac_key: bytes, *, refresh_ms: float,
                 stale_ms: float, identity: VersionedIdentity) -> None:
        self.r = r
        self.metrics = metrics
        self.k = hmac_key
        self.refresh_s = refresh_ms / 1000.0
        self.stale_ns = int(stale_ms * 1e6)
        self.identity = identity
        self.engaged = False
        self.orgs: frozenset[str] = frozenset()
        self.models: frozenset[str] = frozenset()
        self.version = ZERO
        self.last_ok_ns = 0

    def age_s(self) -> float:
        return (time.perf_counter_ns() - self.last_ok_ns) / 1e9

    def state(self) -> str:
        """'ok' | 'engaged' | 'stale' -- evaluated from RAM only."""
        if time.perf_counter_ns() - self.last_ok_ns > self.stale_ns:
            return "stale"
        return "engaged" if self.engaged else "ok"

    def org_killed(self, org: str) -> bool:
        return org in self.orgs

    def model_killed(self, model: str) -> bool:
        return model in self.models

    async def refresh_once(self) -> None:
        pipe = self.r.pipeline(transaction=True)
        pipe.get(K2_META + "ks")
        pipe.hvals(K2_KS)
        pipe.get(K2_META + "key")
        meta_raw, raws, key_meta_raw = await pipe.execute()
        meta = verify_meta(self.k, "ks", meta_raw, not_before=self.version)
        recs = {r["key"]: r for r in verify_set(self.k, "ks", meta, raws)}
        glob = recs.get("global")
        if glob is None or glob["deleted"]:
            raise StoreDataUnavailable("global kill-switch record missing (every scope needs an explicit record)")
        key_meta = verify_meta(self.k, "key", key_meta_raw, not_before=self.identity.version)
        live = {k: bool(r["body"]["on"]) for k, r in recs.items() if not r["deleted"]}
        self.engaged = live["global"]
        self.orgs = frozenset(k[4:] for k, on in live.items() if on and k.startswith("org:"))
        self.models = frozenset(k[6:] for k, on in live.items() if on and k.startswith("model:"))
        self.version = version_of(meta)
        self.identity.on_epoch(version_of(key_meta))
        self.last_ok_ns = time.perf_counter_ns()

    async def run(self) -> None:
        while True:
            try:
                await self.refresh_once()
                self.metrics.inc("background_round_trips")
            except StoreError as exc:
                self.metrics.inc("killswitch_refresh_errors")
                if isinstance(exc, StoreDataUnavailable):
                    self.metrics.inc("state_unavailable_refreshes")
                sys.stderr.write(json.dumps({"event": "killswitch_refresh_error", "t": time.time(),
                                             "error": repr(exc)[:300]}) + "\n")
            await asyncio.sleep(self.refresh_s)
