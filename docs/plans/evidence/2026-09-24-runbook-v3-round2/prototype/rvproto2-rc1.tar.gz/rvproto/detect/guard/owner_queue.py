"""The ONE queue of a guard owner (its GPU): admission, backlog accounting and state pushes.

Admission (C10 on): a request is refused at once (SHED -> 503 + Retry-After = the backlog's drain time)
when the owner already has work and either
  - the backlog plus the request would exceed RV_OWNER_QUEUE_MS of work at the measured rate, or
  - the request would not finish within its own remaining budget: backlog + its own execution > budget
so an admitted request is not expected to expire in the queue (overload becomes a shed, never an
UNAVAILABLE finding that a FAIL_OPEN tenant would skip). C10 off: the frozen-1 bound
(pool_size(GUARD) of the AMF target), no budget check.
Backlog = queued + running padded tokens / measured tokens/s, minus the time the running item has already
spent (FIFO: the head of the queue has run since the previous completion, or since it arrived into an
empty queue), so neither admission nor the pushed state over-counts the work in progress.
The time integrals owner_backlog_ns_x_s and owner_windows_x_ms let the exporter report the average
queue over any window (autoscaling signal) without sampling.
State pushes (C43 on): after every change, one STATE frame per subscribed worker connection, coalesced
to at most one per event-loop iteration.
"""

from __future__ import annotations

import asyncio
import time
from collections import deque

from rvproto.detect.guard import wire
from rvproto.runtime.config import Settings
from rvproto.runtime.metrics import Registry


class OwnerQueue:
    def __init__(self, s: Settings, metrics: Registry, *, tokens_per_s: float, frozen_cap_tokens: int) -> None:
        self.metrics = metrics
        self.budget_check = s.v2.c10.on
        self.tps = tokens_per_s
        self.cap_tokens = int(tokens_per_s * s.v2.c10.owner_queue_ms / 1000.0) if s.v2.c10.on else frozen_cap_tokens
        self.queued_tokens = 0
        self.queued_windows = 0
        self._costs: deque[int] = deque()  # admitted, unfinished costs in FIFO order (the head is running)
        self._head_since = 0  # perf_counter_ns the head started running (0 = idle)
        self.draining = False
        self.subscribers: set[asyncio.StreamWriter] = set()
        self._push_pending = False
        self._t = time.perf_counter_ns()

    def backlog_ns(self, now: int | None = None) -> int:
        if not self.queued_tokens:
            return 0
        full = self.queued_tokens / self.tps * 1e9
        if self._costs and self._head_since:
            ran = (now or time.perf_counter_ns()) - self._head_since
            full -= min(max(ran, 0), self._costs[0] / self.tps * 1e9)
        return int(max(full, 0))

    def _acct(self) -> None:
        now = time.perf_counter_ns()
        dt, self._t = now - self._t, now
        if dt > 0 and self.queued_tokens:
            self.metrics.inc("owner_backlog_ns_x_s", int(self.backlog_ns() * dt / 1e9))
            self.metrics.inc("owner_windows_x_ms", int(self.queued_windows * dt / 1e6))

    def admit(self, cost_tokens: int, windows: int, budget_ns: int) -> float | None:
        """None = admitted (accounted); otherwise the Retry-After seconds of a SHED: the backlog's drain
        time, at least the request's own execution time."""
        now = time.perf_counter_ns()
        wait_s = self.backlog_ns(now) / 1e9
        if self.queued_tokens:
            reason = None
            if self.queued_tokens + cost_tokens > self.cap_tokens:
                reason = "queue_bound"
            elif self.budget_check and wait_s + cost_tokens / self.tps > budget_ns / 1e9:
                reason = "budget"
            if reason is not None:
                self.metrics.inc("owner_shed")
                self.metrics.inc(f'owner_shed_reason{{reason="{reason}"}}')
                return max(wait_s, cost_tokens / self.tps)  # at least the request's own run time
        self._acct()
        if not self._costs:
            self._head_since = now  # into an empty queue: it runs at once
        self._costs.append(cost_tokens)
        self.queued_tokens += cost_tokens
        self.queued_windows += windows
        self._changed()
        return None

    def finish(self, cost_tokens: int, windows: int) -> None:
        self._acct()
        try:
            self._costs.remove(cost_tokens)  # FIFO head in the normal case; a cancelled item elsewhere
        except ValueError:
            pass
        self._head_since = time.perf_counter_ns() if self._costs else 0
        self.queued_tokens -= cost_tokens
        self.queued_windows -= windows
        self._changed()

    def set_draining(self) -> None:
        self.draining = True
        self._changed()

    def subscribe(self, writer: asyncio.StreamWriter) -> None:
        self.subscribers.add(writer)
        writer.write(wire.encode_state(self.backlog_ns(), self.queued_windows, self.draining))

    def _changed(self) -> None:
        m = self.metrics
        m.set("owner_backlog_ns", self.backlog_ns())
        m.set("owner_queued_windows", self.queued_windows)
        m.set("owner_queued_tokens", self.queued_tokens)
        if self.subscribers and not self._push_pending:
            self._push_pending = True
            asyncio.get_running_loop().call_soon(self._push)

    def _push(self) -> None:
        self._push_pending = False
        frame = wire.encode_state(self.backlog_ns(), self.queued_windows, self.draining)
        n = 0
        for w in list(self.subscribers):
            if w.is_closing():
                self.subscribers.discard(w)
                continue
            try:
                w.write(frame)
                n += 1
            except (RuntimeError, OSError):  # the worker went away between the check and the write
                self.subscribers.discard(w)
        self.metrics.inc("owner_state_pushes", n)
