"""Guard discovery through the shared store (autoscaling: owners come and go without gateway restarts).

Owner side: every owner with a TCP listener registers
    {rv2}:guard:owner:<host:port>  JSON {id, addr, port, host, index, pid, tokens_per_s, model_hash, proto,
                                         draining, t}   SET ... PX <RV_GUARD_REGISTER_TTL_MS>
    {rv2}:guard:owners             SET of ids (members whose key has expired are pruned by readers)
refreshed every TTL/3; a draining owner re-registers with draining=true (gateways stop routing to it at
their next poll; subscribed workers already stopped on its state push) and deletes itself on exit.
Gateway side: each worker polls every RV_GUARD_DISCOVERY_MS and hands the live, non-draining owners
whose model hash equals the pinned one to its client, which adds/removes links live.
Store faults only delay discovery: the last known set keeps serving (connections are independent).
A registration that VANISHED is not proof that its owner is gone (a flushed or failed-over store loses
every registration at once, until the owners' next heartbeat): the client keeps an unregistered owner
while its connection is up and it is not draining, and drops it once the connection is gone (TCP
keepalive finds a vanished peer within ~4 s; an overdue request with no answer closes it sooner).
"""

from __future__ import annotations

import asyncio
import json
import socket
import sys
import time
from collections.abc import Callable
from dataclasses import dataclass

import redis.asyncio as aioredis

from rvproto.detect.guard import wire
from rvproto.runtime.store import K2_GUARD_OWNER, K2_GUARD_OWNERS, StoreError


@dataclass(frozen=True, slots=True)
class OwnerRecord:
    id: str
    addr: str
    port: int
    tokens_per_s: float
    model_hash: str
    draining: bool

    def endpoint(self) -> wire.Endpoint:
        return wire.Endpoint("tcp", self.addr, self.port)


def _log(event: str, **kw: object) -> None:
    sys.stderr.write(json.dumps({"event": event, "t": time.time(), **kw}, default=str) + "\n")


def parse(raw: bytes | None) -> OwnerRecord | None:
    if raw is None:
        return None
    try:
        d = json.loads(raw)
        return OwnerRecord(str(d["id"]), str(d["addr"]), int(d["port"]), float(d["tokens_per_s"]),
                           str(d["model_hash"]), bool(d.get("draining", False)))
    except (ValueError, KeyError, TypeError):
        return None


class OwnerRegistration:
    def __init__(self, url: str, *, advertise: tuple[str, int], hello: dict[str, object], ttl_ms: float) -> None:
        self.r = aioredis.Redis.from_url(url, socket_timeout=1.0, socket_connect_timeout=1.0)
        self.id = f"{advertise[0]}:{advertise[1]}"
        self.doc = {"id": self.id, "addr": advertise[0], "port": advertise[1], "host": socket.gethostname(),
                    **{k: hello[k] for k in ("index", "pid", "tokens_per_s", "model_hash") if k in hello},
                    "proto": 2, "draining": False}
        self.ttl_ms = int(ttl_ms)

    async def beat(self) -> None:
        doc = dict(self.doc, t=time.time())
        pipe = self.r.pipeline(transaction=False)
        pipe.set(K2_GUARD_OWNER + self.id, json.dumps(doc), px=self.ttl_ms)
        pipe.sadd(K2_GUARD_OWNERS, self.id)
        await pipe.execute()

    async def run(self) -> None:
        while True:
            try:
                await self.beat()
            except StoreError as exc:
                _log("guard_register_error", owner=self.id, error=repr(exc)[:200])
            await asyncio.sleep(self.ttl_ms / 3000.0)

    async def draining(self) -> None:
        self.doc["draining"] = True
        try:
            await self.beat()
        except StoreError as exc:
            _log("guard_register_error", owner=self.id, error=repr(exc)[:200])

    async def remove(self) -> None:
        try:
            pipe = self.r.pipeline(transaction=False)
            pipe.delete(K2_GUARD_OWNER + self.id)
            pipe.srem(K2_GUARD_OWNERS, self.id)
            await pipe.execute()
        except StoreError:
            pass
        await self.r.aclose()


async def read_owners(r: aioredis.Redis) -> list[OwnerRecord]:
    ids = sorted(x.decode() for x in await r.smembers(K2_GUARD_OWNERS))
    if not ids:
        return []
    raws = await r.mget([K2_GUARD_OWNER + i for i in ids])
    out, dead = [], []
    for i, raw in zip(ids, raws, strict=True):
        rec = parse(raw)
        if rec is None:
            dead.append(i)
        else:
            out.append(rec)
    if dead:
        await r.srem(K2_GUARD_OWNERS, *dead)
    return out


async def watch(r: aioredis.Redis, *, period_s: float, model_hash: str,
                apply: Callable[[list[wire.Endpoint], dict[str, float]], None]) -> None:
    """Worker task: poll the registry; apply(live non-draining endpoints, their tokens/s) every round (the
    client re-checks the owners it kept although unregistered)."""
    last: tuple[str, ...] | None = None
    while True:
        try:
            recs = [x for x in await read_owners(r) if x.model_hash == model_hash and not x.draining]
            key = tuple(sorted(x.id for x in recs))
            apply([x.endpoint() for x in recs], {x.id: x.tokens_per_s for x in recs})
            if key != last:
                _log("guard_discovery", owners=list(key))
                last = key
        except StoreError as exc:
            _log("guard_discovery_error", error=repr(exc)[:200])
        await asyncio.sleep(period_s)
