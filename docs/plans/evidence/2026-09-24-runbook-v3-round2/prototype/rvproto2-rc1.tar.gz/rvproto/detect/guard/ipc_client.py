"""Worker side of the owner topologies: submit windows to guard owners over a Unix socket (owner
on this node) or TCP (remote guard nodes, split topology). One connection per owner.

A request is answered by the owner that ran it, or resolved UNAVAILABLE (never a clean pass):
owner unreachable or dead, connection lost, or no answer within twice its budget (a silent peer is
also disconnected). Every result is checked (one probability in [0, 1] per window submitted).
Links reconnect in the background with bounded exponential backoff; each connection starts with
the owner's hello, whose model hash must equal the pinned one. The capacity hint is this worker's
share of the owners' measured rates: sum(owner tokens/s) / workers sharing those owners.

Routing (which owner gets a request):
  C43 off (frozen-1)  the owner with the fewest windows outstanding FROM THIS WORKER, ties rotating;
                      with 12-36 independent workers this is round-robin in practice and hands each
                      owner near-random arrivals (round 1: queue wait 0.65-0.71 of M/G/1)
  C43 on              every connection subscribes to its owner's backlog pushes (owner_queue.py);
                      estimate(owner) = pushed backlog drained by the time since it was sent + what
                      this worker sent it since; the least estimate wins, owners within
                      RV_GUARD_ROUTE_EPS_US of it tie (random pick, so workers do not herd)
A draining owner (state push flag, or a REDIRECT answer) gets no new work; a redirected request is
re-sent to another owner with its original deadline. Endpoints can change live (discovery.py).
"""

from __future__ import annotations

import asyncio
import dataclasses
import itertools
import json
import random
import socket
import time
from collections.abc import Sequence
from dataclasses import dataclass

from rvproto.detect.guard import wire
from rvproto.detect.guard.batcher import padded_cost
from rvproto.domain.guard import Budget, GuardResult, Readiness
from rvproto.runtime.config import Settings
from rvproto.runtime.contract import CapacityHint
from rvproto.runtime.metrics import Registry

# owner-side outcomes that come back as not-ok, counted under the in-process batcher's names
_FAIL_COUNTERS = (("deadline", "guard_deadline_expired"), ("execution failed", "guard_exec_errors"))


def _unavail(why: str) -> GuardResult:
    return GuardResult(False, (), 0, 0, 0, why)


class LinkDown(Exception):
    """The chosen owner connection turned out to be dead at write time."""


@dataclass(slots=True)
class _Pending:
    fut: asyncio.Future[GuardResult]
    t_submit: int
    windows: int
    expires: int
    rows: Sequence[Sequence[int]]
    budget: Budget
    est_ns: int
    redirects: int = 0


class _Link:
    """One connection to one owner."""

    def __init__(self, owner: OwnerClientBackend, ep: wire.Endpoint) -> None:
        self.o = owner
        self.ep = ep
        self.name = str(ep)
        self.writer: asyncio.StreamWriter | None = None
        self.info: dict[str, object] | None = None  # the last hello
        self.pending: dict[int, _Pending] = {}
        self.windows = 0
        self.last_rx = 0
        self.error = "not connected yet"
        # C43 state (owner pushes)
        self.subscribed = False
        self.backlog_ns = 0
        self.backlog_at = 0
        self.sent_since_ns = 0
        self.draining = False
        self.removed = False  # discovery dropped this owner: no new work; closed once idle
        self.task: asyncio.Task[None] | None = None

    @property
    def tps(self) -> float:
        return float(self.info["tokens_per_s"]) if self.info else 0.0  # type: ignore[arg-type]

    def estimate_ns(self, now: int) -> int:
        """C43: the owner's work ahead of a request sent now, as far as this worker can know."""
        if not self.subscribed or not self.backlog_at:
            per_window = int(self.o.s.window_tokens / self.tps * 1e9) if self.tps else 0
            return self.windows * per_window
        return max(self.backlog_ns - (now - self.backlog_at), 0) + self.sent_since_ns

    def routable(self) -> bool:
        return self.writer is not None and not self.draining and not self.removed

    async def _open(self) -> tuple[asyncio.StreamReader, asyncio.StreamWriter]:
        if self.ep.kind == "unix":
            return await asyncio.open_unix_connection(self.ep.address)
        reader, writer = await asyncio.open_connection(self.ep.address, self.ep.port)
        sock = writer.get_extra_info("socket")
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        # an IDLE peer that vanished (VM gone, partition) is found by keepalive within the
        # staleness period: first probe after half of it, then two unanswered 1 s probes
        half = max(1, int(self.o.s.ks_stale_ms / 2000))
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, half)
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPINTVL, 1)
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPCNT, 2)
        return reader, writer

    async def _frame(self, reader: asyncio.StreamReader) -> tuple[int, GuardResult]:
        (n,) = wire.U32.unpack(await reader.readexactly(4))
        if n > self.o.geo.max_response:
            raise wire.FrameError(f"response frame of {n} bytes")
        return wire.decode_response(await reader.readexactly(n), self.o.geo)

    async def _hello(self, reader: asyncio.StreamReader) -> dict[str, object]:
        req_id, hello = await self._frame(reader)
        info = json.loads(hello.detail) if req_id == 0 else {}
        if info.get("model_hash") != self.o.model_hash:  # never serve another model as this one
            self.o.metrics.inc("guard_owner_model_mismatch")
            raise ConnectionRefusedError(f"owner model {info.get('model_hash')} != pinned {self.o.model_hash}")
        float(info["tokens_per_s"])  # a hello without a measured rate is not a warm owner
        return info

    async def run(self) -> None:
        s = self.o.s
        period = s.ks_refresh_ms / 1000.0
        delay = floor = period / 10
        while not self.removed:
            writer: asyncio.StreamWriter | None = None
            try:
                reader, writer = await asyncio.wait_for(self._open(), period)
                self.info = await asyncio.wait_for(self._hello(reader), period)
                if self.o.s.v2.c43.on and int(self.info.get("proto", 1)) >= 2:  # type: ignore[call-overload]
                    writer.write(wire.encode_request(0, wire.SUBSCRIBE_BUDGET, []))
                    self.subscribed = True
                self.writer, self.last_rx, delay = writer, time.perf_counter_ns(), floor
                self.draining = False
                self.o.metrics.inc("guard_owner_connects")
                self.o.on_links_changed()
                while True:
                    req_id, res = await self._frame(reader)
                    if req_id == wire.STATE_ID:
                        self._state(res)
                    else:
                        self._deliver(req_id, res)
            except (OSError, asyncio.IncompleteReadError, ValueError, KeyError, TypeError) as exc:
                if self.writer is not None:
                    self.o.metrics.inc("guard_owner_disconnects")
                self.writer = None
                self.subscribed = False
                self.backlog_at = 0
                self.error = f"{type(exc).__name__}: {exc}"[:200]
                self.fail_all(f"guard owner {self.ep} unreachable: {type(exc).__name__}")
                self.o.on_links_changed()
            if writer is not None:
                writer.close()
            await asyncio.sleep(delay)
            delay = min(delay * 2, period)  # bounded backoff: never slower than the refresh period

    def _state(self, res: GuardResult) -> None:
        self.last_rx = time.perf_counter_ns()
        self.backlog_ns, self.backlog_at, self.sent_since_ns = res.queue_ns, self.last_rx, 0
        was, self.draining = self.draining, res.detail == "D"
        if self.draining and not was:
            self.o.metrics.inc("guard_owner_drain_seen")
            self.o.on_links_changed()

    def submit(self, req_id: int, p: _Pending) -> None:
        """Raises LinkDown when the connection is already gone (the peer died and the read loop has not
        noticed yet): the caller re-routes, the request never sees a transport error."""
        w = self.writer
        if w is None or w.is_closing():
            raise LinkDown(self.name)
        now = time.perf_counter_ns()
        remaining = p.budget.deadline_ns - now
        try:
            w.write(wire.encode_request(req_id, remaining, [list(r) for r in p.rows]))
        except (RuntimeError, OSError) as exc:  # uvloop raises on a closed transport
            self.writer = None
            self.error = f"write failed: {type(exc).__name__}"
            raise LinkDown(self.name) from exc
        self.pending[req_id] = p
        self.windows += p.windows
        self.sent_since_ns += p.est_ns

    def _write_quiet(self, frame: bytes) -> None:
        """Best-effort control frames (cancel): a dead connection is found by the read loop."""
        w = self.writer
        if w is not None and not w.is_closing():
            try:
                w.write(frame)
            except (RuntimeError, OSError):
                self.writer = None

    def cancel(self, req_id: int) -> None:
        p = self.pending.pop(req_id, None)
        if p is not None:
            self.windows -= p.windows
            self.o.metrics.inc("guard_cancelled_skipped")
            self._write_quiet(wire.encode_request(req_id, 0, []))  # tell the owner to skip the queued windows

    def _deliver(self, req_id: int, res: GuardResult) -> None:
        self.last_rx = time.perf_counter_ns()
        p = self.pending.pop(req_id, None)
        if p is None:
            return  # cancelled or timed out here before the owner answered
        self.windows -= p.windows
        m = self.o.metrics
        rtt = self.last_rx - p.t_submit
        m.observe("guard_owner_rtt_ns", rtt)
        if res.detail.startswith("redirect:"):  # the owner is draining: re-route, same deadline
            m.inc("guard_owner_redirects")
            self.draining = True
            self.o.on_links_changed()
            self.o.resend(p)
            return
        if res.ok and (len(res.p_malicious) != p.windows or not all(0.0 <= x <= 1.0 for x in res.p_malicious)):
            m.inc("guard_owner_bad_results")
            res = _unavail(f"guard owner {self.ep} returned an invalid result")
        elif res.ok:
            m.observe("guard_queue_ns", res.queue_ns)
            m.observe("guard_exec_ns", res.exec_ns)
            m.inc("guard_windows", p.windows)
        elif res.retry_after_s is not None:
            m.inc("guard_owner_sheds")
        else:
            m.inc(next((c for key, c in _FAIL_COUNTERS if key in res.detail), "guard_unavailable_batches"))
        if not p.fut.done():
            p.fut.set_result(dataclasses.replace(res, owner=self.name, rtt_ns=rtt))

    def sweep(self, now: int) -> None:
        """Answer overdue requests UNAVAILABLE. If the owner sent nothing at all since an overdue
        request was written, the connection is dead (half-open): drop it and reconnect."""
        silent = False
        for req_id in [r for r, p in self.pending.items() if p.expires <= now]:
            p = self.pending.pop(req_id)
            self.windows -= p.windows
            self.o.metrics.inc("guard_owner_timeouts")
            silent = silent or self.last_rx < p.t_submit
            self._write_quiet(wire.encode_request(req_id, 0, []))  # the owner need not keep work nobody waits for
            if not p.fut.done():
                p.fut.set_result(_unavail(f"guard owner {self.ep}: no answer within twice the budget"))
        if silent and self.writer is not None:
            self.writer.close()  # the read loop sees EOF, fails the rest and reconnects
        if self.removed and not self.pending and self.writer is not None:
            self.writer.close()  # a discovery-removed owner, now idle

    def fail_all(self, why: str) -> None:
        pending, self.pending, self.windows = self.pending, {}, 0
        if pending:
            self.o.metrics.inc("guard_unavailable_batches", len(pending))
        for p in pending.values():
            if not p.fut.done():
                p.fut.set_result(_unavail(why))

    def describe(self) -> str:
        if self.writer is None or self.info is None:
            return f"{self.ep} DOWN ({self.error})"
        i = self.info
        flags = (" DRAINING" if self.draining else "") + (" REMOVED" if self.removed else "")
        return f"{self.ep} pid={i['pid']} host={i['host']} tokens_per_s={float(i['tokens_per_s']):.0f}{flags}"  # type: ignore[arg-type]


class OwnerClientBackend:
    def __init__(self, s: Settings, metrics: Registry, *, endpoints: Sequence[wire.Endpoint], sharing: int,
                 model_hash: str, name: str) -> None:
        self.name = name
        self.s = s
        self.metrics = metrics
        self.sharing = sharing
        self.model_hash = model_hash
        self.geo = wire.Geometry(s.max_windows, s.window_tokens)
        self.links = [_Link(self, ep) for ep in endpoints]
        self.tokens_per_s: float | None = None
        self.detail = "waiting for guard owners"
        self._ids = itertools.count(1)
        self._rr = itertools.count()
        self._rng = random.Random()
        self._killed = False
        self._started = False
        self._tasks: list[asyncio.Task[None]] = []
        self._where: dict[int, tuple[_Link, int]] = {}  # id(future) -> (link, request id) for cancellation

    async def start(self) -> None:
        """Ready once one owner is connected and every CONFIGURED owner has said hello once
        (discovered owners join live without holding readiness back)."""
        for link in self.links:
            link.task = asyncio.create_task(link.run())
        self._tasks.append(asyncio.create_task(self._sweeper()))
        self._started = True
        while any(link.info is None for link in self.links) or not self._live():
            await asyncio.sleep(self.s.ks_refresh_ms / 1000.0)
        self.on_links_changed()

    def set_endpoints(self, eps: Sequence[wire.Endpoint], _tps: dict[str, float] | None = None) -> None:
        """Discovery: add links for new owners, retire links of owners that left (no new work;
        closed once their in-flight windows are answered). An owner whose registration vanished but
        whose connection is up and not draining is KEPT (a flushed store is not a dead fleet)."""
        want = {str(e): e for e in eps}
        have = {link.name: link for link in self.links if not link.removed}
        for name, link in have.items():
            if name not in want:
                if link.writer is not None and not link.draining:
                    self.metrics.inc("guard_owner_kept_unregistered")
                    continue
                link.removed = True
                self.metrics.inc("guard_owner_removed")
        for name, ep in want.items():
            if name not in have:
                link = _Link(self, ep)
                self.links.append(link)
                if self._started:
                    link.task = asyncio.create_task(link.run())
                self.metrics.inc("guard_owner_added")
        self.links = [x for x in self.links if not (x.removed and x.writer is None and not x.pending)]
        self.on_links_changed()

    def on_links_changed(self) -> None:
        live = [x for x in self.links if x.info is not None and x.routable()]
        if live:
            self.tokens_per_s = sum(x.tps for x in live) / self.sharing
        self.metrics.set("guard_owners_routable", len(live))
        self.refresh_detail()

    async def _sweeper(self) -> None:
        period = self.s.ks_refresh_ms / 5000.0
        while True:
            await asyncio.sleep(period)
            now = time.perf_counter_ns()
            for link in list(self.links):
                link.sweep(now)

    def _live(self) -> list[_Link]:
        return [link for link in self.links if link.routable()]

    def refresh_detail(self) -> None:
        if not self._killed:
            share = f"share 1/{self.sharing}" if self.tokens_per_s is not None else "starting"
            self.detail = (f"owners {len(self._live())}/{len(self.links)} routable, {share}: "
                           + "; ".join(link.describe() for link in self.links))[:1000]

    def _choose(self, live: list[_Link]) -> _Link:
        if not self.s.v2.c43.on:
            k = next(self._rr) % len(live)  # ties rotate; otherwise the least outstanding windows
            return min(live[k:] + live[:k], key=lambda x: x.windows)
        now = time.perf_counter_ns()
        est = [(x.estimate_ns(now), x) for x in live]
        low = min(e for e, _ in est) + self.s.v2.c43.route_eps_ns
        return self._rng.choice([x for e, x in est if e <= low])

    def submit(self, rows: Sequence[Sequence[int]], budget: Budget) -> asyncio.Future[GuardResult]:
        fut: asyncio.Future[GuardResult] = asyncio.get_running_loop().create_future()
        now = time.perf_counter_ns()
        grace = max(budget.deadline_ns - now, int(self.s.ks_refresh_ms * 1e6 / 5))
        p = _Pending(fut, now, len(rows), budget.deadline_ns + grace, rows, budget, 0)
        self._send(p)
        return fut

    def _send(self, p: _Pending) -> None:
        live = self._live()
        while live and not self._killed:
            link = self._choose(live)
            if link.tps:
                p.est_ns = int(padded_cost(p.rows, self.s.guard_seq_buckets) / link.tps * 1e9)
            req_id = next(self._ids)
            try:
                link.submit(req_id, p)
            except LinkDown:
                self.metrics.inc("guard_owner_write_errors")
                live = [x for x in live if x is not link]
                continue
            if not p.redirects:
                p.fut.add_done_callback(lambda f, lk=self: lk._cancel(f))
            self._where[id(p.fut)] = (link, req_id)
            return
        if not p.fut.done():
            p.fut.set_result(_unavail(f"guard backend not ready: {self.detail}"[:300]))

    def _cancel(self, f: asyncio.Future[GuardResult]) -> None:
        loc = self._where.pop(id(f), None)
        if loc is not None and f.cancelled():
            loc[0].cancel(loc[1])

    def resend(self, p: _Pending) -> None:
        """A draining owner redirected this request: send it once more elsewhere, same deadline."""
        p.redirects += 1
        if p.redirects > 2 or p.budget.deadline_ns <= time.perf_counter_ns():
            if not p.fut.done():
                p.fut.set_result(_unavail("guard owner draining; no other owner in time"))
            return
        self._send(p)

    async def classify(self, rows: Sequence[Sequence[int]], budget: Budget) -> GuardResult:
        return await self.submit(rows, budget)

    def queue_stats(self) -> tuple[int, int, float]:
        """This worker's outstanding owner requests: (items, windows, oldest age seconds)."""
        pend = [p for link in self.links for p in link.pending.values()]
        if not pend:
            return 0, 0, 0.0
        oldest = min(p.t_submit for p in pend)
        return len(pend), sum(p.windows for p in pend), (time.perf_counter_ns() - oldest) / 1e9

    async def readiness(self) -> Readiness:
        ok = not self._killed and self.tokens_per_s is not None and bool(self._live())
        return Readiness(ok, self.name, self.model_hash, self.detail)

    def capacity_hint(self) -> CapacityHint | None:
        return None if self.tokens_per_s is None else CapacityHint(tokens_per_second=self.tokens_per_s)

    def kill(self, why: str) -> None:
        self._killed = True
        self.detail = f"killed: {why}"
        for link in self.links:
            link.fail_all(f"guard backend down: {why}")

    def revive(self) -> None:
        self._killed = False
        self.refresh_detail()

    async def close(self) -> None:
        for t in self._tasks:
            t.cancel()
        for link in self.links:
            link.removed = True
            if link.task is not None:
                link.task.cancel()
            if link.writer is not None:
                link.writer.close()
